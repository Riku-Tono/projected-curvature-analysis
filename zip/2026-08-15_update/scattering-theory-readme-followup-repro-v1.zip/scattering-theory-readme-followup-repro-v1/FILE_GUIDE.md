# File guide

| Path | Role |
| --- | --- |
| github_overlay/README/README.md | Updated GitHub README |
| github_overlay/README/projected_curvature_decomposition.png | Existing README figure required by its relative image link |
| baseline/README.before.md | Exact pre-update README |
| UPDATE.patch | Unified before/after patch |
| evidence/base_repro/ | Self-contained base replay package with frozen maps and 38 solves |
| evidence/followup_packages/ | Five original sealed follow-up output packages and scripts |
| portable_replay/scripts/ | Path-only portable script copies used in temporary replay |
| PROVENANCE.json | Package boundary, hashes, exclusions, and claim boundary |
| requirements-lock.txt | Pinned analysis runtime |
| verify_package.py | One-command verifier and deterministic replay comparator |
| MANIFEST_SHA256.txt | Top-level file integrity manifest |
| PACKAGE_VERIFICATION.txt | Build-time verification record |

The external .zip.sha256 sidecar is delivered beside the ZIP and is intentionally outside the archive.
