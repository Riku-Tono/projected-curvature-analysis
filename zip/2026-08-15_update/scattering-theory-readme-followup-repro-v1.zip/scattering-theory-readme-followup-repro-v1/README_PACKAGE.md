# Scattering-theory README follow-up reproducibility package

This archive reproduces and audits the GitHub README update that documents the 90-degree near-null cancellation follow-up.

## Apply the GitHub overlay

From the extracted package root, copy:

~~~
github_overlay/README/README.md
github_overlay/README/projected_curvature_decomposition.png
~~~

to the repository-relative directory README/.

The pre-update README is preserved as baseline/README.before.md, and UPDATE.patch records the unified change.

## Verify

Install the pinned analysis dependencies if needed:

~~~bash
python -m pip install -r requirements-lock.txt
~~~

Then run:

~~~bash
python verify_package.py
~~~

The verifier checks the top-level and nested manifests, validates before/after provenance, derives README claims from sealed JSON, replays the bundled base package, regenerates all five follow-up stages from the 38 bundled solves, and compares deterministic JSON/CSV/text outputs with the sealed records.

Expected final line:

~~~
PACKAGE VERIFICATION: PASS
~~~

## Scope

- Source support solves: 38
- New solver runs: 0
- Final face-geometry regression models: 0
- Final follow-up decision: FACE_LEVEL_NOT_SUPPORTED
- Descriptive result retained: RANK1_FACE_GEOMETRY_CONFIRMED_DRIFT_LINK_NOT_ROBUST

Exact permutation fractions are finite five-scale ordering diagnostics, not population p-values.
