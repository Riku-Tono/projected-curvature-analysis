# Reproducibility protocol

## What is reproduced

1. Integrity of every packaged file through MANIFEST_SHA256.txt.
2. Integrity of the original base package and each of the five sealed follow-up packages.
3. The exact README before/after boundary and its GitHub overlay path.
4. README claim tokens derived from authoritative sealed JSON records.
5. The base projected-curvature replay from the bundled frozen maps and 38 saved solves.
6. Reverse-order regeneration of the five follow-up analyses in a temporary workspace.
7. Numerical comparison of regenerated deterministic JSON and CSV outputs with the sealed records.

## Why replay runs in reverse dependency order

Later stages verify hashes of earlier sealed manifests. Replaying a lower stage changes only its portable script hash and therefore its regenerated manifest. Running face -> adversarial -> drift -> fixed-direction -> near-null ensures that every stage sees its still-sealed prerequisite records.

## Portable-script boundary

The original scripts remain unchanged under evidence/followup_packages/. Copies under portable_replay/scripts/ change only the hard-coded local path constants:

- the upstream package becomes workspace/base_repro;
- cross-stage results become workspace/outputs/<stage>.

Scientific formulas, thresholds, offsets, and decision logic are unchanged.

## Declared noncompared replay outputs

- PNG files: rendering bytes can vary across platforms.
- PROVENANCE_SHA256.json: it records absolute paths.
- subpackage MANIFEST_SHA256.txt: it necessarily records the portable script hash.
- the analysis script itself: portable copies differ only in path constants.

All scientific JSON, CSV, scope, preflight, and generated README text records are compared. Numerical comparison uses tight floating tolerances only after exact byte comparison fails.

## No solver replay

The 38 solve JSON files are bundled inputs. No optimizer is invoked. new_solver_runs=0 remains a release gate.
