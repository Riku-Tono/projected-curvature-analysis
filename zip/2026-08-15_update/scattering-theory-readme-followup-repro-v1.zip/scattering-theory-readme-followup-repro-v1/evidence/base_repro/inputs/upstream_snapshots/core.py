from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import mpmath as mp
import numpy as np

from .config import Stage0Config


def mpf(value: object) -> mp.mpf:
    """Convert through str so decimal configuration values are reproduced exactly."""
    return mp.mpf(str(value))


def build_energy_grid(config: Stage0Config) -> tuple[mp.mpf, ...]:
    lo, hi = mpf(config.s_min), mpf(config.s_max)
    denominator = mp.mpf(config.n_s - 1)
    return tuple(
        lo + (hi - lo) * (mp.mpf(i) / denominator) ** config.p
        for i in range(config.n_s)
    )


def build_tail_grid(config: Stage0Config) -> tuple[mp.mpf, ...]:
    s_max = mpf(config.s_max)
    n = mp.mpf(config.n_s_prime)
    return tuple(s_max / (1 - mp.mpf(i) / n) for i in range(1, config.n_s_prime))


def build_variable_map(config: Stage0Config) -> dict[object, int]:
    mapping: dict[object, int] = {"z0": 0}
    index = 1
    for ell in config.ell_list:
        for k in range(config.k_max + 1):
            mapping[(ell, k)] = index
            index += 1
    if index != config.n_vars:
        raise AssertionError("variable map size mismatch")
    return mapping


def legendre_p(n: int, x: mp.mpf) -> mp.mpf:
    if n < 0:
        raise ValueError("Legendre degree must be nonnegative")
    if n == 0:
        return mp.mpf(1)
    if n == 1:
        return x
    p_nm2, p_nm1 = mp.mpf(1), x
    for degree in range(2, n + 1):
        p_n = ((2 * degree - 1) * x * p_nm1 - (degree - 1) * p_nm2) / degree
        p_nm2, p_nm1 = p_nm1, p_n
    return p_nm1


def phase_space(s: mp.mpf, m: mp.mpf) -> mp.mpf:
    a = 4 * m**2
    if s <= a:
        raise ValueError("phase_space requires s>4m^2")
    return mp.sqrt((s - a) / s)


def im_a_basis(s: mp.mpf, ell: int, k: int, m: mp.mpf) -> mp.mpf:
    a = 4 * m**2
    if s <= a:
        raise ValueError("im_a_basis requires s>4m^2")
    threshold = mp.sqrt(s / (s - a))
    spin_factor = ((s - a) / (s + a + 4 * m * mp.sqrt(s))) ** ell
    return threshold * spin_factor * legendre_p(k, 8 * m**2 / s - 1)


def phi_basis(mu: mp.mpf, t: mp.mpf, ell: int, k: int, m: mp.mpf) -> mp.mpf:
    a = 4 * m**2
    if mu <= a:
        raise ValueError("phi_basis requires mu>4m^2")
    return (
        16
        * mp.pi
        * (2 * ell + 1)
        * im_a_basis(mu, ell, k, m)
        * legendre_p(ell, 1 + 2 * t / (mu - a))
    )


def kernel(mu: mp.mpf, s: mp.mpf, t: mp.mpf, subtraction: mp.mpf, m: mp.mpf) -> mp.mpf:
    a = 4 * m**2
    return (
        1 / (mu - s)
        + 1 / (mu - a + s + t)
        - 1 / (mu - subtraction)
        - 1 / (mu - a + t + subtraction)
    )


def im_a_from_z(
    s: mp.mpf,
    ell: int,
    z: Iterable[mp.mpf],
    config: Stage0Config,
    variable_map: dict[object, int],
) -> mp.mpf:
    z_values = tuple(z)
    m = mpf(config.m)
    return mp.fsum(
        z_values[variable_map[(ell, k)]] * im_a_basis(s, ell, k, m)
        for k in range(config.k_max + 1)
    )


def unitarity_matrix(re_a: float, im_a: float, s: float, m: float = 1.0) -> np.ndarray:
    sm = np.sqrt((s - 4 * m * m) / s)
    return np.array(
        [[1 - 0.5 * sm * im_a, np.sqrt(sm) * re_a], [np.sqrt(sm) * re_a, 2 * im_a]],
        dtype=np.float64,
    )


def disk_slack(re_a: float, im_a: float, s: float, m: float = 1.0) -> float:
    sm = np.sqrt((s - 4 * m * m) / s)
    return float(2 * im_a - sm * (re_a * re_a + im_a * im_a))


def three_way(value: float, tolerance: float) -> str:
    if value > tolerance:
        return "PASS"
    if value < -tolerance:
        return "FAIL"
    return "BOUNDARY"


@dataclass(frozen=True)
class VerificationSummary:
    min_lmi_eigenvalue: float
    min_disk_slack: float
    hard_mismatch_count: int
    boundary_block_count: int
    tail_max_violation: float
    blocks: tuple[dict[str, object], ...]
    tail: tuple[dict[str, object], ...]


def verify_solution(
    z: np.ndarray,
    s_grid: np.ndarray,
    ell_list: tuple[int, ...],
    a_coeff: np.ndarray,
    b_coeff: np.ndarray,
    tail_s: np.ndarray,
    tail_b: np.ndarray,
    *,
    m: float = 1.0,
    tau_abs: float = 1.0e-7,
    tau_rel: float = 1.0e-7,
) -> VerificationSummary:
    rows: list[dict[str, object]] = []
    eig_values: list[float] = []
    det_values: list[float] = []
    mismatch_count = 0
    boundary_count = 0
    for ell_index, ell in enumerate(ell_list):
        for s_index, s in enumerate(s_grid):
            re_a = float(a_coeff[ell_index, s_index] @ z)
            im_a = float(b_coeff[ell_index, s_index] @ z)
            matrix = unitarity_matrix(re_a, im_a, float(s), m)
            eig_min = float(np.linalg.eigvalsh(matrix)[0])
            determinant = disk_slack(re_a, im_a, float(s), m)
            norm2 = float(np.linalg.norm(matrix, 2))
            eig_tol = tau_abs + tau_rel * max(1.0, norm2)
            det_tol = tau_abs + tau_rel * max(1.0, norm2 * norm2)
            eig_state = three_way(eig_min, eig_tol)
            det_state = three_way(determinant, det_tol)
            mismatch = (eig_state == "PASS" and det_state == "FAIL") or (
                eig_state == "FAIL" and det_state == "PASS"
            )
            mismatch_count += int(mismatch)
            boundary_count += int("BOUNDARY" in (eig_state, det_state))
            eig_values.append(eig_min)
            det_values.append(determinant)
            rows.append(
                {
                    "ell": ell,
                    "s_index": s_index,
                    "s": float(s),
                    "re_a": re_a,
                    "im_a": im_a,
                    "eig_min": eig_min,
                    "disk_slack": determinant,
                    "eig_state": eig_state,
                    "disk_state": det_state,
                    "hard_mismatch": mismatch,
                }
            )
    tail_rows: list[dict[str, object]] = []
    max_tail_violation = 0.0
    for ell_index, ell in enumerate(ell_list):
        for s_index, s in enumerate(tail_s):
            sm_im = float(np.sqrt((s - 4 * m * m) / s) * (tail_b[ell_index, s_index] @ z))
            violation = max(0.0, -sm_im, sm_im - 2.0)
            max_tail_violation = max(max_tail_violation, violation)
            tail_rows.append(
                {"ell": ell, "s_index": s_index, "s": float(s), "SmIm": sm_im, "violation": violation}
            )
    return VerificationSummary(
        min_lmi_eigenvalue=min(eig_values),
        min_disk_slack=min(det_values),
        hard_mismatch_count=mismatch_count,
        boundary_block_count=boundary_count,
        tail_max_violation=max_tail_violation,
        blocks=tuple(rows),
        tail=tuple(tail_rows),
    )
