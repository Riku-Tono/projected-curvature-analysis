from __future__ import annotations

import hashlib
import json
import math
import platform
import subprocess
import sys
import traceback
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any

import cvxpy
import numpy as np
import scs


ROOT = Path(__file__).resolve().parent
SOURCE_IMPL = Path(r"C:\Users\yauki\Documents\Codex\2026-08-14\stage-0\outputs\stage0_implementation_v1.0")
SOURCE_SRC = SOURCE_IMPL / "src"
if str(SOURCE_SRC) not in sys.path:
    sys.path.insert(0, str(SOURCE_SRC))

from stage0.config import Stage0Config  # noqa: E402
from stage0.core import (  # noqa: E402
    build_energy_grid,
    build_tail_grid,
    build_variable_map,
    im_a_basis,
    mpf,
    phase_space,
    unitarity_matrix,
)
from stage0.sdp import SolverConfig, SolverStop, solve_problem  # noqa: E402


PREREG = ROOT / "STAGE0_V3_SMOKE_SDP_GATE2.preregistered.json"
PRESEAL = ROOT / "PRE_EXECUTION_SEAL.txt"
FULL = Path(r"C:\Users\yauki\Documents\Codex\2026-08-14\new-chat-2\outputs\stage0_full_gate1_v3_run1")
RECOVERY = Path(r"C:\Users\yauki\Documents\Codex\2026-08-14\new-chat-2\outputs\stage0_linear_solve_v3_recovery_diagnostic_v1")
BENCHMARK = Path(r"C:\Users\yauki\Documents\Codex\2026-08-14\new-chat-2\outputs\stage0_smoke_v3_benchmark_v1")

INPUTS = {
    "gate1_evidence": RECOVERY / "gate1_evidence_synthesis.json",
    "linear_solve_recovery": RECOVERY / "linear_solve_verification.recovery.json",
    "a_coeff": RECOVERY / "a_coeff_recovery_v3.npy",
    "coefficient_evidence": FULL / "coefficient_precompute.json",
    "test_i_evidence": FULL / "test_i_result.json",
    "cal_i": FULL / "cal_i_v3.npy",
    "stage0_v3_preregistered": BENCHMARK / "STAGE0_SMOKE_V3.preregistered.json",
    "source_config": SOURCE_SRC / "stage0" / "config.py",
    "source_core": SOURCE_SRC / "stage0" / "core.py",
    "source_dispersion": SOURCE_SRC / "stage0" / "dispersion.py",
    "source_sdp": SOURCE_SRC / "stage0" / "sdp.py",
}

EXPECTED_HASHES = {
    "gate1_evidence": "026202FE8B52F30C8A0EEE62BA0634EA7A1D094BB94E27D85ABC3932C61BB538",
    "linear_solve_recovery": "B6D371EED166789248514E0425AD730E9FC05D7920C72E2022BDBA444A3900C6",
    "a_coeff": "0F3CA3DD30471DB3C136F392141A9618A8957BCD4260226364E3FE12E4C74161",
    "coefficient_evidence": "D38DCC7199BBC8F3390BFDCAE2CDF0382A4C5750F0AC2D78211527C4DD641024",
    "test_i_evidence": "27E9776D55B83939FB4F23585CAB5AFD1946645A1AF587E5A0F4449E57439251",
    "cal_i": "330907B4B2C08F969B86C9DC25BF5D8C848A3F777743662B7765B64D79BE4F57",
    "stage0_v3_preregistered": "D9D5E1C9EB8A31B67B2C6E429BA6726FE952D2F40480F00C5F23949ED04092CA",
    "source_config": "7F01A6D2D15C37C5FC951FF46C2E709D07CE64186A6DBD3225CCC19FE5078E86",
    "source_core": "8694C13C46264DF9705C7F5EA5C43B59C7C4C4712A8538916CDDFEBCB043B1A7",
    "source_dispersion": "860A20EBA2D910ABBB04EF3BE1841BECB55A38E6CD8DA3ED56150C5B13E751E4",
    "source_sdp": "1B429CB51997391F55F371CCEA0C7B80328C2F7FBBFC091B7CCD751065BF4C6B",
}

EXPECTED_PREREG_SHA256 = "779D96552CB88C932DBE8412201951946AF29E090344DD62A062795263B22553"

SOLVE_PLAN = [
    (1, "feasibility", "feasibility", "solve_01_feasibility.json"),
    (2, "g0_min", "minimize", "solve_02_g0_min.json"),
    (3, "g0_max", "maximize", "solve_03_g0_max.json"),
    (4, "g2_min", "minimize", "solve_04_g2_min.json"),
    (5, "g2_max", "maximize", "solve_05_g2_max.json"),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def json_value(value: Any) -> Any:
    if value is None:
        return "NOT_REPORTED"
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def frozen_config(preregistered: dict[str, Any]) -> Stage0Config:
    cfg = preregistered["scientific_config"]
    return Stage0Config(
        config_id="STAGE0_SMOKE_V3",
        m=cfg["m"], s0=cfg["s0"], t0=cfg["t0"],
        s_min=cfg["s_min"], s_max=cfg["s_max"], p=cfg["p"],
        n_s=cfg["n_s"], n_s_prime=cfg["n_s_prime"],
        ell_max=cfg["ell_max"], k_max=cfg["k_max"],
        t_grid=tuple(cfg["t_grid"]), precision_bits=cfg["precision_bits"],
        quad_n=cfg["quad_n"], quad_h_max=cfg["quad_h_max"],
        refined_n=cfg["refined_n"], refined_h_max=cfg["refined_h_max"],
        integral_abs_tol=cfg["integral_abs_tol"], integral_rel_tol=cfg["integral_rel_tol"],
        near_radius_power=cfg["near_radius_power"], t_collision_power=cfg["t_collision_power"],
        solve_residual_tol=cfg["solve_residual_tol"],
    )


def reconstruct_linear_maps(config: Stage0Config, a_coeff: np.ndarray) -> dict[str, object]:
    s_grid_mp = build_energy_grid(config)
    tail_grid_mp = build_tail_grid(config)
    mapping = build_variable_map(config)
    b_coeff = np.zeros((len(config.ell_list), config.n_s, config.n_vars), dtype=np.float64)
    tail_b = np.zeros((len(config.ell_list), len(tail_grid_mp), config.n_vars), dtype=np.float64)
    with __import__("mpmath").workprec(config.precision_bits):
        m = mpf(config.m)
        for ell_index, ell in enumerate(config.ell_list):
            for s_index, s in enumerate(s_grid_mp):
                for k in range(config.k_max + 1):
                    b_coeff[ell_index, s_index, mapping[(ell, k)]] = float(im_a_basis(s, ell, k, m))
            for s_index, s in enumerate(tail_grid_mp):
                for k in range(config.k_max + 1):
                    tail_b[ell_index, s_index, mapping[(ell, k)]] = float(im_a_basis(s, ell, k, m))
    return {
        "s_grid": np.asarray([float(value) for value in s_grid_mp]),
        "tail_grid": np.asarray([float(value) for value in tail_grid_mp]),
        "a_coeff": a_coeff,
        "b_coeff": b_coeff,
        "tail_b": tail_b,
    }


def preflight() -> tuple[dict[str, Any], Stage0Config, dict[str, object], np.ndarray, np.ndarray]:
    started = perf_counter()
    checks: list[dict[str, Any]] = []
    actual_hashes: dict[str, str] = {}
    for name, path in INPUTS.items():
        exists = path.is_file()
        actual = sha256(path) if exists else "MISSING"
        actual_hashes[name] = actual
        checks.append({"check": f"hash:{name}", "path": str(path), "expected": EXPECTED_HASHES[name], "actual": actual, "pass": exists and actual == EXPECTED_HASHES[name]})

    prereg_hash = sha256(PREREG)
    preseal_text = PRESEAL.read_text(encoding="utf-8") if PRESEAL.is_file() else ""
    seal_hashes = {}
    for line in preseal_text.splitlines():
        parts = line.split("  ", 1)
        if len(parts) == 2 and len(parts[0]) == 64:
            seal_hashes[parts[1]] = parts[0].upper()
    checks.append({"check": "preregistration_hash_matches_frozen_value", "expected": EXPECTED_PREREG_SHA256, "actual": prereg_hash, "pass": prereg_hash == EXPECTED_PREREG_SHA256})
    checks.append({"check": "preregistration_hash_recorded_in_pre_execution_seal", "pass": EXPECTED_PREREG_SHA256 in preseal_text})
    checks.append({"check": "runner_hash_recorded_in_pre_execution_seal", "expected": seal_hashes.get("run_gate2.py", "MISSING"), "actual": sha256(ROOT / "run_gate2.py"), "pass": seal_hashes.get("run_gate2.py") == sha256(ROOT / "run_gate2.py")})
    checks.append({"check": "package_verifier_hash_recorded_in_pre_execution_seal", "expected": seal_hashes.get("verify_package.py", "MISSING"), "actual": sha256(ROOT / "verify_package.py"), "pass": seal_hashes.get("verify_package.py") == sha256(ROOT / "verify_package.py")})
    preexisting_execution_outputs = [
        path.name for path in ROOT.iterdir()
        if path.is_file() and (path.name.startswith("solve_") or path.name in {"preflight_validation.json", "smoke_sdp_gate2_result.json"})
    ]
    checks.append({"check": "fresh_execution_output_namespace", "actual": preexisting_execution_outputs, "pass": not preexisting_execution_outputs})
    preregistered = load_json(PREREG)
    config = frozen_config(preregistered)
    gate1 = load_json(INPUTS["gate1_evidence"])
    recovery = load_json(INPUTS["linear_solve_recovery"])
    test_i = load_json(INPUTS["test_i_evidence"])
    stage0_v3 = load_json(INPUTS["stage0_v3_preregistered"])

    gate_fields = {
        "status": gate1.get("status") == "PASS",
        "gate1_evidence_complete": gate1.get("gate1_evidence_complete") is True,
        "sdp_solve_count": gate1.get("sdp_solve_count") == 0,
        "figure_1_started": gate1.get("figure_1_started") is False,
        "all_referenced_hashes_verified": gate1.get("all_referenced_hashes_verified") is True,
        "original_run_interrupted": gate1.get("original_run_status") == "INTERRUPTED",
    }
    for name, passed in gate_fields.items():
        checks.append({"check": f"gate1:{name}", "pass": passed})

    cross_hashes = {
        "coefficient_evidence": gate1.get("coefficient_evidence", {}).get("sha256") == actual_hashes["coefficient_evidence"],
        "test_i_evidence": gate1.get("test_i_evidence", {}).get("sha256") == actual_hashes["test_i_evidence"],
        "linear_solve_evidence": gate1.get("linear_solve_evidence", {}).get("sha256") == actual_hashes["linear_solve_recovery"],
        "a_coeff_recovery": recovery.get("solution_artifact", {}).get("file_sha256") == actual_hashes["a_coeff"],
        "stage0_v3_preregistered": recovery.get("verified_input_hashes", {}).get("inputs", {}).get("stage0_smoke_v3_preregistered", {}).get("sha256") == actual_hashes["stage0_v3_preregistered"],
        "cal_i": recovery.get("verified_input_hashes", {}).get("inputs", {}).get("cal_i", {}).get("sha256") == actual_hashes["cal_i"],
    }
    for name, passed in cross_hashes.items():
        checks.append({"check": f"cross_reference:{name}", "pass": passed})

    frozen = stage0_v3["config"]
    scientific_equal = all([
        config.m == frozen["m"], config.s0 == frozen["s0"], config.t0 == frozen["t0"],
        config.s_min == frozen["s_min"], config.s_max == frozen["s_max"], config.p == frozen["p"],
        config.n_s == frozen["n_s"], config.n_s_prime == frozen["n_s_prime"],
        config.ell_max == frozen["ell_max"], config.k_max == frozen["k_max"], list(config.t_grid) == frozen["t_grid"],
        config.precision_bits == frozen["precision_bits"], config.quad_n == frozen["quad_n"], config.quad_h_max == frozen["quad_h_max"],
        config.refined_n == frozen["refined_n"], config.refined_h_max == frozen["refined_h_max"],
        config.integral_abs_tol == frozen["integral_abs_tol"], config.integral_rel_tol == frozen["integral_rel_tol"],
        config.solve_residual_tol == frozen["solve_residual_tol"],
    ])
    checks.append({"check": "scientific_config_matches_STAG0_SMOKE_V3", "pass": scientific_equal})

    a_coeff = np.load(INPUTS["a_coeff"], allow_pickle=False)
    q0 = np.asarray(test_i["q0"], dtype=np.float64)
    q2 = np.asarray(test_i["q2"], dtype=np.float64)
    matrices = reconstruct_linear_maps(config, a_coeff)
    expected_shapes = {
        "a_coeff": [3, 30, 16], "b_coeff": [3, 30, 16], "tail_b": [3, 29, 16],
        "s_grid": [30], "tail_grid": [29], "q0": [16], "q2": [16],
    }
    arrays = {**matrices, "q0": q0, "q2": q2}
    for name, expected in expected_shapes.items():
        array = np.asarray(arrays[name])
        checks.append({"check": f"shape:{name}", "expected": expected, "actual": list(array.shape), "pass": list(array.shape) == expected})
        checks.append({"check": f"finite:{name}", "pass": bool(np.all(np.isfinite(array)))})

    structural = {
        "n_vars_is_16": config.n_vars == 16,
        "variable_order": [str(key) for key, _ in sorted(build_variable_map(config).items(), key=lambda item: item[1])],
        "even_partial_waves_only": config.ell_list == (0, 2, 4),
        "odd_partial_wave_count": sum(int(ell % 2 != 0) for ell in config.ell_list),
        "affine_re_shape": list(a_coeff.shape),
        "affine_im_shape": list(np.asarray(matrices["b_coeff"]).shape),
        "unitarity_block_shape": [2, 2],
        "unitarity_block_symmetric": True,
        "q0_finite_linear_map": bool(np.all(np.isfinite(q0)) and q0.shape == (16,)),
        "q2_finite_linear_map": bool(np.all(np.isfinite(q2)) and q2.shape == (16,)),
        "tail_constraint_count": 2 * 3 * 29,
        "lmi_block_count": 3 * 30,
    }
    checks.extend([
        {"check": "structural:n_vars", "pass": structural["n_vars_is_16"]},
        {"check": "structural:even_partial_waves", "pass": structural["even_partial_waves_only"]},
        {"check": "structural:q0", "pass": structural["q0_finite_linear_map"]},
        {"check": "structural:q2", "pass": structural["q2_finite_linear_map"]},
    ])

    solver_config = SolverConfig()
    solver_expected = preregistered["solver_contract"]
    solver_frozen = (
        solver_config.solver == solver_expected["solver"]
        and solver_config.eps_abs == solver_expected["eps_abs"]
        and solver_config.eps_rel == solver_expected["eps_rel"]
        and solver_config.max_iters == solver_expected["max_iters"]
        and solver_config.normalize is solver_expected["normalize"]
        and solver_config.acceleration_lookback == solver_expected["acceleration_lookback"]
    )
    checks.append({"check": "solver_configuration_frozen", "pass": solver_frozen, "actual": asdict(solver_config)})
    all_pass = all(row["pass"] for row in checks)
    payload = {
        "schema_version": "1.0",
        "status": "PASS" if all_pass else "STOP",
        "config_id": "STAGE0_V3_SMOKE_SDP_GATE2",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "gate1_evidence_sha256": actual_hashes["gate1_evidence"],
        "linear_solve_recovery_sha256": actual_hashes["linear_solve_recovery"],
        "preregistered_sha256": prereg_hash,
        "checks": checks,
        "structural_audit": structural,
        "solver_contract": {**asdict(solver_config), "accepted_statuses": ["optimal"]},
        "runtime": {"python": sys.version, "platform": platform.platform(), "cvxpy": cvxpy.__version__, "scs": scs.__version__, "numpy": np.__version__},
        "recomputation": {"dispersion_coefficients": False, "test_i": False, "linear_solve": False, "q0_q2": False},
        "sdp_solve_count": 0,
        "figure_1_started": False,
        "fractional_subtraction_started": False,
        "elapsed_seconds": perf_counter() - started,
    }
    write_json(ROOT / "preflight_validation.json", payload)
    if not all_pass:
        failed = [row for row in checks if not row["pass"]]
        raise RuntimeError(f"preflight validation failed: {failed[0]['check']}")
    return payload, config, matrices, q0, q2


def independent_summary(diagnostics: dict[str, Any], matrices: dict[str, object], config: Stage0Config, q0: np.ndarray, q2: np.ndarray, target: str) -> dict[str, Any]:
    z = np.asarray(diagnostics["z"], dtype=np.float64)
    a_coeff = np.asarray(matrices["a_coeff"])
    b_coeff = np.asarray(matrices["b_coeff"])
    s_grid = np.asarray(matrices["s_grid"])
    verification = diagnostics["verification"]
    blocks = verification["blocks"]
    tail = verification["tail"]
    lmi_entries_finite = True
    re_im_finite = True
    min_im = math.inf
    max_sm_im = -math.inf
    for row in blocks:
        re_a = float(row["re_a"])
        im_a = float(row["im_a"])
        matrix = unitarity_matrix(re_a, im_a, float(row["s"]), config.m)
        re_im_finite = re_im_finite and math.isfinite(re_a) and math.isfinite(im_a)
        lmi_entries_finite = lmi_entries_finite and bool(np.all(np.isfinite(matrix)))
        min_im = min(min_im, im_a)
        max_sm_im = max(max_sm_im, float(phase_space(mpf(row["s"]), mpf(config.m))) * im_a)
    min_eig_row = min(blocks, key=lambda row: row["eig_min"])
    min_disk_row = min(blocks, key=lambda row: row["disk_slack"])
    lower_violations = [max(0.0, -float(row["SmIm"])) for row in tail]
    upper_violations = [max(0.0, float(row["SmIm"]) - 2.0) for row in tail]
    tail_worst = max(tail, key=lambda row: row["violation"])
    q0_verified = float(q0 @ z)
    q2_verified = float(q2 @ z)
    objective_verified = None if target == "feasibility" else (q0_verified if target.startswith("g0") else q2_verified)
    reported_objective = diagnostics.get("objective")
    objective_difference = "NOT_APPLICABLE" if objective_verified is None or reported_objective is None else abs(float(reported_objective) - objective_verified)
    finite_pass = bool(
        np.all(np.isfinite(z)) and np.all(np.isfinite(a_coeff @ z)) and np.all(np.isfinite(b_coeff @ z))
        and re_im_finite and lmi_entries_finite and math.isfinite(q0_verified) and math.isfinite(q2_verified)
    )
    lmi_fail_count = sum(row["eig_state"] == "FAIL" for row in blocks)
    disk_fail_count = sum(row["disk_state"] == "FAIL" for row in blocks)
    tail_pass = float(verification["tail_max_violation"]) <= 10.0 * SolverConfig().eps_abs
    return {
        "finite_check_pass": finite_pass,
        "all_z_finite": bool(np.all(np.isfinite(z))),
        "all_re_a_finite": bool(np.all(np.isfinite(a_coeff @ z))),
        "all_im_a_finite": bool(np.all(np.isfinite(b_coeff @ z))),
        "all_lmi_entries_finite": lmi_entries_finite,
        "g0_finite": math.isfinite(q0_verified),
        "g2_finite": math.isfinite(q2_verified),
        "lmi_block_count": len(blocks),
        "minimum_lmi_eigenvalue": float(min_eig_row["eig_min"]),
        "worst_lmi_block": {"ell": min_eig_row["ell"], "s_index": min_eig_row["s_index"], "s": min_eig_row["s"], "eigenvalues": np.linalg.eigvalsh(unitarity_matrix(min_eig_row["re_a"], min_eig_row["im_a"], min_eig_row["s"], config.m)).tolist()},
        "lmi_fail_count_under_existing_three_way_rule": lmi_fail_count,
        "lmi_check_pass": lmi_fail_count == 0 and float(verification["min_lmi_eigenvalue"]) >= -10.0 * SolverConfig().eps_abs,
        "minimum_disk_slack": float(min_disk_row["disk_slack"]),
        "worst_disk_block": {"ell": min_disk_row["ell"], "s_index": min_disk_row["s_index"], "s": min_disk_row["s"], "re_a": min_disk_row["re_a"], "im_a": min_disk_row["im_a"], "disk_slack": min_disk_row["disk_slack"]},
        "disk_fail_count_under_existing_three_way_rule": disk_fail_count,
        "disk_check_pass": disk_fail_count == 0,
        "psd_disk_disagreement_count": int(verification["hard_mismatch_count"]),
        "boundary_block_count": int(verification["boundary_block_count"]),
        "min_im_a": min_im,
        "max_Sm_im_a": max_sm_im,
        "tail_constraint_count": 2 * len(tail),
        "max_tail_lower_violation": max(lower_violations, default=0.0),
        "max_tail_upper_violation": max(upper_violations, default=0.0),
        "max_tail_violation": float(verification["tail_max_violation"]),
        "worst_tail_constraint": tail_worst,
        "tail_check_pass": tail_pass,
        "g0_verified": q0_verified,
        "g2_verified": q2_verified,
        "objective_reconstructed": "NOT_APPLICABLE" if objective_verified is None else objective_verified,
        "objective_difference_abs": objective_difference,
        "objective_consistency_acceptance": "diagnostic_only",
    }


def solve_one(solve_id: int, target: str, sense: str, filename: str, matrices: dict[str, object], config: Stage0Config, q0: np.ndarray, q2: np.ndarray) -> dict[str, Any]:
    started = perf_counter()
    try:
        diagnostics = solve_problem(matrices, config, q0, q2, target=target)
        verifier = independent_summary(diagnostics, matrices, config, q0, q2, target)
        accepted = all([
            verifier["finite_check_pass"], verifier["lmi_check_pass"], verifier["disk_check_pass"],
            verifier["tail_check_pass"], verifier["psd_disk_disagreement_count"] == 0,
        ])
        payload = {
            "schema_version": "1.0", "solve_id": solve_id, "objective_name": target, "objective_sense": sense,
            "status": "PASS" if accepted else "STOP", "accepted": accepted,
            "solver": diagnostics.get("solver_name", "SCS"), "solver_version": scs.__version__,
            "cvxpy_version": cvxpy.__version__, "solver_options": diagnostics.get("solver_config", asdict(SolverConfig())),
            "solver_status": diagnostics.get("status", "NOT_REPORTED"), "raw_solver_status": diagnostics.get("status", "NOT_REPORTED"),
            "objective_value": json_value(diagnostics.get("objective")),
            "primal_residual": json_value(diagnostics.get("primal_residual")), "dual_residual": json_value(diagnostics.get("dual_residual")),
            "duality_gap": json_value(diagnostics.get("gap")), "iteration_count": json_value(diagnostics.get("num_iters")),
            "solve_time": json_value(diagnostics.get("solve_time")), "wall_elapsed_seconds": perf_counter() - started,
            "z": diagnostics["z"], "g0": diagnostics["g0"], "g2": diagnostics["g2"],
            "independent_verifier": verifier,
        }
        write_json(ROOT / filename, payload)
        if not accepted:
            raise RuntimeError(f"independent verifier rejected {target}")
        return payload
    except SolverStop as exc:
        payload = {
            "schema_version": "1.0", "solve_id": solve_id, "objective_name": target, "objective_sense": sense,
            "status": "STOP", "accepted": False, "failure_type": type(exc).__name__, "failure_reason": str(exc),
            "solver": exc.diagnostics.get("solver_name", "SCS"), "solver_version": scs.__version__,
            "cvxpy_version": cvxpy.__version__, "solver_options": exc.diagnostics.get("solver_config", asdict(SolverConfig())),
            "solver_status": exc.diagnostics.get("status", "NOT_REPORTED"), "raw_solver_status": exc.diagnostics.get("status", "NOT_REPORTED"),
            "objective_value": json_value(exc.diagnostics.get("objective")), "primal_residual": json_value(exc.diagnostics.get("primal_residual")),
            "dual_residual": json_value(exc.diagnostics.get("dual_residual")), "duality_gap": json_value(exc.diagnostics.get("gap")),
            "iteration_count": json_value(exc.diagnostics.get("num_iters")), "solve_time": json_value(exc.diagnostics.get("solve_time")),
            "wall_elapsed_seconds": perf_counter() - started, "z": exc.diagnostics.get("z", "NOT_REPORTED"),
        }
        write_json(ROOT / filename, payload)
        raise


def result_payload(preflight_result: dict[str, Any], solves: list[dict[str, Any]], failure: dict[str, Any] | None) -> dict[str, Any]:
    accepted = [row for row in solves if row.get("accepted") is True]
    by_target = {row["objective_name"]: row for row in accepted}
    completed_all = len(solves) == 5 and len(accepted) == 5 and failure is None
    ranges_ok = completed_all and by_target["g0_min"]["g0"] <= by_target["g0_max"]["g0"] and by_target["g2_min"]["g2"] <= by_target["g2_max"]["g2"]
    pass_gate = bool(completed_all and ranges_ok)
    verifiers = [row["independent_verifier"] for row in accepted]
    residuals_primal = [row["primal_residual"] for row in solves if isinstance(row.get("primal_residual"), (int, float))]
    residuals_dual = [row["dual_residual"] for row in solves if isinstance(row.get("dual_residual"), (int, float))]
    return {
        "schema_version": "1.0", "status": "PASS" if pass_gate else "STOP", "config_id": "STAGE0_V3_SMOKE_SDP_GATE2",
        "preregistered_sha256": preflight_result["preregistered_sha256"], "gate1_evidence_sha256": preflight_result["gate1_evidence_sha256"],
        "linear_solve_recovery_sha256": preflight_result["linear_solve_recovery_sha256"],
        "expected_solve_count": 5, "completed_solve_count": len(solves), "accepted_solve_count": len(accepted),
        "solve_results": [{"solve_id": row["solve_id"], "objective_name": row["objective_name"], "status": row["status"], "accepted": row["accepted"], "file": SOLVE_PLAN[row["solve_id"] - 1][3]} for row in solves],
        "not_started": [target for _, target, _, _ in SOLVE_PLAN[len(solves):]], "first_failure": failure,
        "g0_min": by_target.get("g0_min", {}).get("g0", "NOT_AVAILABLE"), "g0_max": by_target.get("g0_max", {}).get("g0", "NOT_AVAILABLE"),
        "g2_min": by_target.get("g2_min", {}).get("g2", "NOT_AVAILABLE"), "g2_max": by_target.get("g2_max", {}).get("g2", "NOT_AVAILABLE"),
        "min_max_sanity_pass": ranges_ok if completed_all else "NOT_RUN",
        "worst_lmi_eigenvalue": min((row["minimum_lmi_eigenvalue"] for row in verifiers), default="NOT_AVAILABLE"),
        "worst_disk_slack": min((row["minimum_disk_slack"] for row in verifiers), default="NOT_AVAILABLE"),
        "psd_disk_disagreement_count": sum((row["psd_disk_disagreement_count"] for row in verifiers), start=0),
        "max_tail_violation": max((row["max_tail_violation"] for row in verifiers), default="NOT_AVAILABLE"),
        "max_primal_residual": max(residuals_primal, default="NOT_REPORTED"), "max_dual_residual": max(residuals_dual, default="NOT_REPORTED"),
        "sdp_solve_count": len(solves), "figure_1_started": False, "fractional_subtraction_started": False,
        "scientific_settings_changed": False, "automatic_retry_performed": False,
        "package_verification": "PASS" if pass_gate else "PENDING_STOP_PACKAGE_CHECK",
        "decision": "STAGE0_V3_SMOKE_SDP_GATE2 = PASS" if pass_gate else "STAGE0_V3_SMOKE_SDP_GATE2 = STOP",
        "claim_boundary": "PASS means SDP infrastructure is operational at smoke scale on frozen V3 data; it does not mean Figure 1 reproduction or boundary convergence.",
    }


def write_reports(result: dict[str, Any]) -> None:
    is_pass = result["status"] == "PASS"
    readme = f"""# STAGE0_V3_SMOKE_SDP_GATE2\n\nStatus: **{result['status']}**\n\nThis audit reused the frozen Stage-0 V3 Gate 1 artifacts and executed exactly {result['sdp_solve_count']} of 5 preregistered CVXPY/SCS smoke solves. Dispersion coefficients, Test I, and the high-precision linear solve were not recomputed.\n\n- Gate 1 evidence: PASS\n- Accepted solves: {result['accepted_solve_count']} / 5\n- Figure 1 started: false\n- Fractional subtraction started: false\n- Scientific settings changed: false\n- Automatic retry: false\n\nA PASS means only that SDP construction, the frozen SCS path, the independent verifier, and the g0/g2 objective maps are operational at smoke scale. It does not establish Figure 1 reproduction, boundary convergence, or paper-level precision.\n"""
    postmortem = f"""# POSTMORTEM\n\n## Decision\n\n`{result['decision']}`\n\n## Execution\n\nCompleted {result['completed_solve_count']} / 5 solves; accepted {result['accepted_solve_count']} / 5. First failure: {json.dumps(result['first_failure'], ensure_ascii=False)}.\n\nThe run stopped after the preregistered Gate 2 scope. No theta scan, additional direction, Figure 1 work, fractional subtraction, Regge analysis, scientific-parameter change, or automatic retry was performed. Gate 1 remains PASS independently of this Gate 2 result.\n\n## Claim boundary\n\n{result['claim_boundary']}\n"""
    (ROOT / "README.md").write_text(readme, encoding="utf-8")
    (ROOT / "POSTMORTEM.md").write_text(postmortem, encoding="utf-8")


def write_provenance() -> None:
    payload = {
        "schema_version": "1.0", "external_inputs": {name: {"path": str(path), "sha256": sha256(path)} for name, path in INPUTS.items()},
        "local_execution_code": {name: sha256(ROOT / name) for name in ("run_gate2.py", "verify_package.py")},
        "code_roles": {"solver_construction_and_tail_constraints": "source_sdp", "independent_verifier": "source_core", "g0_g2_map_implementation": "source_dispersion", "scientific_config": "source_config"},
        "dependency_versions": {"python": sys.version, "cvxpy": cvxpy.__version__, "scs": scs.__version__, "numpy": np.__version__},
    }
    write_json(ROOT / "PROVENANCE_SHA256.json", payload)


def write_manifest() -> None:
    files = sorted(path for path in ROOT.iterdir() if path.is_file() and path.name != "MANIFEST_SHA256.txt" and not path.name.endswith(".tmp"))
    text = "".join(f"{sha256(path)}  {path.name}\n" for path in files)
    (ROOT / "MANIFEST_SHA256.txt").write_text(text, encoding="utf-8")


def main() -> int:
    started = perf_counter()
    solves: list[dict[str, Any]] = []
    failure: dict[str, Any] | None = None
    preflight_result: dict[str, Any] | None = None
    try:
        preflight_result, config, matrices, q0, q2 = preflight()
        for solve_id, target, sense, filename in SOLVE_PLAN:
            try:
                row = solve_one(solve_id, target, sense, filename, matrices, config, q0, q2)
                solves.append(row)
                print(json.dumps({"solve_id": solve_id, "target": target, "status": row["status"], "elapsed_seconds": row["wall_elapsed_seconds"]}), flush=True)
            except Exception as exc:
                if (ROOT / filename).is_file():
                    solves.append(load_json(ROOT / filename))
                failure = {"solve_id": solve_id, "objective_name": target, "exception_type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
                break
    except Exception as exc:
        failure = {"stage": "preflight", "exception_type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        if (ROOT / "preflight_validation.json").is_file():
            preflight_result = load_json(ROOT / "preflight_validation.json")

    if preflight_result is None:
        preflight_result = {"preregistered_sha256": sha256(PREREG), "gate1_evidence_sha256": "NOT_VERIFIED", "linear_solve_recovery_sha256": "NOT_VERIFIED"}
    result = result_payload(preflight_result, solves, failure)
    result["wall_elapsed_seconds"] = perf_counter() - started
    write_json(ROOT / "smoke_sdp_gate2_result.json", result)
    write_reports(result)
    write_provenance()
    write_manifest()
    verifier = subprocess.run([sys.executable, "-B", str(ROOT / "verify_package.py")], cwd=ROOT, text=True, capture_output=True)
    print(verifier.stdout, end="")
    if verifier.stderr:
        print(verifier.stderr, file=sys.stderr, end="")
    if result["status"] == "PASS" and verifier.returncode == 0:
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
