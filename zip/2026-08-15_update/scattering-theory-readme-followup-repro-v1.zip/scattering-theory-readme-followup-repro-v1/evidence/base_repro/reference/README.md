# Projected curvature second-order read-only analysis

Status: **COMPLETE**  
Classification: **PARTIALLY_EXPLAINED**  
Source support solves: **38**  
New solver runs: **0**

## Main result

The number 47 is primarily the frozen map's `ell=0` sigma-mode scale, not a raw `z0` coefficient norm.  On the saved grid, the `ell=0` imaginary-amplitude map `B0` represents `sigma(s)` with relative residual `1.318e-14`.  If `B0*c_sigma=sigma`, then

`kappa_sigma = q2_ell0 dot c_sigma = 0.00528029695417`,

and the unitarity-disk expansion with `x1=2*a1` gives

`rho_sigma = 1/(4*kappa_sigma) = 47.345822057`.

This predicts the saved 270-degree fit `47.342661329` with relative radius residual `-0.00668%`.  The 90-degree fit is `47.137903984`, a `+0.44108%` correction in quadratic coefficient from the same base scale.

## Why the top mechanism can differ

At the representative saved offset `0.010986328125` degrees, `z0` contributes exactly zero to `b2` because `q2[0]=0`.  Thus a strict `z0`-only projected path has zero curvature (infinite radius); all finite projected curvature is supplied by rest modes.

For 90 degrees the saved `b2` group contributions are `+17.470546`, `-77.653383`, and `+36.330584` for ell=0,2,4, summing to `-23.852253`.  Their gross-to-net cancellation is `81.86%`.  Relative to the reflected universal ell=0 baseline, the cross-ell correction cancels by `99.84%` at this offset.

The 13 top boundary blocks are also effectively low rank in unweighted physical disk demand: the two leading ell=0 blocks carry `95.81%`, and all four ell=0 boundary blocks carry `99.78%`.  At 270 degrees there are 89 boundary blocks, but essentially `100.00000000%` of the first-order quadratic disk demand is ell=0; the ell=2 and ell=4 apex blocks have negligible first-order demand.

## Claim boundary

The common 47.3458 base scale is structurally explained.  The upper cap's remaining 0.44% coefficient correction is measured but not forced by an identified identity: the saved solve records contain no dual multipliers, and an exact full-feasible-set complement symmetry was previously rejected.  Constraint rankings in the CSV are therefore unweighted kinematic disk-demand rankings, not KKT-weighted causal shares.
