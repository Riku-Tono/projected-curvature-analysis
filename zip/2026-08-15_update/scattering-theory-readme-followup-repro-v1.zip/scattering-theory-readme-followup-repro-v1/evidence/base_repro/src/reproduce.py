from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


PROJECTION_OFFSETS = [0.0439453125, 0.02197265625, 0.010986328125, 0.0054931640625]
REPRESENTATIVE_OFFSET = 0.010986328125
ALL_RESPONSE_OFFSETS = [
    0.087890625,
    0.0439453125,
    0.02197265625,
    0.010986328125,
    0.0054931640625,
    0.00274658203125,
    0.001373291015625,
]
CLAIM_BOUNDARY = (
    "The analysis decomposes the saved finite-grid response and identifies coordinate-invariant identities "
    "of the frozen linear map. It does not infer continuum-limit curvature, assign KKT dual weights that "
    "were not saved, or prove an exact full-feasible-set involution."
)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def load_rows(solves_dir: Path) -> dict[tuple[float, float], dict[str, Any]]:
    rows: dict[tuple[float, float], dict[str, Any]] = {}
    for path in solves_dir.glob("solve_*.json"):
        row = load_json(path)
        rows[(float(row["axis_degrees"]), float(row["offset_degrees"]))] = row
    if len(rows) != 38:
        raise ValueError(f"Expected 38 solve records, found {len(rows)}")
    if not all(row["status"] == "PASS" for row in rows.values()):
        raise ValueError("At least one saved solve record is not PASS")
    return rows


def projection_fit(axis: float, rows: dict[tuple[float, float], dict[str, Any]]) -> dict[str, float]:
    center = rows[(axis, 0.0)]
    x_values: list[float] = []
    y_values: list[float] = []
    for offset in PROJECTION_OFFSETS:
        for sign in (-1.0, 1.0):
            row = rows[(axis, sign * offset)]
            x_values.append(float(row["g0"] - center["g0"]))
            normal = center["g2"] - row["g2"] if axis == 90.0 else row["g2"] - center["g2"]
            y_values.append(float(normal))
    x = np.asarray(x_values)
    y = np.asarray(y_values)
    x2 = x * x
    coefficient = float(np.dot(x2, y) / np.dot(x2, x2))
    residual = y - coefficient * x2
    return {
        "quadratic_coefficient_C": coefficient,
        "signed_normal_second_derivative_per_tangent_speed_squared": 2.0 * coefficient,
        "radius": 1.0 / (2.0 * coefficient),
        "curvature": 2.0 * coefficient,
        "rms_residual": float(np.sqrt(np.mean(residual * residual))),
        "max_abs_residual": float(np.max(np.abs(residual))),
    }


def response_at_offset(
    axis: float,
    offset_degrees: float,
    rows: dict[tuple[float, float], dict[str, Any]],
    q0: np.ndarray,
    q2: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, dict[str, float]]:
    delta = math.radians(offset_degrees)
    center = np.asarray(rows[(axis, 0.0)]["z"], dtype=float)
    plus = np.asarray(rows[(axis, offset_degrees)]["z"], dtype=float)
    minus = np.asarray(rows[(axis, -offset_degrees)]["z"], dtype=float)
    first = (plus - minus) / (2.0 * delta)
    second = (plus + minus - 2.0 * center) / (2.0 * delta * delta)
    a1 = float(q0 @ first)
    b1 = float(q2 @ first)
    a2 = float(q0 @ second)
    b2 = float(q2 @ second)
    numerator = abs(2.0 * (a1 * b2 - b1 * a2))
    speed2 = a1 * a1 + b1 * b1
    return first, second, {
        "offset_degrees": offset_degrees,
        "a1": a1,
        "b1": b1,
        "a2": a2,
        "b2": b2,
        "parametric_radius": speed2 ** 1.5 / numerator if numerator else math.inf,
        "vertical_cap_radius_approximation": a1 * a1 / (2.0 * abs(b2)) if b2 else math.inf,
    }


def boundary_keys(
    center: np.ndarray,
    a_coeff: np.ndarray,
    b_coeff: np.ndarray,
    s_grid: np.ndarray,
    ell_list: np.ndarray,
    m: float,
) -> set[tuple[int, int]]:
    keys: set[tuple[int, int]] = set()
    for ell_index, ell in enumerate(ell_list):
        for s_index, s in enumerate(s_grid):
            sigma = math.sqrt((float(s) - 4.0 * m * m) / float(s))
            re_a = float(a_coeff[ell_index, s_index] @ center)
            im_a = float(b_coeff[ell_index, s_index] @ center)
            matrix = np.array(
                [[1.0 - 0.5 * sigma * im_a, math.sqrt(sigma) * re_a], [math.sqrt(sigma) * re_a, 2.0 * im_a]],
                dtype=np.float64,
            )
            eig_min = float(np.linalg.eigvalsh(matrix)[0])
            disk = 2.0 * im_a - sigma * (re_a * re_a + im_a * im_a)
            norm2 = float(np.linalg.norm(matrix, 2))
            eig_tol = 1e-7 + 1e-7 * max(1.0, norm2)
            disk_tol = 1e-7 + 1e-7 * max(1.0, norm2 * norm2)
            if abs(eig_min) <= eig_tol or abs(disk) <= disk_tol:
                keys.add((int(ell), s_index))
    return keys


def reproduce(inputs_dir: Path, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    if any(output_dir.iterdir()):
        raise ValueError(f"Output directory must be empty: {output_dir}")
    rows = load_rows(inputs_dir / "solves")
    with np.load(inputs_dir / "frozen_maps.npz", allow_pickle=False) as maps:
        a_coeff = np.asarray(maps["a_coeff"], dtype=float)
        b_coeff = np.asarray(maps["b_coeff"], dtype=float)
        s_grid = np.asarray(maps["s_grid"], dtype=float)
        q0 = np.asarray(maps["q0"], dtype=float)
        q2 = np.asarray(maps["q2"], dtype=float)
        ell_list = np.asarray(maps["ell_list"], dtype=int)
        m = float(maps["m"][0])
        n_vars = int(maps["n_vars"][0])
    sigma = np.sqrt((s_grid - 4.0 * m * m) / s_grid)
    groups = {
        "z0": np.asarray([0], dtype=int),
        "ell0_spectral": np.arange(1, 6),
        "ell2": np.arange(6, 11),
        "ell4": np.arange(11, 16),
    }

    projection = {"90": projection_fit(90.0, rows), "270": projection_fit(270.0, rows)}
    b0 = b_coeff[0][:, groups["ell0_spectral"]]
    q2_ell0 = q2[groups["ell0_spectral"]]
    c_sigma, _, rank_b0, _ = np.linalg.lstsq(b0, sigma, rcond=None)
    sigma_reconstruction = b0 @ c_sigma
    kappa_sigma = float(q2_ell0 @ c_sigma)
    universal_c = 2.0 * kappa_sigma
    universal_radius = 1.0 / (4.0 * kappa_sigma)
    sigma_identity = {
        "b0_rank": int(rank_b0),
        "sigma_reconstruction_relative_residual": float(np.linalg.norm(sigma_reconstruction - sigma) / np.linalg.norm(sigma)),
        "sigma_reconstruction_max_abs_residual": float(np.max(np.abs(sigma_reconstruction - sigma))),
        "kappa_sigma_q2_dot_c_sigma": kappa_sigma,
        "universal_projection_quadratic_coefficient_2_kappa_sigma": universal_c,
        "universal_radius_1_over_4_kappa_sigma": universal_radius,
        "derivation": "B0*c_sigma=sigma; disk y2=(sigma/2)*x1^2 with x1=2*a1 gives b2=2*kappa_sigma*a1^2 and rho=a1^2/(2*abs(b2))=1/(4*kappa_sigma).",
    }
    for key in ("90", "270"):
        projection[key]["coefficient_relative_to_universal"] = projection[key]["quadratic_coefficient_C"] / universal_c
        projection[key]["coefficient_relative_correction"] = projection[key]["quadratic_coefficient_C"] / universal_c - 1.0
        projection[key]["radius_relative_to_universal"] = projection[key]["radius"] / universal_radius

    sensitivity_rows: list[dict[str, Any]] = []
    representative: dict[str, dict[str, Any]] = {}
    physical_map = np.concatenate([a_coeff.reshape(-1, n_vars), b_coeff.reshape(-1, n_vars)], axis=0)
    mode_rows: list[dict[str, Any]] = []
    for axis in (90.0, 270.0):
        for offset in ALL_RESPONSE_OFFSETS:
            _, _, coeff = response_at_offset(axis, offset, rows, q0, q2)
            sensitivity_rows.append({"axis_degrees": axis, **coeff})
        first, second, coeff = response_at_offset(axis, REPRESENTATIVE_OFFSET, rows, q0, q2)
        sign = -1.0 if axis == 90.0 else 1.0
        b2_universal = sign * 2.0 * kappa_sigma * coeff["a1"] ** 2
        full_amplitude = physical_map @ first
        group_details: dict[str, Any] = {}
        for name, indices in groups.items():
            mask = np.zeros(n_vars)
            mask[indices] = 1.0
            first_group = first * mask
            second_group = second * mask
            details = {
                "b1_contribution": float(q2 @ first_group),
                "b2_contribution": float(q2 @ second_group),
                "signed_curvature_contribution_2b2_over_a1_squared": 2.0 * float(q2 @ second_group) / coeff["a1"] ** 2,
                "first_order_physical_amplitude_norm": float(np.linalg.norm(physical_map @ first_group)),
                "first_order_physical_amplitude_norm_over_full": float(np.linalg.norm(physical_map @ first_group) / np.linalg.norm(full_amplitude)),
            }
            group_details[name] = details
            mode_rows.append({"axis_degrees": axis, "group": name, **details})
        rest_names = ("ell0_spectral", "ell2", "ell4")
        gross_b1 = sum(abs(group_details[name]["b1_contribution"]) for name in rest_names)
        gross_b2 = sum(abs(group_details[name]["b2_contribution"]) for name in rest_names)
        baseline_delta = {
            "ell0_spectral_minus_universal_baseline": group_details["ell0_spectral"]["b2_contribution"] - b2_universal,
            "ell2": group_details["ell2"]["b2_contribution"],
            "ell4": group_details["ell4"]["b2_contribution"],
        }
        gross_baseline_delta = sum(abs(value) for value in baseline_delta.values())
        representative[str(int(axis))] = {
            **coeff,
            "groups": group_details,
            "full_first_order_physical_amplitude_norm": float(np.linalg.norm(full_amplitude)),
            "first_order_q2_cancellation_fraction": 1.0 - abs(coeff["b1"]) / gross_b1,
            "second_order_q2_cancellation_fraction": 1.0 - abs(coeff["b2"]) / gross_b2,
            "universal_b2_prediction": b2_universal,
            "actual_minus_universal_b2": coeff["b2"] - b2_universal,
            "actual_minus_universal_relative": (coeff["b2"] - b2_universal) / abs(b2_universal),
            "baseline_delta_by_group": baseline_delta,
            "baseline_delta_cancellation_fraction": 1.0 - abs(sum(baseline_delta.values())) / gross_baseline_delta,
            "z0_only_projected_b2": 0.0,
            "z0_only_projected_curvature": 0.0,
            "z0_only_projected_radius": "INFINITE",
        }

    with (output_dir / "taylor_coefficients.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(sensitivity_rows[0].keys()))
        writer.writeheader()
        writer.writerows(sensitivity_rows)
    with (output_dir / "mode_group_curvature_contributions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(mode_rows[0].keys()))
        writer.writeheader()
        writer.writerows(mode_rows)

    disk_rows: list[dict[str, Any]] = []
    disk_summary: dict[str, Any] = {}
    for axis in (90.0, 270.0):
        first, second, _ = response_at_offset(axis, REPRESENTATIVE_OFFSET, rows, q0, q2)
        center = np.asarray(rows[(axis, 0.0)]["z"], dtype=float)
        active = boundary_keys(center, a_coeff, b_coeff, s_grid, ell_list, m)
        z0_first = np.zeros_like(first)
        z0_first[0] = first[0]
        axis_rows: list[dict[str, Any]] = []
        for ell_index, ell in enumerate(ell_list):
            for s_index, s in enumerate(s_grid):
                if (int(ell), s_index) not in active:
                    continue
                x0 = float(a_coeff[ell_index, s_index] @ center)
                y0 = float(b_coeff[ell_index, s_index] @ center)
                x1 = float(a_coeff[ell_index, s_index] @ first)
                y1 = float(b_coeff[ell_index, s_index] @ first)
                x2 = float(a_coeff[ell_index, s_index] @ second)
                y2 = float(b_coeff[ell_index, s_index] @ second)
                x1_z0 = float(a_coeff[ell_index, s_index] @ z0_first)
                y1_z0 = float(b_coeff[ell_index, s_index] @ z0_first)
                sig = float(sigma[s_index])
                demand = sig * (x1 * x1 + y1 * y1)
                z0_demand = sig * (x1_z0 * x1_z0 + y1_z0 * y1_z0)
                supply = 2.0 * (1.0 - sig * y0) * y2 - 2.0 * sig * x0 * x2
                axis_rows.append({
                    "axis_degrees": axis,
                    "ell": int(ell),
                    "s_index": s_index,
                    "s": float(s),
                    "sigma": sig,
                    "x0": x0,
                    "y0": y0,
                    "x1": x1,
                    "y1": y1,
                    "x2": x2,
                    "y2": y2,
                    "full_quadratic_demand": demand,
                    "z0_only_quadratic_demand": z0_demand,
                    "second_order_supply": supply,
                    "supply_minus_demand": supply - demand,
                    "supply_over_demand": supply / demand if demand > 1e-20 else math.nan,
                })
        axis_rows.sort(key=lambda row: row["full_quadratic_demand"], reverse=True)
        total_demand = sum(row["full_quadratic_demand"] for row in axis_rows)
        cumulative = 0.0
        for rank, row in enumerate(axis_rows, start=1):
            cumulative += row["full_quadratic_demand"]
            row["demand_rank"] = rank
            row["unweighted_demand_share"] = row["full_quadratic_demand"] / total_demand
            row["cumulative_unweighted_demand_share"] = cumulative / total_demand
        disk_rows.extend(axis_rows)
        demands = np.asarray([row["full_quadratic_demand"] for row in axis_rows])
        ell_sums = {str(int(ell)): sum(row["full_quadratic_demand"] for row in axis_rows if row["ell"] == int(ell)) for ell in ell_list}
        disk_summary[str(int(axis))] = {
            "boundary_block_count": len(axis_rows),
            "total_unweighted_full_quadratic_demand": total_demand,
            "total_unweighted_z0_only_quadratic_demand": sum(row["z0_only_quadratic_demand"] for row in axis_rows),
            "full_over_z0_only_demand_ratio": total_demand / sum(row["z0_only_quadratic_demand"] for row in axis_rows),
            "unweighted_demand_by_ell": ell_sums,
            "ell0_demand_share": ell_sums["0"] / total_demand,
            "top_two_constraint_demand_share": sum(row["full_quadratic_demand"] for row in axis_rows[:2]) / total_demand,
            "effective_participation_count": float(total_demand * total_demand / np.dot(demands, demands)),
            "ranking_boundary": "Ranks use unweighted physical disk quadratic demand sigma*(x1^2+y1^2), not absent KKT dual weights; they are kinematic stress ranks, not unique causal curvature allocations.",
        }

    disk_fields = [
        "axis_degrees", "demand_rank", "ell", "s_index", "s", "sigma", "x0", "y0", "x1", "y1", "x2", "y2",
        "full_quadratic_demand", "z0_only_quadratic_demand", "second_order_supply", "supply_minus_demand", "supply_over_demand",
        "unweighted_demand_share", "cumulative_unweighted_demand_share",
    ]
    with (output_dir / "active_disk_quadratic_demand.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=disk_fields)
        writer.writeheader()
        writer.writerows(disk_rows)

    radius_difference = abs(projection["90"]["radius"] - projection["270"]["radius"]) / (
        (projection["90"]["radius"] + projection["270"]["radius"]) / 2.0
    )
    result = {
        "schema_version": "1.0",
        "config_id": "STAGE0_V3_PROJECTED_CURVATURE_SECOND_ORDER_READONLY_V1",
        "status": "COMPLETE",
        "classification": "PARTIALLY_EXPLAINED",
        "source_solve_count": 38,
        "new_solver_runs": 0,
        "source_artifacts_unchanged": True,
        "projected_quadratic_fits": projection,
        "observed_radius_relative_difference": radius_difference,
        "ell0_sigma_mode_identity": sigma_identity,
        "representative_taylor_and_mode_decomposition": representative,
        "active_disk_quadratic_demand_summary": disk_summary,
        "explanation_accounting": {
            "structurally_explained_base_scale": universal_radius,
            "bottom_radius_unexplained_relative_residual": projection["270"]["radius"] / universal_radius - 1.0,
            "top_radius_unexplained_relative_residual": projection["90"]["radius"] / universal_radius - 1.0,
            "top_coefficient_correction_to_universal": projection["90"]["coefficient_relative_correction"],
            "why_not_structurally_explained": "The common 47.3458 scale is exact for the frozen ell=0 sigma mode and explains the lower cap. The upper cap lands within 0.44 percent only after a large cross-ell cancellation. Saved artifacts contain no conic dual multipliers and the previously tested full complement map is infeasible, so no identity was found that forces that cancellation.",
            "why_not_numerical_coincidence_not_explained": "A coordinate-invariant disk/basis identity predicts the shared scale before using either fitted radius and reproduces the lower result to far below one percent; the upper residual is explicitly isolated.",
        },
        "claim_boundary": CLAIM_BOUNDARY,
    }
    write_json(output_dir / "projected_curvature_result.json", result)

    fig, axes = plt.subplots(1, 3, figsize=(14.5, 4.4))
    labels = ["universal\nell0 sigma", "90 fit", "270 fit"]
    radii = [universal_radius, projection["90"]["radius"], projection["270"]["radius"]]
    axes[0].bar(labels, radii, color=["#4c78a8", "#e45756", "#72b7b2"])
    axes[0].set_ylim(46.9, 47.55)
    axes[0].set_ylabel("projected radius")
    axes[0].set_title("Where 47 comes from")
    for index, value in enumerate(radii):
        axes[0].text(index, value + 0.02, f"{value:.4f}", ha="center", fontsize=9)
    top_values = [representative["90"]["groups"][key]["b2_contribution"] for key in ("ell0_spectral", "ell2", "ell4")]
    bottom_values = [representative["270"]["groups"][key]["b2_contribution"] for key in ("ell0_spectral", "ell2", "ell4")]
    x = np.arange(3)
    axes[1].bar(x - 0.18, top_values, width=0.36, label="90", color="#e45756")
    axes[1].bar(x + 0.18, bottom_values, width=0.36, label="270", color="#72b7b2")
    axes[1].axhline(0.0, color="black", linewidth=0.7)
    axes[1].set_xticks(x, ["ell0", "ell2", "ell4"])
    axes[1].set_ylabel("b2 contribution")
    axes[1].set_title("Top reaches -24 by cancellation")
    axes[1].legend(frameon=False)
    top_disk = [row for row in disk_rows if row["axis_degrees"] == 90.0][:6]
    axes[2].barh(
        [f"ell={row['ell']}, s={row['s']:.3f}" for row in reversed(top_disk)],
        [100.0 * row["unweighted_demand_share"] for row in reversed(top_disk)],
        color="#f2cf5b",
    )
    axes[2].set_xlabel("unweighted disk-demand share (%)")
    axes[2].set_title("90 deg active constraints")
    fig.tight_layout()
    fig.savefig(output_dir / "projected_curvature_decomposition.png", dpi=180)
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser(description="Replay the sealed 38-solve projected-curvature analysis without running a solver.")
    package_root = Path(__file__).resolve().parents[1]
    parser.add_argument("--inputs-dir", type=Path, default=package_root / "inputs")
    parser.add_argument("--output-dir", type=Path, default=package_root / "reproduced")
    args = parser.parse_args()
    reproduce(args.inputs_dir.resolve(), args.output_dir.resolve())
    print(f"REPRODUCTION COMPLETE: {args.output_dir.resolve()}")
    print("source_solve_count=38")
    print("new_solver_runs=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
