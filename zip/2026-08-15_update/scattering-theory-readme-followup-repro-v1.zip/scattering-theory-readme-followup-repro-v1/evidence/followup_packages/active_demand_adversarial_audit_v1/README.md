# ACTIVE_DEMAND_CANDIDATE adversarial audit

Status: **COMPLETE**  
Decision: **DOES_NOT_SURVIVE**  
Competitor qualifier: **ELL0_FACE_LEVEL_NOT_PAIR_SPECIFIC**  
Source support solves: **38**  
New solver runs: **0**

## Exact 120-permutation audit

The immutable canonical pair is `((0, 29), (0, 24))`. Its observed normalized LOOCV SSE is `0.289410403`. Exactly `2` of 120 assignments are at least this good, giving finite-ordering tail fraction `0.0166666667`. The absolute-Spearman tail count is `10` of 120 (`0.0833333333`).

## Leave-one-scale-out

The canonical slope retained its sign in `5` of 5 omissions, `|Spearman|>=0.8` held in `5` of 5, and demand beat width in `4` of 5. Preregistered stability: **PASS**.

## Algebraic self-coupling

`p_D` uses only the odd first response `v_h`. The raw-even direction uses only the even second response `u_h`. The original `r_eta` shares `v_h` only through the universal baseline proportional to `a1(v_h)^2`.

The frozen-baseline and raw-even-direction exact primary tails are `0.0666666667` and `0.991666667`; their slope signs are `1` and `-1` versus original `1`. Preregistered self-coupling audit: **FAIL**.

For context, unratioed raw-even eta retains the original slope sign with exact tail `0.0666666667`, while the universal shared-v term alone has exact tail `0.825`. Thus the failure is a strict direction-level robustness failure; it does not show that the shared v term alone manufactures the observed relation.

## Competitor pairs

Center-boundary ell=0 blocks are `[(0, 11), (0, 12), (0, 24), (0, 29)]`, giving `6` unordered pairs. The canonical pair ranks `4` by LOOCV; `6` pairs lie within 10% of its statistic. The familywise minimum-pair tail is `3/120 = 0.025`. This scan is a robustness qualifier only and did not reselect the candidate.

## Claim boundary

The exact tails describe only the ordering of five saved scales. Surviving this audit does not prove causality, KKT support, a population association, or continuum validity. Failing pair specificity would downgrade the interpretation from a two-block mechanism to an ell=0 active-face-level association; it would not authorize selection of a different pair.

## Re-run

`python analyze_adversarial_audit.py`
