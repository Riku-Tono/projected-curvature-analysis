from __future__ import annotations

import csv
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
from typing import Any

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / ".mplconfig"))

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


ROOT = Path(__file__).resolve().parent
SCOPE = ROOT / "ADVERSARIAL_SCOPE.preregistered.json"
WORKSPACE = ROOT.parents[1]
PRIOR = WORKSPACE / "outputs" / "drift_origin_active_demand_readonly_v1"
PRIOR_RESULT = PRIOR / "drift_origin_result.json"
PRIOR_MANIFEST = PRIOR / "MANIFEST_SHA256.txt"
PRIOR_SCOPE = PRIOR / "ANALYSIS_SCOPE.preregistered.json"
PRIOR_DRIFT = PRIOR / "drift_coordinates.csv"
PRIOR_FINGERPRINT = PRIOR / "active_fingerprints.csv"
FIXED_RESULT = WORKSPACE / "outputs" / "near_null_fixed_direction_validation_v1" / "fixed_direction_result.json"
UPSTREAM = Path(
    r"C:\Users\yauki\Documents\Codex\2026-08-15\90-270-face-microscope"
    r"\outputs\stage0_v3_projected_curvature_github_repro_v1"
)
MAPS = UPSTREAM / "inputs" / "frozen_maps.npz"
SOLVES = UPSTREAM / "inputs" / "solves"

EXPECTED_SCOPE_SHA256 = "0CC53B8CC747936B9D39A86F997A761F2606E98809B427BEEE618C96B79522EF"
EXPECTED_PRIOR_RESULT_SHA256 = "5699268E1C88AFB77AA6C1114F54F64258374D97D293E2BD274AA062B88408E0"
EXPECTED_PRIOR_MANIFEST_SHA256 = "4B5B4462976C099CC5C8B017B8D148E6239F6049FA86D34CC0E4FF97B6800F59"
EXPECTED_PRIOR_SCOPE_SHA256 = "2A65FA18C310B6E7F22B9925D26F5E30CD52DF6CCAC2E465E3FDEEED625CA143"
EXPECTED_PRIOR_DRIFT_SHA256 = "5D808A6D35216A70B31FE80380C7D14B568B24B0AFE025B1F0AEC051DC347261"
EXPECTED_PRIOR_FINGERPRINT_SHA256 = "0DF352C69EA12F5CD6C8C576ECE5E5488B81DF256A0FF19DC0D2B8865A1AE344"
EXPECTED_MAPS_SHA256 = "3BBC7A64271C0CFF9B6C53FE76300DEFE14AB2A4EC9675F1C72E5C7132592F95"
EXPECTED_FIXED_RESULT_SHA256 = "C58E3DF0696740912062C2873CF903CE37754679F1404A17708BEB3B826D6C69"

H_DEGREES = [
    0.0439453125,
    0.02197265625,
    0.010986328125,
    0.0054931640625,
    0.00274658203125,
]
REPRESENTATIVE_H = 0.010986328125
CANONICAL_PAIR = ((0, 29), (0, 24))
TAU_ABS = 1.0e-7
TAU_REL = 1.0e-7


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def average_ranks(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    start = 0
    while start < len(values):
        stop = start + 1
        while stop < len(values) and values[order[stop]] == values[order[start]]:
            stop += 1
        ranks[order[start:stop]] = 0.5 * (start + stop - 1) + 1.0
        start = stop
    return ranks


def spearman(x: np.ndarray, y: np.ndarray) -> float:
    rx = average_ranks(x)
    ry = average_ranks(y)
    rx -= np.mean(rx)
    ry -= np.mean(ry)
    denominator = float(np.linalg.norm(rx) * np.linalg.norm(ry))
    return float(np.dot(rx, ry) / denominator) if denominator else math.nan


def linear_loocv(x: np.ndarray, y: np.ndarray) -> dict[str, Any]:
    linear_predictions = np.empty(len(y))
    mean_predictions = np.empty(len(y))
    for test_index in range(len(y)):
        train = np.arange(len(y)) != test_index
        coefficients = np.linalg.lstsq(
            np.column_stack([np.ones(np.sum(train)), x[train]]), y[train], rcond=None
        )[0]
        linear_predictions[test_index] = coefficients[0] + coefficients[1] * x[test_index]
        mean_predictions[test_index] = float(np.mean(y[train]))
    linear_sse = float(np.sum((y - linear_predictions) ** 2))
    mean_sse = float(np.sum((y - mean_predictions) ** 2))
    coefficients = np.linalg.lstsq(
        np.column_stack([np.ones(len(y)), x]), y, rcond=None
    )[0]
    return {
        "intercept": float(coefficients[0]),
        "slope": float(coefficients[1]),
        "spearman": spearman(x, y),
        "normalized_loocv_sse_ratio": linear_sse / mean_sse if mean_sse else math.nan,
        "linear_loocv_sse": linear_sse,
        "training_mean_loocv_sse": mean_sse,
        "linear_predictions": linear_predictions.tolist(),
    }


def exact_permutation(x: np.ndarray, y: np.ndarray) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    observed = linear_loocv(x, y)
    permutations = list(itertools.permutations(range(len(x))))
    rows: list[dict[str, Any]] = []
    for index, permutation in enumerate(permutations):
        metrics = linear_loocv(x[np.asarray(permutation)], y)
        rows.append(
            {
                "permutation_index": index,
                "permutation": ",".join(str(value) for value in permutation),
                "is_observed_identity": permutation == tuple(range(len(x))),
                "normalized_loocv_sse_ratio": metrics["normalized_loocv_sse_ratio"],
                "abs_spearman": abs(metrics["spearman"]),
            }
        )
    q_count = sum(
        row["normalized_loocv_sse_ratio"]
        <= observed["normalized_loocv_sse_ratio"] + 1.0e-15
        for row in rows
    )
    rho_count = sum(
        row["abs_spearman"] >= abs(observed["spearman"]) - 1.0e-15 for row in rows
    )
    summary = {
        **observed,
        "permutation_count": len(rows),
        "primary_tail_count": int(q_count),
        "primary_exact_tail_fraction": q_count / len(rows),
        "secondary_abs_spearman_tail_count": int(rho_count),
        "secondary_exact_tail_fraction": rho_count / len(rows),
        "observed_rank_by_primary_statistic": int(q_count),
    }
    return summary, rows


def boundary_blocks(
    z: np.ndarray,
    a_coeff: np.ndarray,
    b_coeff: np.ndarray,
    s_grid: np.ndarray,
    ell_list: list[int],
    sigma: np.ndarray,
) -> list[tuple[int, int]]:
    output: list[tuple[int, int]] = []
    for ell_index, ell in enumerate(ell_list):
        for s_index in range(len(s_grid)):
            x = float(a_coeff[ell_index, s_index] @ z)
            y = float(b_coeff[ell_index, s_index] @ z)
            matrix = np.asarray(
                [
                    [1.0 - 0.5 * sigma[s_index] * y, math.sqrt(sigma[s_index]) * x],
                    [math.sqrt(sigma[s_index]) * x, 2.0 * y],
                ]
            )
            eig_min = float(np.linalg.eigvalsh(matrix)[0])
            disk_slack = float(2.0 * y - sigma[s_index] * (x * x + y * y))
            norm2 = float(np.linalg.norm(matrix, 2))
            eig_tol = TAU_ABS + TAU_REL * max(1.0, norm2)
            disk_tol = TAU_ABS + TAU_REL * max(1.0, norm2 * norm2)
            if abs(eig_min) <= eig_tol or abs(disk_slack) <= disk_tol:
                output.append((ell, s_index))
    return output


def main() -> int:
    scope = json.loads(SCOPE.read_text(encoding="utf-8"))
    prior_result = json.loads(PRIOR_RESULT.read_text(encoding="utf-8"))
    fixed_result = json.loads(FIXED_RESULT.read_text(encoding="utf-8"))
    preflight = {
        "scope_hash": sha256(SCOPE) == EXPECTED_SCOPE_SHA256,
        "prior_result_hash": sha256(PRIOR_RESULT) == EXPECTED_PRIOR_RESULT_SHA256,
        "prior_manifest_hash": sha256(PRIOR_MANIFEST) == EXPECTED_PRIOR_MANIFEST_SHA256,
        "prior_scope_hash": sha256(PRIOR_SCOPE) == EXPECTED_PRIOR_SCOPE_SHA256,
        "prior_drift_hash": sha256(PRIOR_DRIFT) == EXPECTED_PRIOR_DRIFT_SHA256,
        "prior_fingerprint_hash": sha256(PRIOR_FINGERPRINT)
        == EXPECTED_PRIOR_FINGERPRINT_SHA256,
        "maps_hash": sha256(MAPS) == EXPECTED_MAPS_SHA256,
        "fixed_result_hash": sha256(FIXED_RESULT) == EXPECTED_FIXED_RESULT_SHA256,
        "prior_classification_is_candidate": prior_result["classification"]
        == "ACTIVE_DEMAND_CANDIDATE",
        "scope_new_solver_runs_zero": scope["new_solver_runs"] == 0,
    }

    maps = np.load(MAPS, allow_pickle=False)
    a_coeff = np.asarray(maps["a_coeff"], dtype=float)
    b_coeff = np.asarray(maps["b_coeff"], dtype=float)
    s_grid = np.asarray(maps["s_grid"], dtype=float)
    q0 = np.asarray(maps["q0"], dtype=float)
    q2 = np.asarray(maps["q2"], dtype=float)
    ell_list = [int(value) for value in maps["ell_list"]]
    mass = float(maps["m"][0])
    sigma = np.sqrt((s_grid - 4.0 * mass * mass) / s_grid)

    solve_paths = sorted(SOLVES.glob("solve_*.json"))
    solves: dict[tuple[float, float], dict[str, Any]] = {}
    for path in solve_paths:
        row = json.loads(path.read_text(encoding="utf-8"))
        solves[(float(row["axis_degrees"]), float(row["offset_degrees"]))] = row
    preflight.update(
        {
            "solve_file_count_38": len(solve_paths) == 38,
            "unique_solve_count_38": len(solves) == 38,
            "all_source_status_pass": all(row["status"] == "PASS" for row in solves.values()),
        }
    )
    if not all(preflight.values()):
        write_json(ROOT / "read_only_preflight.json", {"status": "STOP", "checks": preflight})
        return 2

    d_zero = np.asarray(fixed_result["blind_zero_sum_direction"]["direction_unit"], dtype=float)
    d_zero /= np.linalg.norm(d_zero)
    n_hat = np.ones(3) / math.sqrt(3.0)
    d_perp = np.cross(n_hat, d_zero)
    d_perp /= np.linalg.norm(d_perp)
    if np.dot(d_perp, np.asarray([1.0, 0.0, -1.0])) < 0.0:
        d_perp = -d_perp

    b0 = b_coeff[0, :, 1:6]
    c_sigma = np.linalg.lstsq(b0, sigma, rcond=None)[0]
    z0 = np.asarray(solves[(90.0, 0.0)]["z"], dtype=float)
    center_boundary = boundary_blocks(z0, a_coeff, b_coeff, s_grid, ell_list, sigma)
    active_ell0 = sorted(key for key in center_boundary if key[0] == 0)

    responses: list[dict[str, Any]] = []
    v_by_h: dict[float, np.ndarray] = {}
    u_by_h: dict[float, np.ndarray] = {}
    a1_by_h: dict[float, float] = {}
    for h_degrees in H_DEGREES:
        h = math.radians(h_degrees)
        z_plus = np.asarray(solves[(90.0, h_degrees)]["z"], dtype=float)
        z_minus = np.asarray(solves[(90.0, -h_degrees)]["z"], dtype=float)
        v = (z_plus - z_minus) / (2.0 * h)
        u = (z_plus + z_minus - 2.0 * z0) / (2.0 * h * h)
        v_by_h[h_degrees] = v
        u_by_h[h_degrees] = u
        a1_by_h[h_degrees] = float(q0 @ v)

    a1_reference = a1_by_h[REPRESENTATIVE_H]

    def group_vector(vector: np.ndarray) -> np.ndarray:
        return np.asarray(
            [
                q2[1:6] @ vector[1:6],
                q2[6:11] @ vector[6:11],
                q2[11:16] @ vector[11:16],
            ],
            dtype=float,
        )

    def universal(a1: float) -> np.ndarray:
        value = np.zeros(16)
        value[1:6] = -2.0 * a1 * a1 * c_sigma
        return value

    for h_degrees in H_DEGREES:
        v = v_by_h[h_degrees]
        u = u_by_h[h_degrees]
        raw_group = group_vector(u)
        original_group = group_vector(u - universal(a1_by_h[h_degrees]))
        frozen_group = group_vector(u - universal(a1_reference))

        def coordinates(group: np.ndarray) -> tuple[float, float, float]:
            alpha = float(np.dot(group, d_zero))
            eta = float(np.dot(group, d_perp))
            return alpha, eta, eta / alpha

        original_alpha, original_eta, original_r = coordinates(original_group)
        frozen_alpha, frozen_eta, frozen_r = coordinates(frozen_group)
        raw_alpha, raw_eta, raw_r = coordinates(raw_group)
        universal_eta = float(np.dot(group_vector(universal(a1_by_h[h_degrees])), d_perp))
        responses.append(
            {
                "h_degrees": h_degrees,
                "h_radians_squared": math.radians(h_degrees) ** 2,
                "a1": a1_by_h[h_degrees],
                "original_alpha": original_alpha,
                "original_eta": original_eta,
                "original_r_eta": original_r,
                "frozen_baseline_alpha": frozen_alpha,
                "frozen_baseline_eta": frozen_eta,
                "frozen_baseline_r_eta": frozen_r,
                "raw_even_alpha": raw_alpha,
                "raw_even_eta": raw_eta,
                "raw_even_r_eta": raw_r,
                "universal_eta_shared_v_term": universal_eta,
            }
        )

    # Compute demands for all center-active blocks and all h.
    demand_by_block: dict[tuple[int, int], np.ndarray] = {}
    total_active_demand = np.zeros(len(H_DEGREES))
    for key in center_boundary:
        ell, s_index = key
        ell_index = ell_list.index(ell)
        values = []
        for h_degrees in H_DEGREES:
            v = v_by_h[h_degrees]
            x1 = float(a_coeff[ell_index, s_index] @ v)
            y1 = float(b_coeff[ell_index, s_index] @ v)
            values.append(float(sigma[s_index] * (x1 * x1 + y1 * y1)))
        demand_by_block[key] = np.asarray(values)
        total_active_demand += demand_by_block[key]

    canonical_p = demand_by_block[CANONICAL_PAIR[0]] / (
        demand_by_block[CANONICAL_PAIR[0]] + demand_by_block[CANONICAL_PAIR[1]]
    )
    original_y = np.asarray([row["original_r_eta"] for row in responses])
    width_x = np.asarray([row["h_radians_squared"] for row in responses])

    # Verify exact reproduction of the prior sealed rows.
    prior_drift_rows = list(csv.DictReader(PRIOR_DRIFT.open("r", encoding="utf-8", newline="")))
    prior_fingerprint_rows = list(
        csv.DictReader(PRIOR_FINGERPRINT.open("r", encoding="utf-8", newline=""))
    )
    prior_r_eta = np.asarray(
        [
            float(row["r_eta_symmetric"])
            for row in prior_drift_rows
            if float(row["axis_degrees"]) == 90.0
        ]
    )
    prior_p = np.asarray(
        [
            float(row["p_D"])
            for row in prior_fingerprint_rows
            if float(row["axis_degrees"]) == 90.0
        ]
    )
    preflight["reproduced_prior_r_eta"] = bool(
        np.allclose(original_y, prior_r_eta, rtol=0.0, atol=1.0e-14)
    )
    preflight["reproduced_prior_p_D"] = bool(
        np.allclose(canonical_p, prior_p, rtol=0.0, atol=1.0e-14)
    )
    preflight["canonical_pair_unchanged"] = list(CANONICAL_PAIR) == [
        tuple(item) for item in prior_result["fixed_blocks"]["90"]
    ]
    if not all(preflight.values()):
        write_json(ROOT / "read_only_preflight.json", {"status": "STOP", "checks": preflight})
        return 3
    write_json(
        ROOT / "read_only_preflight.json",
        {"status": "PASS", "checks": preflight, "new_solver_runs": 0},
    )

    primary_summary, permutation_rows = exact_permutation(canonical_p, original_y)
    primary_pass = primary_summary["primary_exact_tail_fraction"] <= 0.05

    # Leave-one-scale-out stability.
    full_slope_sign = int(np.sign(primary_summary["slope"]))
    jackknife_rows: list[dict[str, Any]] = []
    for omitted_index, omitted_h in enumerate(H_DEGREES):
        keep = np.arange(len(H_DEGREES)) != omitted_index
        demand_metrics, demand_permutations = exact_permutation(canonical_p[keep], original_y[keep])
        width_metrics = linear_loocv(width_x[keep], original_y[keep])
        jackknife_rows.append(
            {
                "omitted_h_degrees": omitted_h,
                "remaining_count": int(np.sum(keep)),
                "demand_slope": demand_metrics["slope"],
                "demand_slope_sign_matches_full": int(np.sign(demand_metrics["slope"]))
                == full_slope_sign,
                "demand_abs_spearman": abs(demand_metrics["spearman"]),
                "demand_normalized_loocv_sse": demand_metrics[
                    "normalized_loocv_sse_ratio"
                ],
                "width_normalized_loocv_sse": width_metrics["normalized_loocv_sse_ratio"],
                "demand_better_than_width": demand_metrics["normalized_loocv_sse_ratio"]
                < width_metrics["normalized_loocv_sse_ratio"],
                "demand_exact_24_tail_fraction": demand_metrics[
                    "primary_exact_tail_fraction"
                ],
                "demand_exact_24_tail_count": demand_metrics["primary_tail_count"],
            }
        )
    jackknife_pass = (
        all(row["demand_slope_sign_matches_full"] for row in jackknife_rows)
        and sum(row["demand_abs_spearman"] >= 0.8 - 1.0e-15 for row in jackknife_rows) >= 4
        and sum(row["demand_better_than_width"] for row in jackknife_rows) >= 4
    )

    # Algebraic self-coupling audit.
    variant_values = {
        "original": original_y,
        "frozen_baseline": np.asarray([row["frozen_baseline_r_eta"] for row in responses]),
        "raw_even_direction": np.asarray([row["raw_even_r_eta"] for row in responses]),
        "raw_even_eta": np.asarray([row["raw_even_eta"] for row in responses]),
        "universal_eta_shared_v_term": np.asarray(
            [row["universal_eta_shared_v_term"] for row in responses]
        ),
    }
    self_coupling_rows: list[dict[str, Any]] = []
    self_coupling_summaries: dict[str, Any] = {}
    for variant_name, values in variant_values.items():
        summary, _ = exact_permutation(canonical_p, values)
        self_coupling_summaries[variant_name] = summary
        self_coupling_rows.append(
            {
                "variant": variant_name,
                "depends_on_v": variant_name in ("original", "universal_eta_shared_v_term"),
                "depends_on_u": variant_name
                in ("original", "frozen_baseline", "raw_even_direction", "raw_even_eta"),
                "slope": summary["slope"],
                "slope_sign_matches_original": int(np.sign(summary["slope"]))
                == full_slope_sign,
                "spearman": summary["spearman"],
                "normalized_loocv_sse": summary["normalized_loocv_sse_ratio"],
                "exact_primary_tail_count": summary["primary_tail_count"],
                "exact_primary_tail_fraction": summary["primary_exact_tail_fraction"],
            }
        )
    frozen_summary = self_coupling_summaries["frozen_baseline"]
    raw_direction_summary = self_coupling_summaries["raw_even_direction"]
    self_coupling_pass = (
        int(np.sign(frozen_summary["slope"])) == full_slope_sign
        and int(np.sign(raw_direction_summary["slope"])) == full_slope_sign
        and min(
            frozen_summary["primary_exact_tail_fraction"],
            raw_direction_summary["primary_exact_tail_fraction"],
        )
        <= 0.10
    )

    # All unordered pairs among active ell=0 blocks. Pair orientation is fixed by
    # representative-scale demand, largest first; the canonical orientation stays 29 -> 24.
    representative_index = H_DEGREES.index(REPRESENTATIVE_H)
    pair_records: list[dict[str, Any]] = []
    pair_predictors: dict[str, np.ndarray] = {}
    for raw_left, raw_right in itertools.combinations(active_ell0, 2):
        if demand_by_block[raw_left][representative_index] >= demand_by_block[raw_right][
            representative_index
        ]:
            left, right = raw_left, raw_right
        else:
            left, right = raw_right, raw_left
        predictor = demand_by_block[left] / (demand_by_block[left] + demand_by_block[right])
        pair_name = f"ell{left[0]}_s{left[1]}__ell{right[0]}_s{right[1]}"
        pair_predictors[pair_name] = predictor
        summary, _ = exact_permutation(predictor, original_y)
        pair_records.append(
            {
                "pair_name": pair_name,
                "block_1_ell": left[0],
                "block_1_s_index": left[1],
                "block_2_ell": right[0],
                "block_2_s_index": right[1],
                "is_canonical_pair": (left, right) == CANONICAL_PAIR,
                "mean_pair_demand_share": float(
                    np.mean(
                        (demand_by_block[left] + demand_by_block[right]) / total_active_demand
                    )
                ),
                "slope": summary["slope"],
                "abs_spearman": abs(summary["spearman"]),
                "normalized_loocv_sse": summary["normalized_loocv_sse_ratio"],
                "exact_primary_tail_count": summary["primary_tail_count"],
                "exact_primary_tail_fraction": summary["primary_exact_tail_fraction"],
            }
        )
    pair_records.sort(key=lambda row: row["normalized_loocv_sse"])
    for rank, row in enumerate(pair_records, 1):
        row["loocv_rank"] = rank
    canonical_record = next(row for row in pair_records if row["is_canonical_pair"])
    canonical_q = canonical_record["normalized_loocv_sse"]
    within_10_percent_count = sum(
        row["normalized_loocv_sse"] <= 1.1 * canonical_q + 1.0e-15
        for row in pair_records
    )

    # Common permutations across all pairs for the minimum-statistic diagnostic.
    permutation_tuples = list(itertools.permutations(range(len(H_DEGREES))))
    minimum_pair_statistics: list[float] = []
    for permutation in permutation_tuples:
        indices = np.asarray(permutation)
        minimum_pair_statistics.append(
            min(
                linear_loocv(predictor[indices], original_y)["normalized_loocv_sse_ratio"]
                for predictor in pair_predictors.values()
            )
        )
    familywise_count = sum(value <= canonical_q + 1.0e-15 for value in minimum_pair_statistics)
    familywise_fraction = familywise_count / len(minimum_pair_statistics)
    for row, min_stat in zip(permutation_rows, minimum_pair_statistics):
        row["minimum_competitor_pair_normalized_loocv_sse"] = min_stat
        row["any_pair_beats_observed_canonical"] = min_stat <= canonical_q + 1.0e-15

    if not primary_pass:
        specificity_label = "WEAK_MULTIPLE_COMPARISON_ROBUSTNESS"
    elif canonical_record["loocv_rank"] <= 2 and within_10_percent_count <= 2:
        specificity_label = "PAIR_SPECIFIC"
    else:
        specificity_label = "ELL0_FACE_LEVEL_NOT_PAIR_SPECIFIC"

    core_survives = primary_pass and jackknife_pass and self_coupling_pass
    decision = "SURVIVES_ADVERSARIAL_AUDIT" if core_survives else "DOES_NOT_SURVIVE"

    result = {
        "schema_version": "1.0",
        "status": "COMPLETE",
        "decision": decision,
        "competitor_qualifier": specificity_label,
        "source_solve_count": 38,
        "new_solver_runs": 0,
        "canonical_pair_unchanged": [list(item) for item in CANONICAL_PAIR],
        "active_ell0_blocks": [list(item) for item in active_ell0],
        "exact_permutation_primary": primary_summary,
        "leave_one_scale_out": {
            "pass": jackknife_pass,
            "full_slope_sign": full_slope_sign,
            "same_slope_sign_count": int(
                sum(row["demand_slope_sign_matches_full"] for row in jackknife_rows)
            ),
            "abs_spearman_at_least_0p8_count": int(
                sum(row["demand_abs_spearman"] >= 0.8 - 1.0e-15 for row in jackknife_rows)
            ),
            "demand_better_than_width_count": int(
                sum(row["demand_better_than_width"] for row in jackknife_rows)
            ),
        },
        "algebraic_self_coupling": {
            "pass": self_coupling_pass,
            "dependency_audit": {
                "p_D": "odd first response v_h only",
                "raw_even_direction": "even second response u_h only",
                "frozen_baseline": "u_h plus a scale-independent universal vector",
                "original": "u_h plus scale-dependent universal vector using a1(v_h)^2",
            },
            "variant_summaries": self_coupling_summaries,
        },
        "competitor_pair_scan": {
            "pair_count": len(pair_records),
            "canonical_loocv_rank": canonical_record["loocv_rank"],
            "canonical_normalized_loocv_sse": canonical_q,
            "pairs_within_10_percent_of_canonical": within_10_percent_count,
            "minimum_statistic_familywise_tail_count": int(familywise_count),
            "minimum_statistic_familywise_tail_fraction": familywise_fraction,
            "qualifier": specificity_label,
            "canonical_pair_was_not_reselected": True,
        },
        "preregistered_components": {
            "exact_permutation_pass": primary_pass,
            "leave_one_scale_out_pass": jackknife_pass,
            "algebraic_self_coupling_pass": self_coupling_pass,
        },
        "claim_boundary": scope["claim_boundary"],
    }
    write_json(ROOT / "adversarial_audit_result.json", result)
    write_csv(ROOT / "exact_permutation_120.csv", permutation_rows)
    write_csv(ROOT / "leave_one_scale_out.csv", jackknife_rows)
    write_csv(ROOT / "algebraic_self_coupling.csv", self_coupling_rows)
    write_csv(ROOT / "competitor_pair_scan.csv", pair_records)
    write_csv(ROOT / "response_variants.csv", responses)

    write_json(
        ROOT / "PROVENANCE_SHA256.json",
        {
            "schema_version": "1.0",
            "source_solve_count": 38,
            "new_solver_runs": 0,
            "inputs": {
                str(SCOPE): sha256(SCOPE),
                str(PRIOR_RESULT): sha256(PRIOR_RESULT),
                str(PRIOR_MANIFEST): sha256(PRIOR_MANIFEST),
                str(PRIOR_SCOPE): sha256(PRIOR_SCOPE),
                str(PRIOR_DRIFT): sha256(PRIOR_DRIFT),
                str(PRIOR_FINGERPRINT): sha256(PRIOR_FINGERPRINT),
                str(FIXED_RESULT): sha256(FIXED_RESULT),
                str(MAPS): sha256(MAPS),
                **{str(path): sha256(path) for path in solve_paths},
            },
        },
    )

    # Figure.
    figure, axes = plt.subplots(2, 3, figsize=(16.0, 8.5))
    permutation_q = np.asarray([row["normalized_loocv_sse_ratio"] for row in permutation_rows])
    axes[0, 0].hist(permutation_q, bins=20, color="#4c78a8", alpha=0.8)
    axes[0, 0].axvline(primary_summary["normalized_loocv_sse_ratio"], color="#e45756")
    axes[0, 0].set_xlabel("permuted normalized LOOCV SSE")
    axes[0, 0].set_ylabel("count")
    axes[0, 0].set_title("Exact 120-permutation audit")

    omitted = np.arange(5)
    axes[0, 1].plot(
        omitted,
        [row["demand_normalized_loocv_sse"] for row in jackknife_rows],
        "o-",
        label="demand",
    )
    axes[0, 1].plot(
        omitted,
        [row["width_normalized_loocv_sse"] for row in jackknife_rows],
        "o-",
        label="width",
    )
    axes[0, 1].set_xticks(omitted, [f"drop\n{h:.4g}" for h in H_DEGREES])
    axes[0, 1].set_yscale("log")
    axes[0, 1].set_ylabel("normalized LOOCV SSE")
    axes[0, 1].set_title("Leave-one-scale-out stability")
    axes[0, 1].legend(frameon=False)

    variant_names = [row["variant"] for row in self_coupling_rows]
    variant_q = [row["normalized_loocv_sse"] for row in self_coupling_rows]
    axes[0, 2].bar(np.arange(len(variant_names)), variant_q, color="#72b7b2")
    axes[0, 2].axhline(0.5, color="black", linestyle="--", linewidth=0.8)
    axes[0, 2].set_xticks(np.arange(len(variant_names)), variant_names, rotation=25, ha="right")
    axes[0, 2].set_ylabel("normalized LOOCV SSE")
    axes[0, 2].set_title("Algebraic self-coupling audit")

    pair_names = [row["pair_name"] for row in pair_records]
    pair_q = [row["normalized_loocv_sse"] for row in pair_records]
    colors = ["#e45756" if row["is_canonical_pair"] else "#b9b9b9" for row in pair_records]
    axes[1, 0].barh(np.arange(len(pair_names)), pair_q, color=colors)
    axes[1, 0].set_yticks(np.arange(len(pair_names)), pair_names, fontsize=8)
    axes[1, 0].invert_yaxis()
    axes[1, 0].set_xlabel("normalized LOOCV SSE")
    axes[1, 0].set_title("All active ell=0 pairs")

    axes[1, 1].scatter(canonical_p, original_y, color="#e45756")
    fit_line_x = np.linspace(float(np.min(canonical_p)), float(np.max(canonical_p)), 100)
    axes[1, 1].plot(
        fit_line_x,
        primary_summary["intercept"] + primary_summary["slope"] * fit_line_x,
        color="black",
    )
    for x_value, y_value, h_value in zip(canonical_p, original_y, H_DEGREES):
        axes[1, 1].annotate(f"{h_value:.4g}", (x_value, y_value), fontsize=7)
    axes[1, 1].set_xlabel("canonical p_D")
    axes[1, 1].set_ylabel("r_eta")
    axes[1, 1].set_title("Canonical relation kept fixed")

    component_labels = ["permutation", "jackknife", "self-coupling"]
    component_values = [primary_pass, jackknife_pass, self_coupling_pass]
    axes[1, 2].bar(
        np.arange(3),
        [1 if value else 0 for value in component_values],
        color=["#59a14f" if value else "#e15759" for value in component_values],
    )
    axes[1, 2].set_xticks(np.arange(3), component_labels, rotation=20)
    axes[1, 2].set_ylim(0.0, 1.1)
    axes[1, 2].set_yticks([0, 1], ["FAIL", "PASS"])
    axes[1, 2].set_title(f"{decision}\n{specificity_label}")
    figure.tight_layout()
    figure.savefig(ROOT / "adversarial_audit_diagnostics.png", dpi=180)
    plt.close(figure)

    readme = f"""# ACTIVE_DEMAND_CANDIDATE adversarial audit

Status: **COMPLETE**  
Decision: **{decision}**  
Competitor qualifier: **{specificity_label}**  
Source support solves: **38**  
New solver runs: **0**

## Exact 120-permutation audit

The immutable canonical pair is `{CANONICAL_PAIR}`. Its observed normalized LOOCV SSE is `{primary_summary['normalized_loocv_sse_ratio']:.9g}`. Exactly `{primary_summary['primary_tail_count']}` of 120 assignments are at least this good, giving finite-ordering tail fraction `{primary_summary['primary_exact_tail_fraction']:.9g}`. The absolute-Spearman tail count is `{primary_summary['secondary_abs_spearman_tail_count']}` of 120 (`{primary_summary['secondary_exact_tail_fraction']:.9g}`).

## Leave-one-scale-out

The canonical slope retained its sign in `{sum(row['demand_slope_sign_matches_full'] for row in jackknife_rows)}` of 5 omissions, `|Spearman|>=0.8` held in `{sum(row['demand_abs_spearman'] >= 0.8 - 1.0e-15 for row in jackknife_rows)}` of 5, and demand beat width in `{sum(row['demand_better_than_width'] for row in jackknife_rows)}` of 5. Preregistered stability: **{'PASS' if jackknife_pass else 'FAIL'}**.

## Algebraic self-coupling

`p_D` uses only the odd first response `v_h`. The raw-even direction uses only the even second response `u_h`. The original `r_eta` shares `v_h` only through the universal baseline proportional to `a1(v_h)^2`.

The frozen-baseline and raw-even-direction exact primary tails are `{frozen_summary['primary_exact_tail_fraction']:.9g}` and `{raw_direction_summary['primary_exact_tail_fraction']:.9g}`; their slope signs are `{int(np.sign(frozen_summary['slope']))}` and `{int(np.sign(raw_direction_summary['slope']))}` versus original `{full_slope_sign}`. Preregistered self-coupling audit: **{'PASS' if self_coupling_pass else 'FAIL'}**.

For context, unratioed raw-even eta retains the original slope sign with exact tail `{self_coupling_summaries['raw_even_eta']['primary_exact_tail_fraction']:.9g}`, while the universal shared-v term alone has exact tail `{self_coupling_summaries['universal_eta_shared_v_term']['primary_exact_tail_fraction']:.9g}`. Thus the failure is a strict direction-level robustness failure; it does not show that the shared v term alone manufactures the observed relation.

## Competitor pairs

Center-boundary ell=0 blocks are `{active_ell0}`, giving `{len(pair_records)}` unordered pairs. The canonical pair ranks `{canonical_record['loocv_rank']}` by LOOCV; `{within_10_percent_count}` pairs lie within 10% of its statistic. The familywise minimum-pair tail is `{familywise_count}/120 = {familywise_fraction:.9g}`. This scan is a robustness qualifier only and did not reselect the candidate.

## Claim boundary

The exact tails describe only the ordering of five saved scales. Surviving this audit does not prove causality, KKT support, a population association, or continuum validity. Failing pair specificity would downgrade the interpretation from a two-block mechanism to an ell=0 active-face-level association; it would not authorize selection of a different pair.

## Re-run

`python analyze_adversarial_audit.py`
"""
    (ROOT / "README.md").write_text(readme, encoding="utf-8")

    manifest_names = [
        "ADVERSARIAL_SCOPE.preregistered.json",
        "PROVENANCE_SHA256.json",
        "README.md",
        "adversarial_audit_diagnostics.png",
        "adversarial_audit_result.json",
        "algebraic_self_coupling.csv",
        "analyze_adversarial_audit.py",
        "competitor_pair_scan.csv",
        "exact_permutation_120.csv",
        "leave_one_scale_out.csv",
        "read_only_preflight.json",
        "response_variants.csv",
    ]
    (ROOT / "MANIFEST_SHA256.txt").write_text(
        "".join(f"{sha256(ROOT / name)}  {name}\n" for name in manifest_names),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "status": "COMPLETE",
                "decision": decision,
                "qualifier": specificity_label,
                "new_solver_runs": 0,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
