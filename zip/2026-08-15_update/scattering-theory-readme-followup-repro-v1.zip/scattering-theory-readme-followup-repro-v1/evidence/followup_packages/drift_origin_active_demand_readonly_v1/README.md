# Drift origin versus active-demand redistribution

Status: **COMPLETE**  
Classification: **ACTIVE_DEMAND_CANDIDATE**  
Source support solves: **38**  
New solver runs: **0**

## Preregistered decision

- Width/higher-order candidate: **FAIL**
- Active-demand candidate: **PASS**

The primary normalized LOOCV SSE ratios are `4.9402` for the width model `r_eta ~ h^2` and `0.28941` for the fixed-block demand model `r_eta ~ p_D`. A value below 0.5 was required for clear improvement over a leave-one-out training-mean predictor, and the winning model also had to beat the other by a factor of two.

The fixed 90-degree blocks are `[(0, 29), (0, 24)]`. Their representative identities were sealed before analysis and recovered exactly. The mechanically selected 270-degree control blocks are `[(0, 29), (0, 28)]`.

## One-sided audit

For descending `h`, the absolute one-sided `r_eta` gaps are `[0.5981161221806027, 0.25893578017009616, 0.11842430399792295, 0.049668303751591675, 0.018206381059510657]`. The gap decreased on `4` of four steps, and the smallest-h gap divided by the largest-h gap is `0.0304395`. The preregistered side-gap shrink rule therefore **PASS**.

The symmetric estimate was bracketed by the two one-sided estimates at `3` of five scales.

## Active-demand audit

The 90-degree fixed-block demand balances are `[0.7269948383454495, 0.7251807123220368, 0.725965695037354, 0.7258910180706298, 0.7258477327961083]`. Their absolute Spearman correlation with `r_eta` is `0.9`. The demand-model normalized LOOCV ratio for `r_epsilon` is `2.29699`, while the same 270-degree control ratio for `r_eta` is `5.64892`.

The fixed top-two demand share ranges from `95.7085%` to `95.9382%`. Endpoint active-set Jaccard values for plus versus minus are `[0.9230769230769231, 0.9230769230769231, 0.9230769230769231, 1.0, 1.0]`.

For `r_epsilon`, the preregistered width model has normalized LOOCV ratio `0.0787918`, versus `2.29699` for demand balance. Thus the saved data separate the two small effects mechanically: transverse zero-sum drift favors demand redistribution, while observable leakage favors finite-difference width.

The plus/minus endpoint active-set differences are `[{'h_degrees': 0.0439453125, 'plus_only': [[0, 29]], 'minus_only': []}, {'h_degrees': 0.02197265625, 'plus_only': [[0, 29]], 'minus_only': []}, {'h_degrees': 0.010986328125, 'plus_only': [[0, 29]], 'minus_only': []}, {'h_degrees': 0.0054931640625, 'plus_only': [], 'minus_only': []}, {'h_degrees': 0.00274658203125, 'plus_only': [], 'minus_only': []}]`. The only repeated side-specific block at the three larger scales is the dominant `(ell=0,s_index=29)` block; the active sets agree at the two smallest scales.

## Interpretation boundary

This five-scale read-only comparison can identify only a descriptive candidate. A low LOOCV ratio is not a significance result. No model outside the preregistered `h^2` and fixed-block `p_D` primary pair was selected, and the secondary `p_T` and `p_S` results are reported without choosing a winner.

The 270-degree comparison used the same coordinate and mechanical block-selection rule; its center has `89` active blocks rather than `13` at 90 degrees, so it is a structural contrast rather than a matched population sample.

## Re-run

`python analyze_drift_origin.py`
