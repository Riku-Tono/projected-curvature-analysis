from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / ".mplconfig"))

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


ROOT = Path(__file__).resolve().parent
PREREG = ROOT / "ANALYSIS_SCOPE.preregistered.json"
UPSTREAM = Path(
    r"C:\Users\yauki\Documents\Codex\2026-08-15\90-270-face-microscope"
    r"\outputs\stage0_v3_projected_curvature_github_repro_v1"
)
MAPS = UPSTREAM / "inputs" / "frozen_maps.npz"
SOLVES = UPSTREAM / "inputs" / "solves"
SOURCE_MANIFEST = UPSTREAM / "MANIFEST_SHA256.txt"
FIXED_DIRECTION_RESULT = Path(
    r"C:\Users\yauki\Documents\Codex\2026-08-15\99-8-cancellation-near-null-direction"
    r"\outputs\near_null_fixed_direction_validation_v1\fixed_direction_result.json"
)

EXPECTED_PREREG_SHA256 = "2A65FA18C310B6E7F22B9925D26F5E30CD52DF6CCAC2E465E3FDEEED625CA143"
EXPECTED_MAPS_SHA256 = "3BBC7A64271C0CFF9B6C53FE76300DEFE14AB2A4EC9675F1C72E5C7132592F95"
EXPECTED_SOURCE_MANIFEST_SHA256 = "A5A98F687DCE0E271A05E1E52B8EC20F023FDC4F5587382E726E71B866EDE291"
EXPECTED_FIXED_DIRECTION_SHA256 = "C58E3DF0696740912062C2873CF903CE37754679F1404A17708BEB3B826D6C69"

STABLE_H_DEGREES = [
    0.0439453125,
    0.02197265625,
    0.010986328125,
    0.0054931640625,
    0.00274658203125,
]
REPRESENTATIVE_H_DEGREES = 0.010986328125
TAU_ABS = 1.0e-7
TAU_REL = 1.0e-7


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def three_way(value: float, tolerance: float) -> str:
    if value > tolerance:
        return "PASS"
    if value < -tolerance:
        return "FAIL"
    return "BOUNDARY"


def block_rows(
    z: np.ndarray,
    a_coeff: np.ndarray,
    b_coeff: np.ndarray,
    s_grid: np.ndarray,
    ell_list: list[int],
    sigma: np.ndarray,
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for ell_index, ell in enumerate(ell_list):
        for s_index, s_value in enumerate(s_grid):
            x = float(a_coeff[ell_index, s_index] @ z)
            y = float(b_coeff[ell_index, s_index] @ z)
            matrix = np.asarray(
                [
                    [1.0 - 0.5 * sigma[s_index] * y, math.sqrt(sigma[s_index]) * x],
                    [math.sqrt(sigma[s_index]) * x, 2.0 * y],
                ]
            )
            eig_min = float(np.linalg.eigvalsh(matrix)[0])
            disk_slack = float(2.0 * y - sigma[s_index] * (x * x + y * y))
            norm2 = float(np.linalg.norm(matrix, 2))
            eig_tol = TAU_ABS + TAU_REL * max(1.0, norm2)
            disk_tol = TAU_ABS + TAU_REL * max(1.0, norm2 * norm2)
            eig_state = three_way(eig_min, eig_tol)
            disk_state = three_way(disk_slack, disk_tol)
            output.append(
                {
                    "ell_index": ell_index,
                    "ell": ell,
                    "s_index": s_index,
                    "s": float(s_value),
                    "x": x,
                    "y": y,
                    "eig_min": eig_min,
                    "disk_slack": disk_slack,
                    "eig_tolerance": eig_tol,
                    "disk_tolerance": disk_tol,
                    "eig_state": eig_state,
                    "disk_state": disk_state,
                    "boundary": "BOUNDARY" in (eig_state, disk_state),
                }
            )
    return output


def jaccard(left: set[tuple[int, int]], right: set[tuple[int, int]]) -> float:
    union = left | right
    return len(left & right) / len(union) if union else 1.0


def average_ranks(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    start = 0
    while start < len(values):
        stop = start + 1
        while stop < len(values) and values[order[stop]] == values[order[start]]:
            stop += 1
        ranks[order[start:stop]] = 0.5 * (start + stop - 1) + 1.0
        start = stop
    return ranks


def spearman(x: np.ndarray, y: np.ndarray) -> float:
    rx = average_ranks(x)
    ry = average_ranks(y)
    rx = rx - np.mean(rx)
    ry = ry - np.mean(ry)
    denominator = float(np.linalg.norm(rx) * np.linalg.norm(ry))
    return float(np.dot(rx, ry) / denominator) if denominator > 0.0 else math.nan


def linear_loocv(x: np.ndarray, y: np.ndarray) -> dict[str, float]:
    linear_predictions = np.empty(len(y))
    mean_predictions = np.empty(len(y))
    for test_index in range(len(y)):
        train = np.arange(len(y)) != test_index
        design = np.column_stack([np.ones(np.sum(train)), x[train]])
        coefficients = np.linalg.lstsq(design, y[train], rcond=None)[0]
        linear_predictions[test_index] = coefficients[0] + coefficients[1] * x[test_index]
        mean_predictions[test_index] = float(np.mean(y[train]))
    linear_sse = float(np.sum((y - linear_predictions) ** 2))
    mean_sse = float(np.sum((y - mean_predictions) ** 2))
    full_coefficients = np.linalg.lstsq(
        np.column_stack([np.ones(len(y)), x]), y, rcond=None
    )[0]
    return {
        "intercept": float(full_coefficients[0]),
        "slope": float(full_coefficients[1]),
        "spearman": spearman(x, y),
        "linear_loocv_sse": linear_sse,
        "training_mean_loocv_sse": mean_sse,
        "normalized_loocv_sse_ratio": linear_sse / mean_sse if mean_sse > 0.0 else math.nan,
        "linear_predictions": linear_predictions.tolist(),
        "mean_predictions": mean_predictions.tolist(),
    }


def main() -> int:
    scope = json.loads(PREREG.read_text(encoding="utf-8"))
    fixed_result = json.loads(FIXED_DIRECTION_RESULT.read_text(encoding="utf-8"))
    preflight_checks = {
        "preregistered_scope_hash": sha256(PREREG) == EXPECTED_PREREG_SHA256,
        "frozen_maps_hash": sha256(MAPS) == EXPECTED_MAPS_SHA256,
        "source_manifest_hash": sha256(SOURCE_MANIFEST) == EXPECTED_SOURCE_MANIFEST_SHA256,
        "fixed_direction_result_hash": sha256(FIXED_DIRECTION_RESULT)
        == EXPECTED_FIXED_DIRECTION_SHA256,
        "scope_says_sealed_before_analysis": scope["sealed_before_analysis"] is True,
        "scope_says_new_solver_runs_zero": scope["new_solver_runs"] == 0,
    }

    maps = np.load(MAPS, allow_pickle=False)
    a_coeff = np.asarray(maps["a_coeff"], dtype=float)
    b_coeff = np.asarray(maps["b_coeff"], dtype=float)
    s_grid = np.asarray(maps["s_grid"], dtype=float)
    q0 = np.asarray(maps["q0"], dtype=float)
    q2 = np.asarray(maps["q2"], dtype=float)
    ell_list = [int(value) for value in maps["ell_list"]]
    mass = float(maps["m"][0])
    sigma = np.sqrt((s_grid - 4.0 * mass * mass) / s_grid)

    solve_paths = sorted(SOLVES.glob("solve_*.json"))
    solves: dict[tuple[float, float], dict[str, Any]] = {}
    for path in solve_paths:
        row = json.loads(path.read_text(encoding="utf-8"))
        solves[(float(row["axis_degrees"]), float(row["offset_degrees"]))] = row
    required_keys = {
        (axis, signed_multiplier * h)
        for axis in (90.0, 270.0)
        for h in STABLE_H_DEGREES
        for signed_multiplier in (-2.0, -1.0, 1.0, 2.0)
    } | {(90.0, 0.0), (270.0, 0.0)}
    preflight_checks.update(
        {
            "source_solve_file_count_38": len(solve_paths) == 38,
            "unique_solve_count_38": len(solves) == 38,
            "all_source_status_pass": all(row["status"] == "PASS" for row in solves.values()),
            "all_one_sided_required_offsets_present": required_keys.issubset(set(solves)),
            "fixed_direction_matches_scope": np.allclose(
                np.asarray(fixed_result["blind_zero_sum_direction"]["direction_unit"]),
                np.asarray(scope["fixed_direction_source"]["d_zero_unit"]),
                rtol=0.0,
                atol=1.0e-15,
            ),
        }
    )
    if not all(preflight_checks.values()):
        write_json(
            ROOT / "read_only_preflight.json",
            {"status": "STOP", "checks": preflight_checks, "new_solver_runs": 0},
        )
        return 2
    write_json(
        ROOT / "read_only_preflight.json",
        {"status": "PASS", "checks": preflight_checks, "new_solver_runs": 0},
    )

    d_zero = np.asarray(scope["fixed_direction_source"]["d_zero_unit"], dtype=float)
    d_zero = d_zero / np.linalg.norm(d_zero)
    n_hat = np.ones(3) / math.sqrt(3.0)
    d_perp = np.cross(n_hat, d_zero)
    d_perp = d_perp / np.linalg.norm(d_perp)
    a_orientation = np.asarray([1.0, 0.0, -1.0])
    if np.dot(d_perp, a_orientation) < 0.0:
        d_perp = -d_perp

    b0 = b_coeff[0, :, 1:6]
    c_sigma = np.linalg.lstsq(b0, sigma, rcond=None)[0]
    sigma_relative_residual = float(np.linalg.norm(b0 @ c_sigma - sigma) / np.linalg.norm(sigma))

    center_blocks: dict[float, list[dict[str, Any]]] = {}
    center_active_keys: dict[float, set[tuple[int, int]]] = {}
    center_vectors: dict[float, np.ndarray] = {}
    endpoint_cache: dict[tuple[float, float], list[dict[str, Any]]] = {}
    for axis in (90.0, 270.0):
        center = np.asarray(solves[(axis, 0.0)]["z"], dtype=float)
        center_vectors[axis] = center
        blocks = block_rows(center, a_coeff, b_coeff, s_grid, ell_list, sigma)
        center_blocks[axis] = blocks
        center_active_keys[axis] = {
            (int(row["ell"]), int(row["s_index"])) for row in blocks if row["boundary"]
        }
        for h in STABLE_H_DEGREES:
            for multiplier in (-2.0, -1.0, 1.0, 2.0):
                offset = multiplier * h
                if (axis, offset) not in endpoint_cache:
                    endpoint_cache[(axis, offset)] = block_rows(
                        np.asarray(solves[(axis, offset)]["z"], dtype=float),
                        a_coeff,
                        b_coeff,
                        s_grid,
                        ell_list,
                        sigma,
                    )

    def response_coordinates(axis: float, first: np.ndarray, second: np.ndarray) -> dict[str, Any]:
        universal = np.zeros(16)
        sign = -1.0 if axis == 90.0 else 1.0
        a1 = float(q0 @ first)
        universal[1:6] = sign * 2.0 * a1 * a1 * c_sigma
        residual = second - universal
        delta = np.asarray(
            [
                q2[1:6] @ residual[1:6],
                q2[6:11] @ residual[6:11],
                q2[11:16] @ residual[11:16],
            ],
            dtype=float,
        )
        alpha = float(np.dot(delta, d_zero))
        eta = float(np.dot(delta, d_perp))
        epsilon = float(np.dot(delta, n_hat))
        return {
            "a1": a1,
            "delta": delta,
            "alpha": alpha,
            "eta": eta,
            "epsilon": epsilon,
            "r_eta": eta / alpha,
            "r_epsilon": epsilon / alpha,
            "residual16": residual,
        }

    raw_responses: dict[tuple[float, float], dict[str, Any]] = {}
    drift_rows: list[dict[str, Any]] = []
    for axis in (90.0, 270.0):
        z0 = center_vectors[axis]
        for h_degrees in STABLE_H_DEGREES:
            h = math.radians(h_degrees)
            z_plus = np.asarray(solves[(axis, h_degrees)]["z"], dtype=float)
            z_minus = np.asarray(solves[(axis, -h_degrees)]["z"], dtype=float)
            z_plus2 = np.asarray(solves[(axis, 2.0 * h_degrees)]["z"], dtype=float)
            z_minus2 = np.asarray(solves[(axis, -2.0 * h_degrees)]["z"], dtype=float)
            v_symmetric = (z_plus - z_minus) / (2.0 * h)
            u_symmetric = (z_plus + z_minus - 2.0 * z0) / (2.0 * h * h)
            v_plus = (-3.0 * z0 + 4.0 * z_plus - z_plus2) / (2.0 * h)
            v_minus = (3.0 * z0 - 4.0 * z_minus + z_minus2) / (2.0 * h)
            u_plus = (z_plus2 - 2.0 * z_plus + z0) / (2.0 * h * h)
            u_minus = (z_minus2 - 2.0 * z_minus + z0) / (2.0 * h * h)
            symmetric = response_coordinates(axis, v_symmetric, u_symmetric)
            plus = response_coordinates(axis, v_plus, u_plus)
            minus = response_coordinates(axis, v_minus, u_minus)
            raw_responses[(axis, h_degrees)] = {
                "v_symmetric": v_symmetric,
                "u_symmetric": u_symmetric,
                "v_plus": v_plus,
                "u_plus": u_plus,
                "v_minus": v_minus,
                "u_minus": u_minus,
                "symmetric": symmetric,
                "plus": plus,
                "minus": minus,
            }
            drift_rows.append(
                {
                    "axis_degrees": axis,
                    "h_degrees": h_degrees,
                    "h_radians": h,
                    "h_radians_squared": h * h,
                    "alpha_symmetric": symmetric["alpha"],
                    "eta_symmetric": symmetric["eta"],
                    "epsilon_symmetric": symmetric["epsilon"],
                    "r_eta_symmetric": symmetric["r_eta"],
                    "r_epsilon_symmetric": symmetric["r_epsilon"],
                    "r_eta_plus": plus["r_eta"],
                    "r_eta_minus": minus["r_eta"],
                    "r_epsilon_plus": plus["r_epsilon"],
                    "r_epsilon_minus": minus["r_epsilon"],
                    "r_eta_one_sided_gap_abs": abs(plus["r_eta"] - minus["r_eta"]),
                    "r_epsilon_one_sided_gap_abs": abs(
                        plus["r_epsilon"] - minus["r_epsilon"]
                    ),
                    "r_eta_symmetric_bracketed_by_sides": bool(
                        min(plus["r_eta"], minus["r_eta"])
                        <= symmetric["r_eta"]
                        <= max(plus["r_eta"], minus["r_eta"])
                    ),
                    "r_epsilon_symmetric_bracketed_by_sides": bool(
                        min(plus["r_epsilon"], minus["r_epsilon"])
                        <= symmetric["r_epsilon"]
                        <= max(plus["r_epsilon"], minus["r_epsilon"])
                    ),
                    "delta0_symmetric": float(symmetric["delta"][0]),
                    "delta2_symmetric": float(symmetric["delta"][1]),
                    "delta4_symmetric": float(symmetric["delta"][2]),
                }
            )

    # Select top two center-boundary blocks once at the representative scale for each axis.
    fixed_blocks: dict[float, list[tuple[int, int]]] = {}
    for axis in (90.0, 270.0):
        v_rep = raw_responses[(axis, REPRESENTATIVE_H_DEGREES)]["v_symmetric"]
        ranked: list[tuple[float, tuple[int, int]]] = []
        for block in center_blocks[axis]:
            if not block["boundary"]:
                continue
            ell_index = int(block["ell_index"])
            s_index = int(block["s_index"])
            x1 = float(a_coeff[ell_index, s_index] @ v_rep)
            y1 = float(b_coeff[ell_index, s_index] @ v_rep)
            demand = float(sigma[s_index] * (x1 * x1 + y1 * y1))
            ranked.append((demand, (int(block["ell"]), s_index)))
        ranked.sort(reverse=True)
        fixed_blocks[axis] = [ranked[0][1], ranked[1][1]]
    expected_90 = [(0, 29), (0, 24)]
    if fixed_blocks[90.0] != expected_90:
        write_json(
            ROOT / "read_only_preflight.json",
            {
                "status": "STOP",
                "checks": preflight_checks,
                "fixed_blocks_90_actual": fixed_blocks[90.0],
                "fixed_blocks_90_expected": expected_90,
                "new_solver_runs": 0,
            },
        )
        return 3

    block_diagnostic_rows: list[dict[str, Any]] = []
    fingerprint_rows: list[dict[str, Any]] = []
    for axis in (90.0, 270.0):
        active_center = center_active_keys[axis]
        block_lookup = {
            (int(block["ell"]), int(block["s_index"])): block
            for block in center_blocks[axis]
        }
        fixed = fixed_blocks[axis]
        for h_degrees in STABLE_H_DEGREES:
            response = raw_responses[(axis, h_degrees)]
            v = response["v_symmetric"]
            u = response["u_symmetric"]
            active_metrics: list[dict[str, Any]] = []
            for key in sorted(active_center):
                block = block_lookup[key]
                ell_index = int(block["ell_index"])
                s_index = int(block["s_index"])
                x1 = float(a_coeff[ell_index, s_index] @ v)
                y1 = float(b_coeff[ell_index, s_index] @ v)
                x2 = float(a_coeff[ell_index, s_index] @ u)
                y2 = float(b_coeff[ell_index, s_index] @ u)
                demand = float(sigma[s_index] * (x1 * x1 + y1 * y1))
                tangent_magnitude = math.sqrt(max(0.0, demand))
                supply = float(
                    2.0 * (1.0 - sigma[s_index] * block["y"]) * y2
                    - 2.0 * sigma[s_index] * block["x"] * x2
                )
                metric = {
                    "key": key,
                    "ell": key[0],
                    "s_index": key[1],
                    "s": block["s"],
                    "demand": demand,
                    "tangent_magnitude": tangent_magnitude,
                    "supply": supply,
                    "supply_minus_demand": supply - demand,
                }
                active_metrics.append(metric)
            total_demand = float(sum(item["demand"] for item in active_metrics))
            demand_shares = np.asarray(
                [item["demand"] / total_demand for item in active_metrics], dtype=float
            )
            effective_participation = float(1.0 / np.sum(demand_shares**2))
            ranked_metrics = sorted(active_metrics, key=lambda item: item["demand"], reverse=True)
            metric_lookup = {item["key"]: item for item in active_metrics}
            first_metric = metric_lookup[fixed[0]]
            second_metric = metric_lookup[fixed[1]]
            p_d = first_metric["demand"] / (
                first_metric["demand"] + second_metric["demand"]
            )
            p_t = first_metric["tangent_magnitude"] / (
                first_metric["tangent_magnitude"] + second_metric["tangent_magnitude"]
            )
            supply_denominator = first_metric["supply"] + second_metric["supply"]
            p_s = (
                first_metric["supply"] / supply_denominator
                if supply_denominator != 0.0
                else math.nan
            )

            # One-sided demand balances for the same fixed block IDs.
            side_balances: dict[str, float] = {}
            for side_name, side_v in (
                ("plus", response["v_plus"]),
                ("minus", response["v_minus"]),
            ):
                side_demands = []
                for key in fixed:
                    block = block_lookup[key]
                    ell_index = int(block["ell_index"])
                    s_index = int(block["s_index"])
                    x1 = float(a_coeff[ell_index, s_index] @ side_v)
                    y1 = float(b_coeff[ell_index, s_index] @ side_v)
                    side_demands.append(float(sigma[s_index] * (x1 * x1 + y1 * y1)))
                side_balances[side_name] = side_demands[0] / sum(side_demands)

            plus_blocks = endpoint_cache[(axis, h_degrees)]
            minus_blocks = endpoint_cache[(axis, -h_degrees)]
            active_plus = {
                (int(block["ell"]), int(block["s_index"]))
                for block in plus_blocks
                if block["boundary"]
            }
            active_minus = {
                (int(block["ell"]), int(block["s_index"]))
                for block in minus_blocks
                if block["boundary"]
            }
            plus_lookup = {
                (int(block["ell"]), int(block["s_index"])): block for block in plus_blocks
            }
            minus_lookup = {
                (int(block["ell"]), int(block["s_index"])): block for block in minus_blocks
            }
            fingerprint_rows.append(
                {
                    "axis_degrees": axis,
                    "h_degrees": h_degrees,
                    "fixed_block_1": f"ell{fixed[0][0]}_s{fixed[0][1]}",
                    "fixed_block_2": f"ell{fixed[1][0]}_s{fixed[1][1]}",
                    "p_D": p_d,
                    "p_T": p_t,
                    "p_S": p_s,
                    "p_D_plus_one_sided": side_balances["plus"],
                    "p_D_minus_one_sided": side_balances["minus"],
                    "fixed_top2_demand_share": (
                        first_metric["demand"] + second_metric["demand"]
                    )
                    / total_demand,
                    "top1_dynamic_demand_share": ranked_metrics[0]["demand"] / total_demand,
                    "top2_dynamic_demand_share": (
                        ranked_metrics[0]["demand"] + ranked_metrics[1]["demand"]
                    )
                    / total_demand,
                    "effective_participation_count": effective_participation,
                    "center_active_count": len(active_center),
                    "plus_active_count": len(active_plus),
                    "minus_active_count": len(active_minus),
                    "plus_minus_active_jaccard": jaccard(active_plus, active_minus),
                    "plus_center_active_jaccard": jaccard(active_plus, active_center),
                    "minus_center_active_jaccard": jaccard(active_minus, active_center),
                    "plus_minus_symmetric_difference_count": len(
                        active_plus.symmetric_difference(active_minus)
                    ),
                    "plus_active_ids": json.dumps(sorted(active_plus), separators=(",", ":")),
                    "minus_active_ids": json.dumps(sorted(active_minus), separators=(",", ":")),
                    "fixed1_plus_disk_slack": plus_lookup[fixed[0]]["disk_slack"],
                    "fixed1_minus_disk_slack": minus_lookup[fixed[0]]["disk_slack"],
                    "fixed2_plus_disk_slack": plus_lookup[fixed[1]]["disk_slack"],
                    "fixed2_minus_disk_slack": minus_lookup[fixed[1]]["disk_slack"],
                }
            )
            rank_lookup = {item["key"]: rank + 1 for rank, item in enumerate(ranked_metrics)}
            for item in active_metrics:
                block_diagnostic_rows.append(
                    {
                        "axis_degrees": axis,
                        "h_degrees": h_degrees,
                        "ell": item["ell"],
                        "s_index": item["s_index"],
                        "s": item["s"],
                        "demand_rank": rank_lookup[item["key"]],
                        "is_fixed_block_1": item["key"] == fixed[0],
                        "is_fixed_block_2": item["key"] == fixed[1],
                        "quadratic_disk_demand": item["demand"],
                        "demand_share": item["demand"] / total_demand,
                        "tangent_magnitude_sqrt_demand": item["tangent_magnitude"],
                        "second_order_supply": item["supply"],
                        "supply_minus_demand": item["supply_minus_demand"],
                    }
                )

    drift_lookup = {
        (float(row["axis_degrees"]), float(row["h_degrees"])): row for row in drift_rows
    }
    fingerprint_lookup = {
        (float(row["axis_degrees"]), float(row["h_degrees"])): row
        for row in fingerprint_rows
    }
    joined_rows: list[dict[str, Any]] = []
    for axis in (90.0, 270.0):
        for h_degrees in STABLE_H_DEGREES:
            joined_rows.append(
                {
                    **drift_lookup[(axis, h_degrees)],
                    **{
                        key: value
                        for key, value in fingerprint_lookup[(axis, h_degrees)].items()
                        if key not in ("axis_degrees", "h_degrees")
                    },
                }
            )

    model_rows: list[dict[str, Any]] = []
    model_results: dict[str, dict[str, dict[str, dict[str, float]]]] = {}
    for axis in (90.0, 270.0):
        axis_rows = [row for row in joined_rows if row["axis_degrees"] == axis]
        model_results[str(int(axis))] = {}
        predictor_values = {
            "h_squared": np.asarray([row["h_radians_squared"] for row in axis_rows]),
            "p_D": np.asarray([row["p_D"] for row in axis_rows]),
            "p_T_secondary": np.asarray([row["p_T"] for row in axis_rows]),
            "p_S_secondary": np.asarray([row["p_S"] for row in axis_rows]),
        }
        outcome_values = {
            "r_eta": np.asarray([row["r_eta_symmetric"] for row in axis_rows]),
            "r_epsilon": np.asarray([row["r_epsilon_symmetric"] for row in axis_rows]),
        }
        for outcome_name, outcome in outcome_values.items():
            model_results[str(int(axis))][outcome_name] = {}
            for predictor_name, predictor in predictor_values.items():
                metrics = linear_loocv(predictor, outcome)
                model_results[str(int(axis))][outcome_name][predictor_name] = metrics
                model_rows.append(
                    {
                        "axis_degrees": axis,
                        "outcome": outcome_name,
                        "predictor": predictor_name,
                        "intercept": metrics["intercept"],
                        "slope": metrics["slope"],
                        "spearman": metrics["spearman"],
                        "linear_loocv_sse": metrics["linear_loocv_sse"],
                        "training_mean_loocv_sse": metrics["training_mean_loocv_sse"],
                        "normalized_loocv_sse_ratio": metrics[
                            "normalized_loocv_sse_ratio"
                        ],
                    }
                )

    rows_90 = [row for row in joined_rows if row["axis_degrees"] == 90.0]
    eta_gaps = np.asarray([row["r_eta_one_sided_gap_abs"] for row in rows_90])
    adjacent_gap_decreases = [
        bool(eta_gaps[index + 1] < eta_gaps[index]) for index in range(len(eta_gaps) - 1)
    ]
    gap_smallest_over_largest_h = float(eta_gaps[-1] / eta_gaps[0])
    side_gap_pass = sum(adjacent_gap_decreases) >= 3 and gap_smallest_over_largest_h <= 0.5

    q_width = model_results["90"]["r_eta"]["h_squared"]["normalized_loocv_sse_ratio"]
    q_demand = model_results["90"]["r_eta"]["p_D"]["normalized_loocv_sse_ratio"]
    q_demand_epsilon = model_results["90"]["r_epsilon"]["p_D"][
        "normalized_loocv_sse_ratio"
    ]
    q_width_epsilon = model_results["90"]["r_epsilon"]["h_squared"][
        "normalized_loocv_sse_ratio"
    ]
    q_demand_270 = model_results["270"]["r_eta"]["p_D"][
        "normalized_loocv_sse_ratio"
    ]
    rho_demand = abs(model_results["90"]["r_eta"]["p_D"]["spearman"])

    width_checks = {
        "clear_improvement": q_width <= 0.5,
        "clear_advantage_over_demand": q_width <= 0.5 * q_demand,
        "one_sided_gap_shrink": side_gap_pass,
    }
    demand_checks = {
        "clear_improvement": q_demand <= 0.5,
        "clear_advantage_over_width": q_demand <= 0.5 * q_width,
        "rank_correspondence": rho_demand >= 0.8,
        "specific_to_eta_over_epsilon": q_demand <= 0.5 * q_demand_epsilon,
        "absent_in_270_control": q_demand_270 > 0.5,
    }
    width_candidate = all(width_checks.values())
    demand_candidate = all(demand_checks.values())
    if width_candidate and demand_candidate:
        classification = "MIXED"
    elif width_candidate:
        classification = "WIDTH_HIGHER_ORDER_CANDIDATE"
    elif demand_candidate:
        classification = "ACTIVE_DEMAND_CANDIDATE"
    else:
        classification = "UNRESOLVED"

    endpoint_active_differences_90: list[dict[str, Any]] = []
    for row in rows_90:
        plus_set = {tuple(item) for item in json.loads(row["plus_active_ids"])}
        minus_set = {tuple(item) for item in json.loads(row["minus_active_ids"])}
        endpoint_active_differences_90.append(
            {
                "h_degrees": row["h_degrees"],
                "plus_only": [list(item) for item in sorted(plus_set - minus_set)],
                "minus_only": [list(item) for item in sorted(minus_set - plus_set)],
            }
        )

    result = {
        "schema_version": "1.0",
        "status": "COMPLETE",
        "classification": classification,
        "source_solve_count": 38,
        "new_solver_runs": 0,
        "preregistered_scope_sha256": EXPECTED_PREREG_SHA256,
        "coordinates": {
            "d_zero_unit": d_zero.tolist(),
            "d_perp_unit": d_perp.tolist(),
            "n_hat": n_hat.tolist(),
            "orthogonality_max_abs_dot": float(
                max(
                    abs(np.dot(d_zero, d_perp)),
                    abs(np.dot(d_zero, n_hat)),
                    abs(np.dot(d_perp, n_hat)),
                )
            ),
        },
        "frozen_map_identity": {
            "sigma_reconstruction_relative_residual": sigma_relative_residual,
        },
        "fixed_blocks": {
            "90": [list(key) for key in fixed_blocks[90.0]],
            "270": [list(key) for key in fixed_blocks[270.0]],
        },
        "primary_model_comparison": {
            "90_r_eta_width_h_squared_normalized_loocv_sse": q_width,
            "90_r_eta_demand_p_D_normalized_loocv_sse": q_demand,
            "demand_over_width_ratio": q_demand / q_width if q_width > 0.0 else math.inf,
            "width_over_demand_ratio": q_width / q_demand if q_demand > 0.0 else math.inf,
            "90_p_D_r_eta_abs_spearman": rho_demand,
            "90_p_D_r_epsilon_normalized_loocv_sse": q_demand_epsilon,
            "90_h_squared_r_epsilon_normalized_loocv_sse": q_width_epsilon,
            "270_p_D_r_eta_normalized_loocv_sse": q_demand_270,
        },
        "one_sided_audit_90": {
            "h_degrees_descending": STABLE_H_DEGREES,
            "r_eta_plus": [row["r_eta_plus"] for row in rows_90],
            "r_eta_symmetric": [row["r_eta_symmetric"] for row in rows_90],
            "r_eta_minus": [row["r_eta_minus"] for row in rows_90],
            "absolute_plus_minus_gaps": eta_gaps.tolist(),
            "adjacent_gap_decreases_toward_smaller_h": adjacent_gap_decreases,
            "decrease_count": int(sum(adjacent_gap_decreases)),
            "smallest_h_gap_over_largest_h_gap": gap_smallest_over_largest_h,
            "symmetric_bracketed_count": int(
                sum(row["r_eta_symmetric_bracketed_by_sides"] for row in rows_90)
            ),
        },
        "active_fingerprint_90": {
            "center_active_count": rows_90[0]["center_active_count"],
            "plus_minus_jaccard": [row["plus_minus_active_jaccard"] for row in rows_90],
            "plus_minus_symmetric_difference_count": [
                row["plus_minus_symmetric_difference_count"] for row in rows_90
            ],
            "fixed_top2_demand_share": [row["fixed_top2_demand_share"] for row in rows_90],
            "effective_participation_count": [
                row["effective_participation_count"] for row in rows_90
            ],
            "p_D": [row["p_D"] for row in rows_90],
            "endpoint_active_set_differences": endpoint_active_differences_90,
        },
        "mechanical_separation_summary": (
            "Within the preregistered models, symmetric zero-sum transverse drift r_eta is "
            "better predicted by fixed top-two demand balance than by h^2, while observable "
            "leakage r_epsilon is better predicted by h^2 than by demand balance. One-sided "
            "gaps still shrink strongly, so higher-order odd contamination exists but does "
            "not by itself explain the symmetric r_eta sequence."
        ),
        "all_model_results": model_results,
        "preregistered_decision": {
            "width_checks": width_checks,
            "width_candidate": width_candidate,
            "active_demand_checks": demand_checks,
            "active_demand_candidate": demand_candidate,
        },
        "claim_boundary": scope["claim_boundary"],
    }
    write_json(ROOT / "drift_origin_result.json", result)

    def write_csv(path: Path, rows_to_write: list[dict[str, Any]]) -> None:
        with path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows_to_write[0]))
            writer.writeheader()
            writer.writerows(rows_to_write)

    write_csv(ROOT / "drift_coordinates.csv", drift_rows)
    write_csv(ROOT / "active_fingerprints.csv", fingerprint_rows)
    write_csv(ROOT / "active_block_diagnostics.csv", block_diagnostic_rows)
    write_csv(ROOT / "model_comparison.csv", model_rows)

    write_json(
        ROOT / "PROVENANCE_SHA256.json",
        {
            "schema_version": "1.0",
            "source_solve_count": 38,
            "new_solver_runs": 0,
            "inputs": {
                str(PREREG): sha256(PREREG),
                str(MAPS): sha256(MAPS),
                str(SOURCE_MANIFEST): sha256(SOURCE_MANIFEST),
                str(FIXED_DIRECTION_RESULT): sha256(FIXED_DIRECTION_RESULT),
                **{str(path): sha256(path) for path in solve_paths},
            },
        },
    )

    # Diagnostics figure.
    h_values = np.asarray(STABLE_H_DEGREES)
    p_d_90 = np.asarray([row["p_D"] for row in rows_90])
    r_eta_90 = np.asarray([row["r_eta_symmetric"] for row in rows_90])
    r_eps_90 = np.asarray([row["r_epsilon_symmetric"] for row in rows_90])
    figure, axes = plt.subplots(2, 3, figsize=(16.5, 8.7))
    axes[0, 0].plot(h_values, [row["r_eta_plus"] for row in rows_90], "o-", label="plus")
    axes[0, 0].plot(h_values, r_eta_90, "ko-", label="symmetric")
    axes[0, 0].plot(h_values, [row["r_eta_minus"] for row in rows_90], "o-", label="minus")
    axes[0, 0].set_xscale("log")
    axes[0, 0].invert_xaxis()
    axes[0, 0].set_xlabel("h (degrees)")
    axes[0, 0].set_ylabel("r_eta")
    axes[0, 0].set_title("One-sided versus symmetric drift")
    axes[0, 0].legend(frameon=False)

    axes[0, 1].plot(h_values, eta_gaps, "o-", color="#e45756")
    axes[0, 1].set_xscale("log")
    axes[0, 1].set_yscale("log")
    axes[0, 1].invert_xaxis()
    axes[0, 1].set_xlabel("h (degrees)")
    axes[0, 1].set_ylabel("abs(r_eta_plus-r_eta_minus)")
    axes[0, 1].set_title("Odd/higher-order side gap")

    axes[0, 2].plot(p_d_90, r_eta_90, "o-", label="r_eta")
    axes[0, 2].plot(p_d_90, r_eps_90, "s--", label="r_epsilon")
    for x_value, y_value, h_value in zip(p_d_90, r_eta_90, h_values):
        axes[0, 2].annotate(f"{h_value:.4g}", (x_value, y_value), fontsize=7)
    axes[0, 2].set_xlabel("fixed top-2 demand balance p_D")
    axes[0, 2].set_ylabel("normalized drift")
    axes[0, 2].set_title("Demand redistribution")
    axes[0, 2].legend(frameon=False)

    axes[1, 0].plot(
        h_values,
        [row["plus_minus_active_jaccard"] for row in rows_90],
        "o-",
        label="plus/minus Jaccard",
    )
    axes[1, 0].plot(
        h_values,
        [row["plus_center_active_jaccard"] for row in rows_90],
        "o--",
        label="plus/center",
    )
    axes[1, 0].plot(
        h_values,
        [row["minus_center_active_jaccard"] for row in rows_90],
        "o--",
        label="minus/center",
    )
    axes[1, 0].set_xscale("log")
    axes[1, 0].invert_xaxis()
    axes[1, 0].set_ylim(0.0, 1.05)
    axes[1, 0].set_xlabel("h (degrees)")
    axes[1, 0].set_ylabel("active-set Jaccard")
    axes[1, 0].set_title("Endpoint active fingerprints")
    axes[1, 0].legend(frameon=False, fontsize=8)

    axes[1, 1].plot(
        h_values,
        [row["fixed_top2_demand_share"] for row in rows_90],
        "o-",
        label="fixed top-2 share",
    )
    axes[1, 1].plot(
        h_values,
        [row["effective_participation_count"] for row in rows_90],
        "s--",
        label="effective participation",
    )
    axes[1, 1].set_xscale("log")
    axes[1, 1].invert_xaxis()
    axes[1, 1].set_xlabel("h (degrees)")
    axes[1, 1].set_title("Center demand concentration")
    axes[1, 1].legend(frameon=False, fontsize=8)

    labels = ["width->eta", "demand->eta", "demand->eps", "270 demand->eta"]
    q_values = [q_width, q_demand, q_demand_epsilon, q_demand_270]
    axes[1, 2].bar(np.arange(4), q_values, color=["#4c78a8", "#e45756", "#72b7b2", "#f2cf5b"])
    axes[1, 2].axhline(0.5, color="black", linestyle="--", linewidth=0.8)
    axes[1, 2].set_xticks(np.arange(4), labels, rotation=25, ha="right")
    axes[1, 2].set_ylabel("normalized LOOCV SSE")
    axes[1, 2].set_title("Preregistered predictive checks")
    figure.tight_layout()
    figure.savefig(ROOT / "drift_origin_diagnostics.png", dpi=180)
    plt.close(figure)

    width_word = "PASS" if width_candidate else "FAIL"
    demand_word = "PASS" if demand_candidate else "FAIL"
    rows270 = [row for row in joined_rows if row["axis_degrees"] == 270.0]
    readme = f"""# Drift origin versus active-demand redistribution

Status: **COMPLETE**  
Classification: **{classification}**  
Source support solves: **38**  
New solver runs: **0**

## Preregistered decision

- Width/higher-order candidate: **{width_word}**
- Active-demand candidate: **{demand_word}**

The primary normalized LOOCV SSE ratios are `{q_width:.6g}` for the width model `r_eta ~ h^2` and `{q_demand:.6g}` for the fixed-block demand model `r_eta ~ p_D`. A value below 0.5 was required for clear improvement over a leave-one-out training-mean predictor, and the winning model also had to beat the other by a factor of two.

The fixed 90-degree blocks are `{fixed_blocks[90.0]}`. Their representative identities were sealed before analysis and recovered exactly. The mechanically selected 270-degree control blocks are `{fixed_blocks[270.0]}`.

## One-sided audit

For descending `h`, the absolute one-sided `r_eta` gaps are `{[float(value) for value in eta_gaps]}`. The gap decreased on `{sum(adjacent_gap_decreases)}` of four steps, and the smallest-h gap divided by the largest-h gap is `{gap_smallest_over_largest_h:.6g}`. The preregistered side-gap shrink rule therefore **{'PASS' if side_gap_pass else 'FAIL'}**.

The symmetric estimate was bracketed by the two one-sided estimates at `{sum(row['r_eta_symmetric_bracketed_by_sides'] for row in rows_90)}` of five scales.

## Active-demand audit

The 90-degree fixed-block demand balances are `{[row['p_D'] for row in rows_90]}`. Their absolute Spearman correlation with `r_eta` is `{rho_demand:.6g}`. The demand-model normalized LOOCV ratio for `r_epsilon` is `{q_demand_epsilon:.6g}`, while the same 270-degree control ratio for `r_eta` is `{q_demand_270:.6g}`.

The fixed top-two demand share ranges from `{100.0*min(row['fixed_top2_demand_share'] for row in rows_90):.4f}%` to `{100.0*max(row['fixed_top2_demand_share'] for row in rows_90):.4f}%`. Endpoint active-set Jaccard values for plus versus minus are `{[row['plus_minus_active_jaccard'] for row in rows_90]}`.

For `r_epsilon`, the preregistered width model has normalized LOOCV ratio `{q_width_epsilon:.6g}`, versus `{q_demand_epsilon:.6g}` for demand balance. Thus the saved data separate the two small effects mechanically: transverse zero-sum drift favors demand redistribution, while observable leakage favors finite-difference width.

The plus/minus endpoint active-set differences are `{endpoint_active_differences_90}`. The only repeated side-specific block at the three larger scales is the dominant `(ell=0,s_index=29)` block; the active sets agree at the two smallest scales.

## Interpretation boundary

This five-scale read-only comparison can identify only a descriptive candidate. A low LOOCV ratio is not a significance result. No model outside the preregistered `h^2` and fixed-block `p_D` primary pair was selected, and the secondary `p_T` and `p_S` results are reported without choosing a winner.

The 270-degree comparison used the same coordinate and mechanical block-selection rule; its center has `{rows270[0]['center_active_count']}` active blocks rather than `{rows_90[0]['center_active_count']}` at 90 degrees, so it is a structural contrast rather than a matched population sample.

## Re-run

`python analyze_drift_origin.py`
"""
    (ROOT / "README.md").write_text(readme, encoding="utf-8")

    manifest_names = [
        "ANALYSIS_SCOPE.preregistered.json",
        "PROVENANCE_SHA256.json",
        "README.md",
        "active_block_diagnostics.csv",
        "active_fingerprints.csv",
        "analyze_drift_origin.py",
        "drift_coordinates.csv",
        "drift_origin_diagnostics.png",
        "drift_origin_result.json",
        "model_comparison.csv",
        "read_only_preflight.json",
    ]
    (ROOT / "MANIFEST_SHA256.txt").write_text(
        "".join(f"{sha256(ROOT / name)}  {name}\n" for name in manifest_names),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {"status": "COMPLETE", "classification": classification, "new_solver_runs": 0},
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
