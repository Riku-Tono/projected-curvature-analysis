# Face-level geometry without regression

Status: **COMPLETE**  
Decision: **FACE_LEVEL_NOT_SUPPORTED**  
Descriptive classification: **RANK1_FACE_GEOMETRY_CONFIRMED_DRIFT_LINK_NOT_ROBUST**  
Saved source solves: **38**  
New solver runs: **0**  
Regression models fit: **0**

## 90-degree face geometry

The fixed face is `((0, 11), (0, 12), (0, 24), (0, 29))`. Centered normalized demand has PC1 energy fraction `0.99997362` (preregistered rank-1 threshold 0.95: **PASS**). Across leave-one-scale-out PCA fits, the maximum angle to the full PC1 is `0.532183` degrees and the minimum training PC1 fraction is `0.999977311`.

In block order `(s11,s12,s24,s29)`, the mean face proportions are `[0.0240076, 0.0158375, 0.263105 , 0.6970499]` and the oriented PC1 loadings are `[-0.3235915, -0.270415 , -0.2712143,  0.8652208]`. Thus the observed face mode is predominantly s29 against the pooled other three blocks, not a special s29-s24 exchange.

## Cross-fitted score versus drift, without regression

The PC orientation is fixed from low to high s-index without using drift. The table below reports Spearman rank agreement and the number of positive signs among the five products of held-out score and held-out drift relative to the four-point training mean.

| drift definition | Spearman | positive signs | relation pass | one-sided exact tail |
|---|---:|---:|---|---:|
| original r_eta | 0.9 | 3/5 | False | 0.0416667 |
| frozen baseline r_eta | 0.8 | 5/5 | True | 0.0666667 |
| raw even eta | 0.8 | 5/5 | True | 0.0666667 |
| raw even eta/alpha | -0.3 | 4/5 | False | 0.741667 |

## 270-degree controls

The matched four-coordinate 270-degree PC1 fraction is `0.997597811`. Its original-drift Spearman is `-0.6` with `2/5` positive signs, so simultaneous rank-1 plus drift reproduction is **False**. The descriptive native 270-degree ell=0 face contains `29` blocks and has PC1 fraction `0.996357965`.

Because both 270-degree controls are also above the 0.95 rank-1 threshold, rank-1 face-demand variation alone is not a 90-degree-specific signature. The axis contrast lies in the absence of the same original-drift correspondence at 270 degrees.

## Normalization sensitivity

The exact identity `raw_even_direction = raw_even_eta/raw_even_alpha` holds to maximum absolute error `0`; all five alpha values are positive. The variable denominator reverses `6` of 10 pairwise raw-eta orderings. Normalization sensitivity is preregistered as **DOCUMENTED**. This arithmetic result does not establish that alpha is a nuisance or that the ratio reversal is an artifact.

## Coordinate invariance and claim boundary

All 24 label permutations and all 16 coordinate sign flips preserve the singular spectrum and structurally oriented scores to within `8.67e-19`. They are therefore sanity checks, not negative controls.

This package describes five saved scales only. It fits no drift-on-face regression and makes no causal, KKT, dual, population, continuum, or intervention claim.

## Re-run

`python analyze_face_geometry.py`
