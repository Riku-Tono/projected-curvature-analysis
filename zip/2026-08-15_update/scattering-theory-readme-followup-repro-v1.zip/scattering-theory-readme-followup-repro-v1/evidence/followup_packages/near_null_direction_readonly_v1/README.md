# 99.8% cancellation near-null direction

Status: **COMPLETE**  
Classification: **PROJECTED_NEAR_NULL_DIRECTION_IDENTIFIED; MECHANISM NOT FORCED**  
Source support solves: **38**  
New solver runs: **0**

## Result

Define `u` as the centered second-order coefficient response and subtract the signed universal ell=0 sigma-mode particular solution. In the three q2-projected group coordinates

`(q2*(u_ell0-u_universal), q2*u_ell2, q2*u_ell4)`,

the representative 90-degree direction is

`(+41.570406849, -77.653383283, +36.330584453)`

or, setting the first component to one,

`(+1.000000, -1.867997, +0.873953)`.

It has cosine `0.999242486` with `(1,-2,1)` and is only `2.230` degrees away. Since `(1,-2,1)` is orthogonal to the total-sum functional `(1,1,1)`, this is the empirical near-null direction that produces the `99.8408%` representative cancellation.

Across the five-offset stable window, cancellation remains `99.7408%` to `99.9303%`. The 16-dimensional residual responses are also nearly one-dimensional: the leading uncentered direction carries `99.8442%` of normalized raw-coefficient variation and `99.6256%` after mapping into physical amplitudes.

## What it is not

The earlier small raw singular value of the active-disk response matrix is not the mechanism. For the top two demand blocks its raw singular-value ratio is `0.009161`, but the smallest right singular vector is `[0.001614, 0.029177, -0.999573]`, almost the weak ell=4 column. After normalizing the three group columns, the ratio rises to `0.375514`; for 4 and 13 blocks it is `0.234544` and `0.423300`. Thus simple active-response collinearity is rejected.

The 270-degree control has representative components `(+0.007600949, +0.011734827, +0.011553917)`; all have the same sign, so this near-null is absent.

## Claim boundary

This establishes an empirical, stable q2-projected direction for this saved finite grid. It does not establish an exact identity in coefficient or active-constraint space, and it does not explain why the optimizer selects that direction. KKT dual multipliers were not saved, so a dual-weighted causal allocation cannot be reconstructed.

## Re-run

From this directory:

`python analyze_near_null.py`
