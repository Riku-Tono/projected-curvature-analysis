from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / ".mplconfig"))

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


ROOT = Path(__file__).resolve().parent
UPSTREAM = Path(
    r"C:\Users\yauki\Documents\Codex\2026-08-15\90-270-face-microscope"
    r"\outputs\stage0_v3_projected_curvature_github_repro_v1"
)
PRIOR_SECOND_ORDER = Path(
    r"C:\Users\yauki\Documents\Codex\2026-08-15\90-270-face-microscope"
    r"\outputs\stage0_v3_projected_curvature_second_order_readonly_v1"
)
MAPS = UPSTREAM / "inputs" / "frozen_maps.npz"
SOLVES = UPSTREAM / "inputs" / "solves"
ACTIVE_CSV = PRIOR_SECOND_ORDER / "active_disk_quadratic_demand.csv"

OFFSETS = [
    0.087890625,
    0.0439453125,
    0.02197265625,
    0.010986328125,
    0.0054931640625,
    0.00274658203125,
    0.001373291015625,
]
STABLE_OFFSETS = OFFSETS[1:6]
REPRESENTATIVE_OFFSET = 0.010986328125
GROUPS = {
    "ell0_delta": np.arange(1, 6),
    "ell2": np.arange(6, 11),
    "ell4": np.arange(11, 16),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def cosine(x: np.ndarray, y: np.ndarray) -> float:
    return float(np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y)))


def pca_summary(unit_rows: np.ndarray) -> dict[str, Any]:
    reference = unit_rows[len(unit_rows) // 2]
    aligned = np.asarray([row if np.dot(row, reference) >= 0.0 else -row for row in unit_rows])
    _, singular_values, vh = np.linalg.svd(aligned, full_matrices=False)
    gram = aligned @ aligned.T
    off_diagonal = gram[~np.eye(len(gram), dtype=bool)]
    return {
        "singular_values": singular_values.tolist(),
        "leading_uncentered_variance_fraction": float(
            singular_values[0] ** 2 / np.sum(singular_values**2)
        ),
        "minimum_pairwise_cosine": float(np.min(off_diagonal)),
        "maximum_pairwise_cosine": float(np.max(off_diagonal)),
        "leading_direction": vh[0].tolist(),
    }


def main() -> int:
    maps = np.load(MAPS, allow_pickle=False)
    a_coeff = np.asarray(maps["a_coeff"], dtype=float)
    b_coeff = np.asarray(maps["b_coeff"], dtype=float)
    s_grid = np.asarray(maps["s_grid"], dtype=float)
    q0 = np.asarray(maps["q0"], dtype=float)
    q2 = np.asarray(maps["q2"], dtype=float)
    ell_list = [int(value) for value in maps["ell_list"]]
    mass = float(maps["m"][0])
    sigma = np.sqrt((s_grid - 4.0 * mass * mass) / s_grid)

    rows: dict[tuple[float, float], dict[str, Any]] = {}
    solve_paths = sorted(SOLVES.glob("solve_*.json"))
    for path in solve_paths:
        row = json.loads(path.read_text(encoding="utf-8"))
        rows[(float(row["axis_degrees"]), float(row["offset_degrees"]))] = row
    expected_keys = {
        (axis, sign * offset)
        for axis in (90.0, 270.0)
        for offset in OFFSETS
        for sign in (-1.0, 1.0)
    } | {(90.0, 0.0), (270.0, 0.0)}
    checks = {
        "solve_count_is_38": len(solve_paths) == 38,
        "unique_row_count_is_38": len(rows) == 38,
        "all_status_pass": all(row["status"] == "PASS" for row in rows.values()),
        "all_expected_axis_offset_keys_present": expected_keys.issubset(set(rows)),
        "map_dimension_is_16": q0.shape == q2.shape == (16,),
    }
    if not all(checks.values()):
        write_json(ROOT / "read_only_preflight.json", {"status": "STOP", "checks": checks})
        return 2
    write_json(
        ROOT / "read_only_preflight.json",
        {"status": "PASS", "checks": checks, "source_solve_count": 38, "new_solver_runs": 0},
    )

    # Exact-on-grid universal ell=0 sigma mode used by the prior analysis.
    b0 = b_coeff[0, :, 1:6]
    c_sigma, _, rank_b0, _ = np.linalg.lstsq(b0, sigma, rcond=None)
    sigma_residual = b0 @ c_sigma - sigma
    kappa_sigma = float(q2[1:6] @ c_sigma)

    physical_map = np.concatenate(
        [a_coeff.reshape(-1, 16), b_coeff.reshape(-1, 16)], axis=0
    )
    target_121 = np.asarray([1.0, -2.0, 1.0])
    target_121_unit = target_121 / np.linalg.norm(target_121)

    offset_rows: list[dict[str, Any]] = []
    residual_vectors: dict[float, np.ndarray] = {}
    physical_residual_vectors: dict[float, np.ndarray] = {}
    contribution_vectors: dict[float, np.ndarray] = {}
    response_cache: dict[tuple[float, float], dict[str, np.ndarray | float]] = {}

    for axis in (90.0, 270.0):
        sign = -1.0 if axis == 90.0 else 1.0
        center = np.asarray(rows[(axis, 0.0)]["z"], dtype=float)
        for offset in OFFSETS:
            delta = math.radians(offset)
            plus = np.asarray(rows[(axis, offset)]["z"], dtype=float)
            minus = np.asarray(rows[(axis, -offset)]["z"], dtype=float)
            first = (plus - minus) / (2.0 * delta)
            second = (plus + minus - 2.0 * center) / (2.0 * delta * delta)
            a1 = float(q0 @ first)
            universal = np.zeros(16)
            universal[1:6] = sign * 2.0 * a1 * a1 * c_sigma
            residual = second - universal
            contributions = np.asarray(
                [
                    q2[1:6] @ residual[1:6],
                    q2[6:11] @ residual[6:11],
                    q2[11:16] @ residual[11:16],
                ],
                dtype=float,
            )
            gross = float(np.sum(np.abs(contributions)))
            net = float(np.sum(contributions))
            cancellation = 1.0 - abs(net) / gross if gross else math.nan
            direction_l1 = contributions / gross if gross else np.full(3, math.nan)
            cos_121 = abs(cosine(contributions, target_121)) if gross else math.nan
            angle_121 = math.degrees(math.acos(min(1.0, max(-1.0, cos_121))))
            offset_rows.append(
                {
                    "axis_degrees": axis,
                    "offset_degrees": offset,
                    "a1": a1,
                    "actual_b2": float(q2 @ second),
                    "universal_b2": float(q2 @ universal),
                    "ell0_delta": float(contributions[0]),
                    "ell2": float(contributions[1]),
                    "ell4": float(contributions[2]),
                    "net_actual_minus_universal": net,
                    "gross_absolute_deviation": gross,
                    "cancellation_fraction": cancellation,
                    "direction_l1_ell0": float(direction_l1[0]),
                    "direction_l1_ell2": float(direction_l1[1]),
                    "direction_l1_ell4": float(direction_l1[2]),
                    "cosine_to_1_minus2_1": cos_121,
                    "angle_to_1_minus2_1_degrees": angle_121,
                }
            )
            response_cache[(axis, offset)] = {
                "center": center,
                "first": first,
                "second": second,
                "universal": universal,
                "residual": residual,
            }
            if axis == 90.0:
                residual_vectors[offset] = residual
                physical_residual_vectors[offset] = physical_map @ residual
                contribution_vectors[offset] = contributions

    with (ROOT / "offset_near_null_directions.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(offset_rows[0]))
        writer.writeheader()
        writer.writerows(offset_rows)

    stable_raw_unit = np.asarray(
        [residual_vectors[offset] / np.linalg.norm(residual_vectors[offset]) for offset in STABLE_OFFSETS]
    )
    stable_physical_unit = np.asarray(
        [
            physical_residual_vectors[offset] / np.linalg.norm(physical_residual_vectors[offset])
            for offset in STABLE_OFFSETS
        ]
    )
    stable_contribution_unit = np.asarray(
        [
            contribution_vectors[offset] / np.linalg.norm(contribution_vectors[offset])
            for offset in STABLE_OFFSETS
        ]
    )

    # Re-evaluate the previously observed active-disk SVD using the disk quadratic metric.
    with ACTIVE_CSV.open("r", encoding="utf-8", newline="") as handle:
        active_rows = [
            row for row in csv.DictReader(handle) if float(row["axis_degrees"]) == 90.0
        ]
    active_keys = [
        (ell_list.index(int(row["ell"])), int(row["s_index"])) for row in active_rows
    ]
    representative = response_cache[(90.0, REPRESENTATIVE_OFFSET)]
    center = np.asarray(representative["center"])
    first = np.asarray(representative["first"])
    group_indices = list(GROUPS.values())
    active_svd: dict[str, Any] = {}
    for selected_count in (2, 4, 13):
        matrix = np.empty((2 * selected_count, 3))
        for block_rank, (ell_index, s_index) in enumerate(active_keys[:selected_count]):
            for group_index, indices in enumerate(group_indices):
                grouped_first = np.zeros(16)
                grouped_first[indices] = first[indices]
                weight = math.sqrt(sigma[s_index])
                matrix[2 * block_rank, group_index] = weight * float(
                    a_coeff[ell_index, s_index] @ grouped_first
                )
                matrix[2 * block_rank + 1, group_index] = weight * float(
                    b_coeff[ell_index, s_index] @ grouped_first
                )
        _, raw_singular, raw_vh = np.linalg.svd(matrix, full_matrices=False)
        column_norms = np.linalg.norm(matrix, axis=0)
        normalized_matrix = matrix / column_norms
        _, normalized_singular, normalized_vh = np.linalg.svd(
            normalized_matrix, full_matrices=False
        )
        raw_right = raw_vh[-1]
        normalized_right = normalized_vh[-1]
        if raw_right[0] < 0.0:
            raw_right = -raw_right
        if normalized_right[0] < 0.0:
            normalized_right = -normalized_right
        active_svd[str(selected_count)] = {
            "selected_by": "descending unweighted full quadratic disk demand",
            "disk_metric_column_norms_ell0_ell2_ell4": column_norms.tolist(),
            "raw_singular_values": raw_singular.tolist(),
            "raw_min_over_max": float(raw_singular[-1] / raw_singular[0]),
            "raw_smallest_right_singular_vector": raw_right.tolist(),
            "column_normalized_singular_values": normalized_singular.tolist(),
            "column_normalized_min_over_max": float(
                normalized_singular[-1] / normalized_singular[0]
            ),
            "column_normalized_smallest_right_singular_vector": normalized_right.tolist(),
        }

    rep_row = next(
        row
        for row in offset_rows
        if row["axis_degrees"] == 90.0
        and row["offset_degrees"] == REPRESENTATIVE_OFFSET
    )
    rep_contributions = contribution_vectors[REPRESENTATIVE_OFFSET]
    rep_ratio_to_ell0 = rep_contributions / rep_contributions[0]
    stable_rows = [
        row
        for row in offset_rows
        if row["axis_degrees"] == 90.0 and row["offset_degrees"] in STABLE_OFFSETS
    ]
    control_row = next(
        row
        for row in offset_rows
        if row["axis_degrees"] == 270.0
        and row["offset_degrees"] == REPRESENTATIVE_OFFSET
    )

    result = {
        "schema_version": "1.0",
        "status": "COMPLETE",
        "classification": "PROJECTED_NEAR_NULL_DIRECTION_IDENTIFIED_MECHANISM_NOT_FORCED",
        "source_solve_count": 38,
        "new_solver_runs": 0,
        "universal_mode": {
            "b0_rank": int(rank_b0),
            "sigma_reconstruction_relative_residual": float(
                np.linalg.norm(sigma_residual) / np.linalg.norm(sigma)
            ),
            "kappa_sigma": kappa_sigma,
            "universal_radius": 1.0 / (4.0 * kappa_sigma),
        },
        "identified_direction": {
            "coordinate_definition": (
                "(q2 dot [u_ell0-u_universal], q2 dot u_ell2, q2 dot u_ell4), "
                "where u is the centered second-order coefficient response"
            ),
            "representative_offset_degrees": REPRESENTATIVE_OFFSET,
            "representative_components": rep_contributions.tolist(),
            "representative_ratio_with_ell0_set_to_one": rep_ratio_to_ell0.tolist(),
            "representative_l1_normalized": [
                rep_row["direction_l1_ell0"],
                rep_row["direction_l1_ell2"],
                rep_row["direction_l1_ell4"],
            ],
            "representative_cancellation_fraction": rep_row["cancellation_fraction"],
            "representative_cosine_to_1_minus2_1": rep_row["cosine_to_1_minus2_1"],
            "representative_angle_to_1_minus2_1_degrees": rep_row[
                "angle_to_1_minus2_1_degrees"
            ],
            "empirical_stencil": [1.0, -2.0, 1.0],
            "interpretation": (
                "The saved 90-degree path repeatedly selects an actual-minus-universal "
                "second-order response whose q2-projected ell-group components are nearly "
                "the discrete second-difference stencil (1,-2,1), which is orthogonal to "
                "the total-sum functional (1,1,1)."
            ),
        },
        "stable_window": {
            "offsets_degrees": STABLE_OFFSETS,
            "minimum_cancellation_fraction": float(
                min(row["cancellation_fraction"] for row in stable_rows)
            ),
            "maximum_cancellation_fraction": float(
                max(row["cancellation_fraction"] for row in stable_rows)
            ),
            "minimum_cosine_to_1_minus2_1": float(
                min(row["cosine_to_1_minus2_1"] for row in stable_rows)
            ),
            "maximum_angle_to_1_minus2_1_degrees": float(
                max(row["angle_to_1_minus2_1_degrees"] for row in stable_rows)
            ),
            "coefficient_space_direction_stability": pca_summary(stable_raw_unit),
            "physical_amplitude_space_direction_stability": pca_summary(
                stable_physical_unit
            ),
            "three_group_projected_direction_stability": pca_summary(
                stable_contribution_unit
            ),
        },
        "active_disk_svd": active_svd,
        "active_disk_svd_assessment": (
            "The raw small singular value is dominated by the weak ell4 column. After "
            "normalizing group columns, min/max singular-value ratios are not near zero. "
            "Therefore the earlier raw active-response SVD does not explain the 99.8% "
            "projected cancellation."
        ),
        "control_270_at_representative_offset": {
            "components": [
                control_row["ell0_delta"],
                control_row["ell2"],
                control_row["ell4"],
            ],
            "cancellation_fraction": control_row["cancellation_fraction"],
            "assessment": "All three deviations have the same sign; the 90-degree near-null is absent.",
        },
        "claim_boundary": (
            "This is a read-only finite-grid diagnosis of saved primal responses. It "
            "identifies the empirical q2-projected direction and rejects a simple "
            "column-scale SVD explanation. It does not show an exact coefficient-space "
            "identity, a KKT-weighted cause, or a continuum-limit law because dual "
            "multipliers and additional grids are unavailable."
        ),
    }
    write_json(ROOT / "near_null_result.json", result)

    scope = {
        "config_id": "STAGE0_V3_99P8_NEAR_NULL_DIRECTION_READONLY_V1",
        "mode": "read_only_saved_artifacts",
        "source_solve_count": 38,
        "new_solver_runs": 0,
        "axes": [90.0, 270.0],
        "offsets_degrees": OFFSETS,
        "stable_window_offsets_degrees": STABLE_OFFSETS,
        "representative_offset_degrees": REPRESENTATIVE_OFFSET,
        "primary_question": (
            "Identify the direction producing the 90-degree actual-minus-universal "
            "cross-ell cancellation and test whether raw active-response SVD explains it."
        ),
        "claim_boundary": result["claim_boundary"],
    }
    write_json(ROOT / "ANALYSIS_SCOPE.json", scope)

    provenance = {
        "schema_version": "1.0",
        "new_solver_runs": 0,
        "inputs": {
            str(MAPS): sha256(MAPS),
            str(ACTIVE_CSV): sha256(ACTIVE_CSV),
            **{str(path): sha256(path) for path in solve_paths},
        },
    }
    write_json(ROOT / "PROVENANCE_SHA256.json", provenance)

    top_rows = [row for row in offset_rows if row["axis_degrees"] == 90.0]
    x = np.asarray([row["offset_degrees"] for row in top_rows])
    fig, axes = plt.subplots(1, 3, figsize=(15.2, 4.5))
    for key, label, color in (
        ("ell0_delta", r"$\Delta_{\ell=0}$", "#4c78a8"),
        ("ell2", r"$\Delta_{\ell=2}$", "#e45756"),
        ("ell4", r"$\Delta_{\ell=4}$", "#72b7b2"),
    ):
        axes[0].plot(x, [row[key] for row in top_rows], "o-", label=label, color=color)
    axes[0].plot(
        x,
        [row["net_actual_minus_universal"] for row in top_rows],
        "ko--",
        label="net",
        linewidth=1.0,
    )
    axes[0].set_xscale("log")
    axes[0].invert_xaxis()
    axes[0].axhline(0.0, color="black", linewidth=0.6)
    axes[0].set_xlabel("offset (degrees)")
    axes[0].set_ylabel("q2-projected second-order deviation")
    axes[0].set_title("90 deg: large terms, small net")
    axes[0].legend(frameon=False, fontsize=8)

    actual_unit = rep_contributions / np.linalg.norm(rep_contributions)
    labels = [r"$\ell=0$ delta", r"$\ell=2$", r"$\ell=4$"]
    xpos = np.arange(3)
    axes[1].bar(xpos - 0.18, actual_unit, width=0.36, label="observed")
    axes[1].bar(xpos + 0.18, target_121_unit, width=0.36, label="(1,-2,1)")
    axes[1].set_xticks(xpos, labels)
    axes[1].axhline(0.0, color="black", linewidth=0.6)
    axes[1].set_title(
        f"direction cosine = {rep_row['cosine_to_1_minus2_1']:.6f}"
    )
    axes[1].legend(frameon=False, fontsize=8)

    counts = [2, 4, 13]
    raw_ratios = [active_svd[str(count)]["raw_min_over_max"] for count in counts]
    normalized_ratios = [
        active_svd[str(count)]["column_normalized_min_over_max"] for count in counts
    ]
    axes[2].plot(counts, raw_ratios, "o-", label="raw columns")
    axes[2].plot(counts, normalized_ratios, "o-", label="unit-norm columns")
    axes[2].set_yscale("log")
    axes[2].set_xticks(counts)
    axes[2].set_xlabel("top active blocks by demand")
    axes[2].set_ylabel("smallest / largest singular value")
    axes[2].set_title("raw SVD null is a scale artifact")
    axes[2].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(ROOT / "near_null_diagnostics.png", dpi=180)
    plt.close(fig)

    stable_min = 100.0 * result["stable_window"]["minimum_cancellation_fraction"]
    stable_max = 100.0 * result["stable_window"]["maximum_cancellation_fraction"]
    raw_stability = 100.0 * result["stable_window"][
        "coefficient_space_direction_stability"
    ]["leading_uncentered_variance_fraction"]
    physical_stability = 100.0 * result["stable_window"][
        "physical_amplitude_space_direction_stability"
    ]["leading_uncentered_variance_fraction"]
    readme = f"""# 99.8% cancellation near-null direction

Status: **COMPLETE**  
Classification: **PROJECTED_NEAR_NULL_DIRECTION_IDENTIFIED; MECHANISM NOT FORCED**  
Source support solves: **38**  
New solver runs: **0**

## Result

Define `u` as the centered second-order coefficient response and subtract the signed universal ell=0 sigma-mode particular solution. In the three q2-projected group coordinates

`(q2*(u_ell0-u_universal), q2*u_ell2, q2*u_ell4)`,

the representative 90-degree direction is

`({rep_contributions[0]:+.9f}, {rep_contributions[1]:+.9f}, {rep_contributions[2]:+.9f})`

or, setting the first component to one,

`({rep_ratio_to_ell0[0]:+.6f}, {rep_ratio_to_ell0[1]:+.6f}, {rep_ratio_to_ell0[2]:+.6f})`.

It has cosine `{rep_row['cosine_to_1_minus2_1']:.9f}` with `(1,-2,1)` and is only `{rep_row['angle_to_1_minus2_1_degrees']:.3f}` degrees away. Since `(1,-2,1)` is orthogonal to the total-sum functional `(1,1,1)`, this is the empirical near-null direction that produces the `{100.0*rep_row['cancellation_fraction']:.4f}%` representative cancellation.

Across the five-offset stable window, cancellation remains `{stable_min:.4f}%` to `{stable_max:.4f}%`. The 16-dimensional residual responses are also nearly one-dimensional: the leading uncentered direction carries `{raw_stability:.4f}%` of normalized raw-coefficient variation and `{physical_stability:.4f}%` after mapping into physical amplitudes.

## What it is not

The earlier small raw singular value of the active-disk response matrix is not the mechanism. For the top two demand blocks its raw singular-value ratio is `{active_svd['2']['raw_min_over_max']:.6f}`, but the smallest right singular vector is `{np.asarray(active_svd['2']['raw_smallest_right_singular_vector']).round(6).tolist()}`, almost the weak ell=4 column. After normalizing the three group columns, the ratio rises to `{active_svd['2']['column_normalized_min_over_max']:.6f}`; for 4 and 13 blocks it is `{active_svd['4']['column_normalized_min_over_max']:.6f}` and `{active_svd['13']['column_normalized_min_over_max']:.6f}`. Thus simple active-response collinearity is rejected.

The 270-degree control has representative components `({control_row['ell0_delta']:+.9f}, {control_row['ell2']:+.9f}, {control_row['ell4']:+.9f})`; all have the same sign, so this near-null is absent.

## Claim boundary

This establishes an empirical, stable q2-projected direction for this saved finite grid. It does not establish an exact identity in coefficient or active-constraint space, and it does not explain why the optimizer selects that direction. KKT dual multipliers were not saved, so a dual-weighted causal allocation cannot be reconstructed.

## Re-run

From this directory:

`python analyze_near_null.py`
"""
    (ROOT / "README.md").write_text(readme, encoding="utf-8")

    manifest_names = [
        "ANALYSIS_SCOPE.json",
        "PROVENANCE_SHA256.json",
        "README.md",
        "analyze_near_null.py",
        "near_null_diagnostics.png",
        "near_null_result.json",
        "offset_near_null_directions.csv",
        "read_only_preflight.json",
    ]
    (ROOT / "MANIFEST_SHA256.txt").write_text(
        "".join(f"{sha256(ROOT / name)}  {name}\n" for name in manifest_names),
        encoding="utf-8",
    )
    print(json.dumps({"status": "COMPLETE", "new_solver_runs": 0}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
