# Near-null fixed-direction validation

Status: **COMPLETE**  
Decision: **MIXED / STRICT FIXED-LAMBDA FAIL**  
Source support solves: **38**  
New solver runs: **0**

## Main result

The zero-sum structure is confirmed, but the preregistered strict fixed-`lambda` criterion is not. Over the five-offset stable window,

`lambda=B/A = [0.08004235454258256, 0.0511741352474784, 0.06740542136872694, 0.07089659077884453, 0.05343959218498426]`

and the origin least-squares value is `lambda_star=0.063116479`. The maximum relative departure from this value is `26.82%`, above the fixed 5% threshold. Thus the data do not support an offset-independent `s+lambda*a` direction at the requested precision.

The average fixed direction is

`d_star = [1.0631164787882719, -2.0, 0.9368835212117282]`,

and it reduces the mean projection residual from `3.7298%` for `s=(1,-2,1)` to `0.6097%`. The maximum stable-window angle to `d_star` is only `0.5762` degrees. Thus the geometric average direction is tight because `lambda` is small, even though relative invariance of `lambda` fails the declared rule.

## Blind zero-sum result

The blind maximum-energy zero-sum direction is

`d_zero = [0.433728556493, -0.815954967927, 0.382226411434]`.

It lies `2.0870` degrees from normalized `(1,-2,1)`, explains `99.996237%` of the stable-window zero-sum projection energy, and implies `lambda=0.063118857`. This passes the 3-degree blind-direction criterion without using `(1,-2,1)` in the fit.

## Leakage C

The stable-window maximum `|C/A|` is `0.3453%`, passing the 1% leakage threshold. `C` changes sign across the saved offsets, and the adjacent absolute-C log-log slopes are `[2.3848, 1.5773, -1.0636, -0.4745, 0.9798, -1.9982]`. They are not approximately constant, so no single power law or plateau is claimed.

## Centered versus uncentered

For unit direction rows at 90 degrees, the leading uncentered/centered energy fractions are:

- 3-group space: `99.9958%` / `95.4185%`
- 16-dimensional coefficient space: `99.8442%` / `99.9395%`
- physical-amplitude space: `99.6256%` / `98.8550%`

For the unnormalized response rows, the centered leading fractions are `99.8910%`, `97.2500%`, and `74.1530%` in the same three spaces. The centered total energy is only `0.004176%`, `0.155884%`, and `0.374840%` for the unit-direction rows.

The uncentered result says the responses lie close to a common ray. After centering, the small direction changes are themselves mostly one-dimensional, but their total energy is tiny; this is a drift diagnostic, not a second large physical mode.

## 90 versus 270 control

Stable-window mean orthogonal component norms divided by `|delta|` are:

- 90 degrees `(s,a,n)`: `[0.999284, 0.037264, 0.001539]`
- 270 degrees `(s,a,n)`: `[0.218994, 0.358023, 0.866944]`

Thus 90 degrees concentrates in the zero-sum `s` direction with tiny `n` leakage, whereas 270 degrees is dominated by the sum direction `n`.

## Decision boundary

Two of three strict criteria pass: blind zero-sum recovery and small observable leakage. The fixed-`lambda` stability criterion fails. The supported compression is therefore

`delta(offset) = alpha(offset)*d_average + small zero-sum drift + epsilon(offset)*n`,

not a single fixed `d_star` at 5% relative precision in `lambda`.

No solver was run, no power law was fit, and no optimizer/KKT cause is claimed.

## Re-run

`python analyze_fixed_direction.py`
