from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / ".mplconfig"))

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


ROOT = Path(__file__).resolve().parent
UPSTREAM = Path(
    r"C:\Users\yauki\Documents\Codex\2026-08-15\90-270-face-microscope"
    r"\outputs\stage0_v3_projected_curvature_github_repro_v1"
)
MAPS = UPSTREAM / "inputs" / "frozen_maps.npz"
SOLVES = UPSTREAM / "inputs" / "solves"

OFFSETS = [
    0.087890625,
    0.0439453125,
    0.02197265625,
    0.010986328125,
    0.0054931640625,
    0.00274658203125,
    0.001373291015625,
]
STABLE_OFFSETS = OFFSETS[1:6]
REPRESENTATIVE_OFFSET = 0.010986328125

S = np.asarray([1.0, -2.0, 1.0])
A_BASIS = np.asarray([1.0, 0.0, -1.0])
N = np.asarray([1.0, 1.0, 1.0])

LAMBDA_MAX_RELATIVE_DEVIATION_THRESHOLD = 0.05
BLIND_ANGLE_TO_S_THRESHOLD_DEGREES = 3.0
MAX_ABS_C_OVER_A_THRESHOLD = 0.01


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def angle_degrees(x: np.ndarray, y: np.ndarray, unoriented: bool = True) -> float:
    value = float(np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y)))
    if unoriented:
        value = abs(value)
    return math.degrees(math.acos(min(1.0, max(-1.0, value))))


def direction_metrics(delta: np.ndarray, direction: np.ndarray) -> tuple[float, float]:
    cosine = abs(float(np.dot(delta, direction))) / (
        float(np.linalg.norm(delta)) * float(np.linalg.norm(direction))
    )
    projection = float(np.dot(delta, direction) / np.dot(direction, direction)) * direction
    relative_residual = float(np.linalg.norm(delta - projection) / np.linalg.norm(delta))
    return cosine, relative_residual


def svd_pair(matrix: np.ndarray) -> dict[str, Any]:
    uncentered = np.linalg.svd(matrix, full_matrices=False)[1]
    centered_matrix = matrix - np.mean(matrix, axis=0, keepdims=True)
    centered = np.linalg.svd(centered_matrix, full_matrices=False)[1]
    uncentered_energy = float(np.sum(uncentered**2))
    centered_energy = float(np.sum(centered**2))
    return {
        "uncentered_singular_values": uncentered.tolist(),
        "uncentered_leading_energy_fraction": float(uncentered[0] ** 2 / uncentered_energy),
        "centered_singular_values": centered.tolist(),
        "centered_leading_energy_fraction": (
            float(centered[0] ** 2 / centered_energy) if centered_energy > 0.0 else math.nan
        ),
        "centered_total_energy_over_uncentered_total_energy": (
            centered_energy / uncentered_energy if uncentered_energy > 0.0 else math.nan
        ),
    }


def main() -> int:
    maps = np.load(MAPS, allow_pickle=False)
    a_coeff = np.asarray(maps["a_coeff"], dtype=float)
    b_coeff = np.asarray(maps["b_coeff"], dtype=float)
    s_grid = np.asarray(maps["s_grid"], dtype=float)
    q0 = np.asarray(maps["q0"], dtype=float)
    q2 = np.asarray(maps["q2"], dtype=float)
    mass = float(maps["m"][0])
    sigma = np.sqrt((s_grid - 4.0 * mass * mass) / s_grid)
    physical_map = np.concatenate(
        [a_coeff.reshape(-1, 16), b_coeff.reshape(-1, 16)], axis=0
    )

    solve_paths = sorted(SOLVES.glob("solve_*.json"))
    rows: dict[tuple[float, float], dict[str, Any]] = {}
    for path in solve_paths:
        row = json.loads(path.read_text(encoding="utf-8"))
        rows[(float(row["axis_degrees"]), float(row["offset_degrees"]))] = row
    required_keys = {
        (axis, sign * offset)
        for axis in (90.0, 270.0)
        for offset in OFFSETS
        for sign in (-1.0, 1.0)
    } | {(90.0, 0.0), (270.0, 0.0)}
    checks = {
        "source_solve_file_count_is_38": len(solve_paths) == 38,
        "unique_solve_key_count_is_38": len(rows) == 38,
        "all_source_status_pass": all(row["status"] == "PASS" for row in rows.values()),
        "all_required_offsets_present": required_keys.issubset(set(rows)),
        "basis_is_orthogonal": all(
            abs(float(np.dot(x, y))) < 1e-15
            for x, y in ((S, A_BASIS), (S, N), (A_BASIS, N))
        ),
    }
    if not all(checks.values()):
        write_json(ROOT / "read_only_preflight.json", {"status": "STOP", "checks": checks})
        return 2
    write_json(
        ROOT / "read_only_preflight.json",
        {"status": "PASS", "checks": checks, "new_solver_runs": 0},
    )

    b0 = b_coeff[0, :, 1:6]
    c_sigma, _, b0_rank, _ = np.linalg.lstsq(b0, sigma, rcond=None)
    sigma_relative_residual = float(np.linalg.norm(b0 @ c_sigma - sigma) / np.linalg.norm(sigma))
    kappa_sigma = float(q2[1:6] @ c_sigma)

    analysis_rows: list[dict[str, Any]] = []
    vectors: dict[float, dict[str, dict[float, np.ndarray]]] = {
        axis: {"group3": {}, "coefficient16": {}, "physical": {}}
        for axis in (90.0, 270.0)
    }

    for axis in (90.0, 270.0):
        universal_sign = -1.0 if axis == 90.0 else 1.0
        center = np.asarray(rows[(axis, 0.0)]["z"], dtype=float)
        for offset in OFFSETS:
            radians = math.radians(offset)
            plus = np.asarray(rows[(axis, offset)]["z"], dtype=float)
            minus = np.asarray(rows[(axis, -offset)]["z"], dtype=float)
            first = (plus - minus) / (2.0 * radians)
            second = (plus + minus - 2.0 * center) / (2.0 * radians * radians)
            a1 = float(q0 @ first)
            universal = np.zeros(16)
            universal[1:6] = universal_sign * 2.0 * a1 * a1 * c_sigma
            residual = second - universal
            delta = np.asarray(
                [
                    q2[1:6] @ residual[1:6],
                    q2[6:11] @ residual[6:11],
                    q2[11:16] @ residual[11:16],
                ],
                dtype=float,
            )
            coefficient_s = float(np.dot(delta, S) / np.dot(S, S))
            coefficient_a = float(np.dot(delta, A_BASIS) / np.dot(A_BASIS, A_BASIS))
            coefficient_n = float(np.dot(delta, N) / np.dot(N, N))
            reconstruction = coefficient_s * S + coefficient_a * A_BASIS + coefficient_n * N
            delta_norm = float(np.linalg.norm(delta))
            analysis_rows.append(
                {
                    "axis_degrees": axis,
                    "offset_degrees": offset,
                    "delta0": float(delta[0]),
                    "delta2": float(delta[1]),
                    "delta4": float(delta[2]),
                    "A": coefficient_s,
                    "B": coefficient_a,
                    "C": coefficient_n,
                    "B_over_A": coefficient_a / coefficient_s,
                    "C_over_A": coefficient_n / coefficient_s,
                    "delta_norm": delta_norm,
                    "abs_A_over_delta_norm": abs(coefficient_s) / delta_norm,
                    "abs_B_over_delta_norm": abs(coefficient_a) / delta_norm,
                    "abs_C_over_delta_norm": abs(coefficient_n) / delta_norm,
                    "s_component_norm_over_delta_norm": (
                        abs(coefficient_s) * np.linalg.norm(S) / delta_norm
                    ),
                    "a_component_norm_over_delta_norm": (
                        abs(coefficient_a) * np.linalg.norm(A_BASIS) / delta_norm
                    ),
                    "n_component_norm_over_delta_norm": (
                        abs(coefficient_n) * np.linalg.norm(N) / delta_norm
                    ),
                    "basis_reconstruction_relative_error": float(
                        np.linalg.norm(delta - reconstruction) / delta_norm
                    ),
                    "net_actual_minus_universal": float(np.sum(delta)),
                }
            )
            vectors[axis]["group3"][offset] = delta
            vectors[axis]["coefficient16"][offset] = residual
            vectors[axis]["physical"][offset] = physical_map @ residual

    stable_90_rows = [
        row
        for row in analysis_rows
        if row["axis_degrees"] == 90.0 and row["offset_degrees"] in STABLE_OFFSETS
    ]
    stable_a = np.asarray([row["A"] for row in stable_90_rows])
    stable_b = np.asarray([row["B"] for row in stable_90_rows])
    lambda_values = stable_b / stable_a
    lambda_star = float(np.dot(stable_a, stable_b) / np.dot(stable_a, stable_a))
    d_star = S + lambda_star * A_BASIS
    d_star_unit = d_star / np.linalg.norm(d_star)

    for row in analysis_rows:
        delta = np.asarray([row["delta0"], row["delta2"], row["delta4"]])
        cosine_star, residual_star = direction_metrics(delta, d_star)
        cosine_s, residual_s = direction_metrics(delta, S)
        row["cosine_to_d_star"] = cosine_star
        row["angle_to_d_star_degrees"] = math.degrees(math.acos(min(1.0, cosine_star)))
        row["relative_residual_after_d_star_projection"] = residual_star
        row["cosine_to_s"] = cosine_s
        row["angle_to_s_degrees"] = math.degrees(math.acos(min(1.0, cosine_s)))
        row["relative_residual_after_s_projection"] = residual_s
        row["d_star_residual_improvement_fraction_over_s"] = (
            1.0 - residual_star / residual_s if residual_s > 0.0 else math.nan
        )

    # Adjacent absolute-C slopes; no global power-law fit is performed.
    for axis in (90.0, 270.0):
        axis_rows = sorted(
            [row for row in analysis_rows if row["axis_degrees"] == axis],
            key=lambda row: row["offset_degrees"],
            reverse=True,
        )
        for index, row in enumerate(axis_rows):
            if index + 1 == len(axis_rows):
                row["next_smaller_offset_degrees"] = ""
                row["abs_C_adjacent_loglog_slope"] = ""
                row["C_sign_change_to_next_smaller_offset"] = ""
                continue
            next_row = axis_rows[index + 1]
            row["next_smaller_offset_degrees"] = next_row["offset_degrees"]
            if row["C"] != 0.0 and next_row["C"] != 0.0:
                row["abs_C_adjacent_loglog_slope"] = math.log(
                    abs(next_row["C"]) / abs(row["C"])
                ) / math.log(next_row["offset_degrees"] / row["offset_degrees"])
            else:
                row["abs_C_adjacent_loglog_slope"] = ""
            row["C_sign_change_to_next_smaller_offset"] = bool(
                np.sign(row["C"]) != np.sign(next_row["C"])
            )

    fieldnames = list(analysis_rows[0])
    with (ROOT / "abc_all_offsets.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(analysis_rows)

    # Blind maximum-energy direction constrained to the zero-sum plane.
    zero_sum_rows = np.asarray(
        [
            vectors[90.0]["group3"][offset]
            - np.mean(vectors[90.0]["group3"][offset]) * N
            for offset in STABLE_OFFSETS
        ]
    )
    _, blind_singular_values, blind_vh = np.linalg.svd(zero_sum_rows, full_matrices=False)
    d_zero = blind_vh[0]
    if np.dot(d_zero, S) < 0.0:
        d_zero = -d_zero
    d_zero = d_zero - np.mean(d_zero) * N
    d_zero = d_zero / np.linalg.norm(d_zero)
    d_zero_A = float(np.dot(d_zero, S) / np.dot(S, S))
    d_zero_B = float(np.dot(d_zero, A_BASIS) / np.dot(A_BASIS, A_BASIS))

    svd_results: dict[str, Any] = {}
    svd_csv_rows: list[dict[str, Any]] = []
    for axis in (90.0, 270.0):
        svd_results[str(int(axis))] = {}
        for space in ("group3", "coefficient16", "physical"):
            matrix = np.asarray([vectors[axis][space][offset] for offset in STABLE_OFFSETS])
            unit_matrix = matrix / np.linalg.norm(matrix, axis=1, keepdims=True)
            raw_stats = svd_pair(matrix)
            unit_stats = svd_pair(unit_matrix)
            svd_results[str(int(axis))][space] = {
                "raw_response_rows": raw_stats,
                "unit_direction_rows": unit_stats,
            }
            for row_mode, stats in (
                ("raw_response_rows", raw_stats),
                ("unit_direction_rows", unit_stats),
            ):
                svd_csv_rows.append(
                    {
                        "axis_degrees": axis,
                        "space": space,
                        "row_mode": row_mode,
                        "uncentered_leading_energy_fraction": stats[
                            "uncentered_leading_energy_fraction"
                        ],
                        "centered_leading_energy_fraction": stats[
                            "centered_leading_energy_fraction"
                        ],
                        "centered_total_energy_over_uncentered_total_energy": stats[
                            "centered_total_energy_over_uncentered_total_energy"
                        ],
                    }
                )
    with (ROOT / "svd_centered_uncentered.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(svd_csv_rows[0]))
        writer.writeheader()
        writer.writerows(svd_csv_rows)

    stable_90_after = [
        row
        for row in analysis_rows
        if row["axis_degrees"] == 90.0 and row["offset_degrees"] in STABLE_OFFSETS
    ]
    lambda_max_relative_deviation = float(
        np.max(np.abs(lambda_values - lambda_star)) / abs(lambda_star)
    )
    max_abs_c_over_a = float(max(abs(row["C_over_A"]) for row in stable_90_after))
    angle_blind_to_s = angle_degrees(d_zero, S)
    criteria = {
        "lambda_stable_within_5_percent": {
            "threshold": LAMBDA_MAX_RELATIVE_DEVIATION_THRESHOLD,
            "observed_max_relative_deviation": lambda_max_relative_deviation,
            "pass": lambda_max_relative_deviation
            <= LAMBDA_MAX_RELATIVE_DEVIATION_THRESHOLD,
        },
        "blind_zero_sum_within_3_degrees_of_s": {
            "threshold_degrees": BLIND_ANGLE_TO_S_THRESHOLD_DEGREES,
            "observed_degrees": angle_blind_to_s,
            "pass": angle_blind_to_s <= BLIND_ANGLE_TO_S_THRESHOLD_DEGREES,
        },
        "leakage_C_over_A_at_most_1_percent": {
            "threshold": MAX_ABS_C_OVER_A_THRESHOLD,
            "observed_max_abs_C_over_A": max_abs_c_over_a,
            "pass": max_abs_c_over_a <= MAX_ABS_C_OVER_A_THRESHOLD,
        },
    }
    all_criteria_pass = all(item["pass"] for item in criteria.values())

    comparison: dict[str, Any] = {}
    for axis in (90.0, 270.0):
        stable_axis = [
            row
            for row in analysis_rows
            if row["axis_degrees"] == axis and row["offset_degrees"] in STABLE_OFFSETS
        ]
        comparison[str(int(axis))] = {
            "mean_abs_A_over_delta_norm": float(
                np.mean([row["abs_A_over_delta_norm"] for row in stable_axis])
            ),
            "mean_abs_B_over_delta_norm": float(
                np.mean([row["abs_B_over_delta_norm"] for row in stable_axis])
            ),
            "mean_abs_C_over_delta_norm": float(
                np.mean([row["abs_C_over_delta_norm"] for row in stable_axis])
            ),
            "mean_s_component_norm_over_delta_norm": float(
                np.mean([row["s_component_norm_over_delta_norm"] for row in stable_axis])
            ),
            "mean_a_component_norm_over_delta_norm": float(
                np.mean([row["a_component_norm_over_delta_norm"] for row in stable_axis])
            ),
            "mean_n_component_norm_over_delta_norm": float(
                np.mean([row["n_component_norm_over_delta_norm"] for row in stable_axis])
            ),
        }

    c_signs_90 = [int(np.sign(row["C"])) for row in analysis_rows if row["axis_degrees"] == 90.0]
    c_slopes_90 = [
        row["abs_C_adjacent_loglog_slope"]
        for row in analysis_rows
        if row["axis_degrees"] == 90.0 and row["abs_C_adjacent_loglog_slope"] != ""
    ]
    fixed_residuals = np.asarray(
        [row["relative_residual_after_d_star_projection"] for row in stable_90_after]
    )
    s_residuals = np.asarray(
        [row["relative_residual_after_s_projection"] for row in stable_90_after]
    )
    result = {
        "schema_version": "1.0",
        "status": "COMPLETE",
        "classification": (
            "STRICT_FIXED_DIRECTION_CONFIRMED"
            if all_criteria_pass
            else "ZERO_SUM_PLANE_CONFIRMED_STRICT_FIXED_LAMBDA_NOT_CONFIRMED"
        ),
        "source_solve_count": 38,
        "new_solver_runs": 0,
        "orthogonal_decomposition": {
            "s": S.tolist(),
            "a": A_BASIS.tolist(),
            "n": N.tolist(),
            "formula_A": "(delta0-2*delta2+delta4)/6",
            "formula_B": "(delta0-delta4)/2",
            "formula_C": "(delta0+delta2+delta4)/3",
            "maximum_reconstruction_relative_error": float(
                max(row["basis_reconstruction_relative_error"] for row in analysis_rows)
            ),
        },
        "universal_mode": {
            "b0_rank": int(b0_rank),
            "sigma_reconstruction_relative_residual": sigma_relative_residual,
            "kappa_sigma": kappa_sigma,
            "universal_radius": 1.0 / (4.0 * kappa_sigma),
        },
        "fixed_direction_90_stable_window": {
            "offsets_degrees": STABLE_OFFSETS,
            "lambda_values_B_over_A": lambda_values.tolist(),
            "lambda_star_origin_least_squares_B_on_A": lambda_star,
            "lambda_mean": float(np.mean(lambda_values)),
            "lambda_sample_std": float(np.std(lambda_values, ddof=1)),
            "lambda_coefficient_of_variation": float(
                np.std(lambda_values, ddof=1) / abs(np.mean(lambda_values))
            ),
            "lambda_max_relative_deviation_from_lambda_star": lambda_max_relative_deviation,
            "d_star": d_star.tolist(),
            "d_star_unit": d_star_unit.tolist(),
            "mean_relative_residual_after_d_star_projection": float(np.mean(fixed_residuals)),
            "mean_relative_residual_after_s_projection": float(np.mean(s_residuals)),
            "mean_residual_reduction_fraction": float(
                1.0 - np.mean(fixed_residuals) / np.mean(s_residuals)
            ),
            "maximum_angle_to_d_star_degrees": float(
                max(row["angle_to_d_star_degrees"] for row in stable_90_after)
            ),
        },
        "blind_zero_sum_direction": {
            "method": (
                "Project each stable-window 3-group vector onto sum(delta)=0, then take "
                "the unit right singular vector maximizing total projection energy."
            ),
            "direction_unit": d_zero.tolist(),
            "projection_energy_fraction": float(
                blind_singular_values[0] ** 2 / np.sum(blind_singular_values**2)
            ),
            "angle_to_s_degrees": angle_blind_to_s,
            "angle_to_d_star_degrees": angle_degrees(d_zero, d_star),
            "implied_lambda_B_over_A": d_zero_B / d_zero_A,
        },
        "C_leakage_90": {
            "C_signs_in_descending_offset_order": c_signs_90,
            "sign_change_present": any(
                c_signs_90[index] != c_signs_90[index + 1]
                for index in range(len(c_signs_90) - 1)
            ),
            "adjacent_abs_C_loglog_slopes": c_slopes_90,
            "stable_window_max_abs_C_over_A": max_abs_c_over_a,
            "assessment": (
                "Adjacent slopes are descriptive only. A sign change and strongly varying "
                "slopes do not support a single saved-offset power law."
            ),
        },
        "svd_centered_uncentered": svd_results,
        "axis_comparison_stable_window": comparison,
        "preregistered_decision_criteria": criteria,
        "all_strict_hit_criteria_pass": all_criteria_pass,
        "claim_boundary": (
            "Read-only finite-grid analysis of 38 saved primal solves. The blind direction "
            "is estimated only from the fixed five-offset stable window. No power law is "
            "fit. No KKT dual cause, exact coefficient identity, or continuum-limit claim "
            "is inferred."
        ),
    }
    write_json(ROOT / "fixed_direction_result.json", result)

    scope = {
        "config_id": "STAGE0_V3_NEAR_NULL_FIXED_DIRECTION_VALIDATION_V1",
        "mode": "read_only_saved_artifacts",
        "source_solve_count": 38,
        "new_solver_runs": 0,
        "axes": [90.0, 270.0],
        "offsets_degrees": OFFSETS,
        "stable_window_offsets_degrees": STABLE_OFFSETS,
        "fixed_before_analysis": {
            "basis_s": S.tolist(),
            "basis_a": A_BASIS.tolist(),
            "basis_n": N.tolist(),
            "lambda_estimator": "origin least squares B=lambda*A on the five stable offsets",
            "blind_direction_constraint": "sum(d)=0 and norm(d)=1",
            "lambda_max_relative_deviation_threshold": LAMBDA_MAX_RELATIVE_DEVIATION_THRESHOLD,
            "blind_angle_to_s_threshold_degrees": BLIND_ANGLE_TO_S_THRESHOLD_DEGREES,
            "max_abs_C_over_A_threshold": MAX_ABS_C_OVER_A_THRESHOLD,
            "power_law_policy": "adjacent absolute-C log-log slopes only; no fitted power law",
        },
        "claim_boundary": result["claim_boundary"],
    }
    write_json(ROOT / "ANALYSIS_SCOPE.json", scope)

    write_json(
        ROOT / "PROVENANCE_SHA256.json",
        {
            "schema_version": "1.0",
            "new_solver_runs": 0,
            "inputs": {
                str(MAPS): sha256(MAPS),
                **{str(path): sha256(path) for path in solve_paths},
            },
        },
    )

    top_rows = sorted(
        [row for row in analysis_rows if row["axis_degrees"] == 90.0],
        key=lambda row: row["offset_degrees"],
        reverse=True,
    )
    x = np.asarray([row["offset_degrees"] for row in top_rows])
    stable_mask = np.asarray([value in STABLE_OFFSETS for value in x])
    fig, axes = plt.subplots(2, 2, figsize=(13.8, 9.0))

    axes[0, 0].plot(x, [row["B_over_A"] for row in top_rows], "o-", color="#4c78a8")
    axes[0, 0].axhline(lambda_star, color="black", linestyle="--", label="lambda star")
    axes[0, 0].scatter(
        x[stable_mask],
        np.asarray([row["B_over_A"] for row in top_rows])[stable_mask],
        facecolors="none",
        edgecolors="#e45756",
        s=90,
        label="stable window",
    )
    axes[0, 0].set_xscale("log")
    axes[0, 0].invert_xaxis()
    axes[0, 0].set_xlabel("offset (degrees)")
    axes[0, 0].set_ylabel("B/A")
    axes[0, 0].set_title("Fixed-lambda test")
    axes[0, 0].legend(frameon=False)

    c_over_a = np.asarray([row["C_over_A"] for row in top_rows])
    axes[0, 1].plot(x, c_over_a, "o-", color="#e45756")
    axes[0, 1].axhline(0.0, color="black", linewidth=0.7)
    axes[0, 1].axhline(MAX_ABS_C_OVER_A_THRESHOLD, color="gray", linestyle=":")
    axes[0, 1].axhline(-MAX_ABS_C_OVER_A_THRESHOLD, color="gray", linestyle=":")
    axes[0, 1].set_xscale("log")
    axes[0, 1].invert_xaxis()
    axes[0, 1].set_xlabel("offset (degrees)")
    axes[0, 1].set_ylabel("C/A")
    axes[0, 1].set_title("Observable leakage and sign change")

    labels = ["s component", "a component", "n component"]
    values90 = [
        comparison["90"]["mean_s_component_norm_over_delta_norm"],
        comparison["90"]["mean_a_component_norm_over_delta_norm"],
        comparison["90"]["mean_n_component_norm_over_delta_norm"],
    ]
    values270 = [
        comparison["270"]["mean_s_component_norm_over_delta_norm"],
        comparison["270"]["mean_a_component_norm_over_delta_norm"],
        comparison["270"]["mean_n_component_norm_over_delta_norm"],
    ]
    xpos = np.arange(3)
    axes[1, 0].bar(xpos - 0.18, values90, width=0.36, label="90 deg")
    axes[1, 0].bar(xpos + 0.18, values270, width=0.36, label="270 deg")
    axes[1, 0].set_xticks(xpos, labels)
    axes[1, 0].set_ylabel("mean component norm / |delta|")
    axes[1, 0].set_title("Orthogonal-coordinate control")
    axes[1, 0].legend(frameon=False)

    spaces = ["group3", "coefficient16", "physical"]
    unc = [
        svd_results["90"][space]["unit_direction_rows"][
            "uncentered_leading_energy_fraction"
        ]
        for space in spaces
    ]
    cen = [
        svd_results["90"][space]["unit_direction_rows"][
            "centered_leading_energy_fraction"
        ]
        for space in spaces
    ]
    axes[1, 1].bar(xpos - 0.18, unc, width=0.36, label="uncentered")
    axes[1, 1].bar(xpos + 0.18, cen, width=0.36, label="centered")
    axes[1, 1].set_xticks(xpos, ["3-group", "coefficient", "physical"])
    axes[1, 1].set_ylim(0.0, 1.05)
    axes[1, 1].set_ylabel("leading energy fraction")
    axes[1, 1].set_title("90 deg unit-direction SVD/PCA")
    axes[1, 1].legend(frameon=False)
    fig.tight_layout()
    fig.savefig(ROOT / "fixed_direction_diagnostics.png", dpi=180)
    plt.close(fig)

    criterion_word = "PASS" if all_criteria_pass else "MIXED / STRICT FIXED-LAMBDA FAIL"
    blind = result["blind_zero_sum_direction"]
    group_svd = svd_results["90"]["group3"]["unit_direction_rows"]
    coeff_svd = svd_results["90"]["coefficient16"]["unit_direction_rows"]
    physical_svd = svd_results["90"]["physical"]["unit_direction_rows"]
    group_svd_raw = svd_results["90"]["group3"]["raw_response_rows"]
    coeff_svd_raw = svd_results["90"]["coefficient16"]["raw_response_rows"]
    physical_svd_raw = svd_results["90"]["physical"]["raw_response_rows"]
    readme = f"""# Near-null fixed-direction validation

Status: **COMPLETE**  
Decision: **{criterion_word}**  
Source support solves: **38**  
New solver runs: **0**

## Main result

The zero-sum structure is confirmed, but the preregistered strict fixed-`lambda` criterion is not. Over the five-offset stable window,

`lambda=B/A = {lambda_values.tolist()}`

and the origin least-squares value is `lambda_star={lambda_star:.9f}`. The maximum relative departure from this value is `{100.0*lambda_max_relative_deviation:.2f}%`, above the fixed 5% threshold. Thus the data do not support an offset-independent `s+lambda*a` direction at the requested precision.

The average fixed direction is

`d_star = {d_star.tolist()}`,

and it reduces the mean projection residual from `{100.0*np.mean(s_residuals):.4f}%` for `s=(1,-2,1)` to `{100.0*np.mean(fixed_residuals):.4f}%`. The maximum stable-window angle to `d_star` is only `{result['fixed_direction_90_stable_window']['maximum_angle_to_d_star_degrees']:.4f}` degrees. Thus the geometric average direction is tight because `lambda` is small, even though relative invariance of `lambda` fails the declared rule.

## Blind zero-sum result

The blind maximum-energy zero-sum direction is

`d_zero = {np.round(d_zero, 12).tolist()}`.

It lies `{blind['angle_to_s_degrees']:.4f}` degrees from normalized `(1,-2,1)`, explains `{100.0*blind['projection_energy_fraction']:.6f}%` of the stable-window zero-sum projection energy, and implies `lambda={blind['implied_lambda_B_over_A']:.9f}`. This passes the 3-degree blind-direction criterion without using `(1,-2,1)` in the fit.

## Leakage C

The stable-window maximum `|C/A|` is `{100.0*max_abs_c_over_a:.4f}%`, passing the 1% leakage threshold. `C` changes sign across the saved offsets, and the adjacent absolute-C log-log slopes are `{[round(float(value), 4) for value in c_slopes_90]}`. They are not approximately constant, so no single power law or plateau is claimed.

## Centered versus uncentered

For unit direction rows at 90 degrees, the leading uncentered/centered energy fractions are:

- 3-group space: `{100.0*group_svd['uncentered_leading_energy_fraction']:.4f}%` / `{100.0*group_svd['centered_leading_energy_fraction']:.4f}%`
- 16-dimensional coefficient space: `{100.0*coeff_svd['uncentered_leading_energy_fraction']:.4f}%` / `{100.0*coeff_svd['centered_leading_energy_fraction']:.4f}%`
- physical-amplitude space: `{100.0*physical_svd['uncentered_leading_energy_fraction']:.4f}%` / `{100.0*physical_svd['centered_leading_energy_fraction']:.4f}%`

For the unnormalized response rows, the centered leading fractions are `{100.0*group_svd_raw['centered_leading_energy_fraction']:.4f}%`, `{100.0*coeff_svd_raw['centered_leading_energy_fraction']:.4f}%`, and `{100.0*physical_svd_raw['centered_leading_energy_fraction']:.4f}%` in the same three spaces. The centered total energy is only `{100.0*group_svd['centered_total_energy_over_uncentered_total_energy']:.6f}%`, `{100.0*coeff_svd['centered_total_energy_over_uncentered_total_energy']:.6f}%`, and `{100.0*physical_svd['centered_total_energy_over_uncentered_total_energy']:.6f}%` for the unit-direction rows.

The uncentered result says the responses lie close to a common ray. After centering, the small direction changes are themselves mostly one-dimensional, but their total energy is tiny; this is a drift diagnostic, not a second large physical mode.

## 90 versus 270 control

Stable-window mean orthogonal component norms divided by `|delta|` are:

- 90 degrees `(s,a,n)`: `{[round(value, 6) for value in values90]}`
- 270 degrees `(s,a,n)`: `{[round(value, 6) for value in values270]}`

Thus 90 degrees concentrates in the zero-sum `s` direction with tiny `n` leakage, whereas 270 degrees is dominated by the sum direction `n`.

## Decision boundary

Two of three strict criteria pass: blind zero-sum recovery and small observable leakage. The fixed-`lambda` stability criterion fails. The supported compression is therefore

`delta(offset) = alpha(offset)*d_average + small zero-sum drift + epsilon(offset)*n`,

not a single fixed `d_star` at 5% relative precision in `lambda`.

No solver was run, no power law was fit, and no optimizer/KKT cause is claimed.

## Re-run

`python analyze_fixed_direction.py`
"""
    (ROOT / "README.md").write_text(readme, encoding="utf-8")

    manifest_names = [
        "ANALYSIS_SCOPE.json",
        "PROVENANCE_SHA256.json",
        "README.md",
        "abc_all_offsets.csv",
        "analyze_fixed_direction.py",
        "fixed_direction_diagnostics.png",
        "fixed_direction_result.json",
        "read_only_preflight.json",
        "svd_centered_uncentered.csv",
    ]
    (ROOT / "MANIFEST_SHA256.txt").write_text(
        "".join(f"{sha256(ROOT / name)}  {name}\n" for name in manifest_names),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "status": "COMPLETE",
                "classification": result["classification"],
                "new_solver_runs": 0,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
