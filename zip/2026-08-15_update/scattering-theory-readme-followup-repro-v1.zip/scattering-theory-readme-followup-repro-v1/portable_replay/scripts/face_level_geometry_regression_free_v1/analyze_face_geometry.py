from __future__ import annotations

import csv
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
from typing import Any

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / ".mplconfig"))

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
PREREG = ROOT / "FACE_GEOMETRY_SCOPE.preregistered.json"
PRIOR_AUDIT = WORKSPACE / "outputs" / "active_demand_adversarial_audit_v1"
PRIOR_RESULT = PRIOR_AUDIT / "adversarial_audit_result.json"
PRIOR_SCOPE = PRIOR_AUDIT / "ADVERSARIAL_SCOPE.preregistered.json"
PRIOR_VARIANTS = PRIOR_AUDIT / "response_variants.csv"
PRIOR_MANIFEST = PRIOR_AUDIT / "MANIFEST_SHA256.txt"
FIXED_RESULT = WORKSPACE / "outputs" / "near_null_fixed_direction_validation_v1" / "fixed_direction_result.json"
UPSTREAM = WORKSPACE / "base_repro"
MAPS = UPSTREAM / "inputs" / "frozen_maps.npz"
SOLVES = UPSTREAM / "inputs" / "solves"

EXPECTED = {
    PREREG: "B0F45F1090E290F78E7781F9B0473E68F3804664EDC0307B1697A1B710305AE3",
    PRIOR_RESULT: "26300E557C75C2C223743A3E388B25D5BF7BD4C2BE42977021BD6AADB8C60FAC",
    PRIOR_SCOPE: "0CC53B8CC747936B9D39A86F997A761F2606E98809B427BEEE618C96B79522EF",
    PRIOR_VARIANTS: "DE658079CD750FEB471061E77538D8921DC5358B528601C97CADE3CA5ED629B8",
    PRIOR_MANIFEST: "8F7AB7EF4376151076DBC88AF4E639483AD9272D93EA9002DEF8F2607FCC23F0",
    FIXED_RESULT: "C58E3DF0696740912062C2873CF903CE37754679F1404A17708BEB3B826D6C69",
    MAPS: "3BBC7A64271C0CFF9B6C53FE76300DEFE14AB2A4EC9675F1C72E5C7132592F95",
}

H_DEGREES = np.asarray(
    [0.0439453125, 0.02197265625, 0.010986328125, 0.0054931640625, 0.00274658203125],
    dtype=float,
)
REP_H = 0.010986328125
FACE90 = ((0, 11), (0, 12), (0, 24), (0, 29))
TAU_ABS = 1.0e-7
TAU_REL = 1.0e-7
TOL = 1.0e-15


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty CSV: {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def average_ranks(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    start = 0
    while start < len(values):
        stop = start + 1
        while stop < len(values) and values[order[stop]] == values[order[start]]:
            stop += 1
        ranks[order[start:stop]] = 0.5 * (start + stop - 1) + 1.0
        start = stop
    return ranks


def spearman(left: np.ndarray, right: np.ndarray) -> float:
    x = average_ranks(left) - np.mean(average_ranks(left))
    y = average_ranks(right) - np.mean(average_ranks(right))
    denominator = float(np.linalg.norm(x) * np.linalg.norm(y))
    return float(np.dot(x, y) / denominator) if denominator > 0.0 else math.nan


def three_way(value: float, tolerance: float) -> str:
    if value > tolerance:
        return "PASS"
    if value < -tolerance:
        return "FAIL"
    return "BOUNDARY"


def center_boundary_keys(
    z: np.ndarray,
    a_coeff: np.ndarray,
    b_coeff: np.ndarray,
    sigma: np.ndarray,
    ell_list: list[int],
) -> set[tuple[int, int]]:
    output: set[tuple[int, int]] = set()
    for ell_index, ell in enumerate(ell_list):
        for s_index in range(len(sigma)):
            x = float(a_coeff[ell_index, s_index] @ z)
            y = float(b_coeff[ell_index, s_index] @ z)
            matrix = np.asarray(
                [
                    [1.0 - 0.5 * sigma[s_index] * y, math.sqrt(sigma[s_index]) * x],
                    [math.sqrt(sigma[s_index]) * x, 2.0 * y],
                ]
            )
            eig_min = float(np.linalg.eigvalsh(matrix)[0])
            disk_slack = float(2.0 * y - sigma[s_index] * (x * x + y * y))
            norm2 = float(np.linalg.norm(matrix, 2))
            eig_tol = TAU_ABS + TAU_REL * max(1.0, norm2)
            disk_tol = TAU_ABS + TAU_REL * max(1.0, norm2 * norm2)
            if "BOUNDARY" in (
                three_way(eig_min, eig_tol),
                three_way(disk_slack, disk_tol),
            ):
                output.add((ell, s_index))
    return output


def group_vector(vector: np.ndarray, q2: np.ndarray) -> np.ndarray:
    return np.asarray(
        [
            q2[1:6] @ vector[1:6],
            q2[6:11] @ vector[6:11],
            q2[11:16] @ vector[11:16],
        ],
        dtype=float,
    )


def structural_contrast(s_indices: np.ndarray) -> np.ndarray:
    contrast = np.asarray(s_indices, dtype=float) - float(np.mean(s_indices))
    norm = float(np.linalg.norm(contrast))
    if norm == 0.0:
        raise ValueError("degenerate structural contrast")
    return contrast / norm


def orient_direction(direction: np.ndarray, contrast: np.ndarray) -> np.ndarray:
    direction = np.asarray(direction, dtype=float)
    dot = float(np.dot(direction, contrast))
    if dot < 0.0:
        return -direction
    if dot == 0.0:
        first = next((value for value in direction if value != 0.0), 0.0)
        if first < 0.0:
            return -direction
    return direction


def pca_from_centered(centered: np.ndarray, contrast: np.ndarray) -> dict[str, Any]:
    _, singular_values, vh = np.linalg.svd(centered, full_matrices=False)
    energies = singular_values**2
    total = float(np.sum(energies))
    fractions = energies / total if total > 0.0 else np.zeros_like(energies)
    direction = orient_direction(vh[0], contrast)
    scores = centered @ direction
    reconstructed = np.outer(scores, direction)
    denominators = np.linalg.norm(centered, axis=1)
    residuals = np.linalg.norm(centered - reconstructed, axis=1)
    residual_fractions = np.divide(
        residuals,
        denominators,
        out=np.zeros_like(residuals),
        where=denominators > 0.0,
    )
    return {
        "singular_values": singular_values,
        "explained_fractions": fractions,
        "direction": direction,
        "scores": scores,
        "residual_fractions": residual_fractions,
    }


def full_pca(proportions: np.ndarray, s_indices: np.ndarray) -> dict[str, Any]:
    mean = np.mean(proportions, axis=0)
    centered = proportions - mean
    output = pca_from_centered(centered, structural_contrast(s_indices))
    output["mean"] = mean
    output["centered"] = centered
    return output


def loso_pca(
    proportions: np.ndarray,
    s_indices: np.ndarray,
    full_direction: np.ndarray,
) -> list[dict[str, Any]]:
    contrast = structural_contrast(s_indices)
    rows: list[dict[str, Any]] = []
    for held_out in range(len(proportions)):
        keep = np.arange(len(proportions)) != held_out
        train_mean = np.mean(proportions[keep], axis=0)
        training = proportions[keep] - train_mean
        fit = pca_from_centered(training, contrast)
        direction = fit["direction"]
        dot = float(np.clip(np.dot(direction, full_direction), -1.0, 1.0))
        angle = math.degrees(math.acos(dot))
        delta = proportions[held_out] - train_mean
        score = float(np.dot(delta, direction))
        residual = delta - score * direction
        delta_norm = float(np.linalg.norm(delta))
        rows.append(
            {
                "held_out_index": held_out,
                "gamma": score,
                "training_pc1_fraction": float(fit["explained_fractions"][0]),
                "angle_to_full_pc1_degrees": angle,
                "held_out_residual_fraction": (
                    float(np.linalg.norm(residual) / delta_norm) if delta_norm > 0.0 else 0.0
                ),
                "direction": direction,
                "training_mean": train_mean,
            }
        )
    return rows


def drift_relation(gamma: np.ndarray, drift: np.ndarray) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    centered = np.asarray(
        [drift[index] - np.mean(np.delete(drift, index)) for index in range(len(drift))],
        dtype=float,
    )
    observed_rho = spearman(gamma, drift)
    observed_sign_count = int(np.sum(gamma * centered > 0.0))
    permutation_rows: list[dict[str, Any]] = []
    for permutation_index, permutation in enumerate(itertools.permutations(range(len(drift)))):
        permuted = drift[np.asarray(permutation)]
        permuted_centered = np.asarray(
            [
                permuted[index] - np.mean(np.delete(permuted, index))
                for index in range(len(permuted))
            ],
            dtype=float,
        )
        rho = spearman(gamma, permuted)
        sign_count = int(np.sum(gamma * permuted_centered > 0.0))
        permutation_rows.append(
            {
                "permutation_index": permutation_index,
                "permutation": ",".join(str(value) for value in permutation),
                "is_identity": permutation == tuple(range(len(drift))),
                "spearman": rho,
                "abs_spearman": abs(rho),
                "sign_concordance_count": sign_count,
            }
        )
    one_sided_rho_count = sum(row["spearman"] >= observed_rho - TOL for row in permutation_rows)
    abs_rho_count = sum(row["abs_spearman"] >= abs(observed_rho) - TOL for row in permutation_rows)
    sign_count_tail = sum(
        row["sign_concordance_count"] >= observed_sign_count for row in permutation_rows
    )
    relation_pass = observed_rho >= 0.8 - TOL and observed_sign_count == len(drift)
    return (
        {
            "spearman": observed_rho,
            "sign_concordance_count": observed_sign_count,
            "relation_pass": relation_pass,
            "one_sided_spearman_tail_count": one_sided_rho_count,
            "one_sided_spearman_tail_fraction": one_sided_rho_count / len(permutation_rows),
            "absolute_spearman_tail_count": abs_rho_count,
            "absolute_spearman_tail_fraction": abs_rho_count / len(permutation_rows),
            "sign_concordance_tail_count": sign_count_tail,
            "sign_concordance_tail_fraction": sign_count_tail / len(permutation_rows),
            "cross_fitted_centered_drift": centered.tolist(),
        },
        permutation_rows,
    )


def face_proportions(
    blocks: tuple[tuple[int, int], ...],
    responses: dict[tuple[float, float], dict[str, Any]],
    axis: float,
    a_coeff: np.ndarray,
    b_coeff: np.ndarray,
    sigma: np.ndarray,
    ell_list: list[int],
) -> tuple[np.ndarray, np.ndarray]:
    ell_to_index = {ell: index for index, ell in enumerate(ell_list)}
    demand_rows = []
    for h in H_DEGREES:
        v = responses[(axis, float(h))]["v"]
        demands = []
        for ell, s_index in blocks:
            ell_index = ell_to_index[ell]
            x1 = float(a_coeff[ell_index, s_index] @ v)
            y1 = float(b_coeff[ell_index, s_index] @ v)
            demands.append(float(sigma[s_index] * (x1 * x1 + y1 * y1)))
        demand_rows.append(demands)
    demands_array = np.asarray(demand_rows, dtype=float)
    proportions = demands_array / np.sum(demands_array, axis=1, keepdims=True)
    return demands_array, proportions


def coordinate_invariance(
    centered: np.ndarray,
    s_indices: np.ndarray,
    reference: dict[str, Any],
) -> dict[str, Any]:
    contrast = structural_contrast(s_indices)
    reference_fractions = reference["explained_fractions"]
    reference_scores = reference["scores"]
    permutation_fraction_error = 0.0
    permutation_score_error = 0.0
    for permutation in itertools.permutations(range(centered.shape[1])):
        indices = np.asarray(permutation)
        transformed = centered[:, indices]
        fit = pca_from_centered(transformed, contrast[indices])
        permutation_fraction_error = max(
            permutation_fraction_error,
            float(np.max(np.abs(fit["explained_fractions"] - reference_fractions))),
        )
        permutation_score_error = max(
            permutation_score_error,
            float(np.max(np.abs(fit["scores"] - reference_scores))),
        )
    sign_fraction_error = 0.0
    sign_score_error = 0.0
    for signs_tuple in itertools.product((-1.0, 1.0), repeat=centered.shape[1]):
        signs = np.asarray(signs_tuple)
        transformed = centered * signs
        fit = pca_from_centered(transformed, contrast * signs)
        sign_fraction_error = max(
            sign_fraction_error,
            float(np.max(np.abs(fit["explained_fractions"] - reference_fractions))),
        )
        sign_score_error = max(
            sign_score_error,
            float(np.max(np.abs(fit["scores"] - reference_scores))),
        )
    return {
        "label_permutation_count": math.factorial(centered.shape[1]),
        "coordinate_sign_flip_count": 2 ** centered.shape[1],
        "max_label_permutation_explained_fraction_error": permutation_fraction_error,
        "max_label_permutation_score_error": permutation_score_error,
        "max_sign_flip_explained_fraction_error": sign_fraction_error,
        "max_sign_flip_score_error": sign_score_error,
        "pass_at_1e_minus_12": max(
            permutation_fraction_error,
            permutation_score_error,
            sign_fraction_error,
            sign_score_error,
        )
        <= 1.0e-12,
        "interpretation": "Coordinate permutations and sign flips are orthogonal transformations, so they are invariance checks rather than inferential negative controls for PCA.",
    }


def main() -> int:
    scope = json.loads(PREREG.read_text(encoding="utf-8"))
    prior_result = json.loads(PRIOR_RESULT.read_text(encoding="utf-8"))
    fixed_result = json.loads(FIXED_RESULT.read_text(encoding="utf-8"))
    preflight: dict[str, bool] = {
        f"hash_{path.name}": sha256(path) == expected for path, expected in EXPECTED.items()
    }
    preflight.update(
        {
            "scope_sealed_before_analysis": scope["sealed_before_analysis"] is True,
            "scope_new_solver_runs_zero": scope["new_solver_runs"] == 0,
            "scope_forbids_regression": any(
                "regression" in item for item in scope["forbidden_methods"]
            ),
            "prior_pair_specificity_rejected": prior_result["competitor_qualifier"]
            == "ELL0_FACE_LEVEL_NOT_PAIR_SPECIFIC",
        }
    )

    maps = np.load(MAPS, allow_pickle=False)
    a_coeff = np.asarray(maps["a_coeff"], dtype=float)
    b_coeff = np.asarray(maps["b_coeff"], dtype=float)
    s_grid = np.asarray(maps["s_grid"], dtype=float)
    q0 = np.asarray(maps["q0"], dtype=float)
    q2 = np.asarray(maps["q2"], dtype=float)
    ell_list = [int(value) for value in maps["ell_list"]]
    mass = float(maps["m"][0])
    sigma = np.sqrt((s_grid - 4.0 * mass * mass) / s_grid)
    b0 = b_coeff[0, :, 1:6]
    c_sigma = np.linalg.lstsq(b0, sigma, rcond=None)[0]

    solve_paths = sorted(SOLVES.glob("solve_*.json"))
    solves: dict[tuple[float, float], dict[str, Any]] = {}
    for path in solve_paths:
        value = json.loads(path.read_text(encoding="utf-8"))
        solves[(float(value["axis_degrees"]), float(value["offset_degrees"]))] = value
    required = {
        (axis, signed * float(h))
        for axis in (90.0, 270.0)
        for h in H_DEGREES
        for signed in (-2.0, -1.0, 1.0, 2.0)
    } | {(90.0, 0.0), (270.0, 0.0)}
    preflight.update(
        {
            "solve_file_count_38": len(solve_paths) == 38,
            "unique_solve_count_38": len(solves) == 38,
            "all_source_status_pass": all(row["status"] == "PASS" for row in solves.values()),
            "all_required_offsets_present": required.issubset(solves),
        }
    )

    center_active: dict[float, set[tuple[int, int]]] = {}
    for axis in (90.0, 270.0):
        center_active[axis] = center_boundary_keys(
            np.asarray(solves[(axis, 0.0)]["z"], dtype=float),
            a_coeff,
            b_coeff,
            sigma,
            ell_list,
        )
    active90_ell0 = tuple(sorted(key for key in center_active[90.0] if key[0] == 0))
    active270_ell0 = tuple(sorted(key for key in center_active[270.0] if key[0] == 0))
    preflight.update(
        {
            "90_face_ids_match_preregistered": active90_ell0 == FACE90,
            "270_matched_ids_are_center_boundary": set(FACE90).issubset(center_active[270.0]),
        }
    )

    d_zero = np.asarray(fixed_result["blind_zero_sum_direction"]["direction_unit"], dtype=float)
    d_zero /= np.linalg.norm(d_zero)
    n_hat = np.ones(3) / math.sqrt(3.0)
    d_perp = np.cross(n_hat, d_zero)
    d_perp /= np.linalg.norm(d_perp)
    if np.dot(d_perp, np.asarray([1.0, 0.0, -1.0])) < 0.0:
        d_perp = -d_perp

    responses: dict[tuple[float, float], dict[str, Any]] = {}
    for axis in (90.0, 270.0):
        z0 = np.asarray(solves[(axis, 0.0)]["z"], dtype=float)
        for h_degrees in H_DEGREES:
            h = math.radians(float(h_degrees))
            z_plus = np.asarray(solves[(axis, float(h_degrees))]["z"], dtype=float)
            z_minus = np.asarray(solves[(axis, -float(h_degrees))]["z"], dtype=float)
            v = (z_plus - z_minus) / (2.0 * h)
            u = (z_plus + z_minus - 2.0 * z0) / (2.0 * h * h)
            responses[(axis, float(h_degrees))] = {"v": v, "u": u, "a1": float(q0 @ v)}

    def universal(axis: float, a1: float) -> np.ndarray:
        vector = np.zeros(16)
        sign = -1.0 if axis == 90.0 else 1.0
        vector[1:6] = sign * 2.0 * a1 * a1 * c_sigma
        return vector

    drift_by_axis: dict[float, dict[str, np.ndarray]] = {}
    response_rows: list[dict[str, Any]] = []
    for axis in (90.0, 270.0):
        a1_ref = responses[(axis, REP_H)]["a1"]
        variants = {
            "original_r_eta": [],
            "frozen_baseline_r_eta": [],
            "raw_even_eta": [],
            "raw_even_direction": [],
            "raw_even_alpha": [],
        }
        for h in H_DEGREES:
            response = responses[(axis, float(h))]
            original_group = group_vector(response["u"] - universal(axis, response["a1"]), q2)
            frozen_group = group_vector(response["u"] - universal(axis, a1_ref), q2)
            raw_group = group_vector(response["u"], q2)
            original_alpha = float(np.dot(original_group, d_zero))
            original_eta = float(np.dot(original_group, d_perp))
            frozen_alpha = float(np.dot(frozen_group, d_zero))
            frozen_eta = float(np.dot(frozen_group, d_perp))
            raw_alpha = float(np.dot(raw_group, d_zero))
            raw_eta = float(np.dot(raw_group, d_perp))
            values = {
                "original_r_eta": original_eta / original_alpha,
                "frozen_baseline_r_eta": frozen_eta / frozen_alpha,
                "raw_even_eta": raw_eta,
                "raw_even_direction": raw_eta / raw_alpha,
                "raw_even_alpha": raw_alpha,
            }
            for name, value in values.items():
                variants[name].append(value)
            response_rows.append(
                {
                    "axis_degrees": axis,
                    "h_degrees": float(h),
                    "a1": response["a1"],
                    "original_r_eta": values["original_r_eta"],
                    "frozen_baseline_r_eta": values["frozen_baseline_r_eta"],
                    "raw_even_eta": raw_eta,
                    "raw_even_alpha": raw_alpha,
                    "raw_even_direction": values["raw_even_direction"],
                }
            )
        drift_by_axis[axis] = {name: np.asarray(values) for name, values in variants.items()}

    prior_variants = list(csv.DictReader(PRIOR_VARIANTS.open("r", encoding="utf-8")))
    prior_lookup = {float(row["h_degrees"]): row for row in prior_variants}
    reproduction_errors = []
    prior_names = {
        "original_r_eta": "original_r_eta",
        "frozen_baseline_r_eta": "frozen_baseline_r_eta",
        "raw_even_eta": "raw_even_eta",
        "raw_even_direction": "raw_even_r_eta",
    }
    for index, h in enumerate(H_DEGREES):
        for new_name, old_name in prior_names.items():
            reproduction_errors.append(
                abs(drift_by_axis[90.0][new_name][index] - float(prior_lookup[float(h)][old_name]))
            )
    preflight["reproduces_prior_90_variants_at_1e_minus_12"] = bool(
        max(reproduction_errors) <= 1.0e-12
    )

    if not all(preflight.values()):
        write_json(
            ROOT / "read_only_preflight.json",
            {"status": "STOP", "checks": preflight, "new_solver_runs": 0},
        )
        return 2
    write_json(
        ROOT / "read_only_preflight.json",
        {"status": "PASS", "checks": preflight, "new_solver_runs": 0},
    )

    face_definitions = {
        "90_primary": (90.0, FACE90),
        "270_matched": (270.0, FACE90),
        "270_native": (270.0, active270_ell0),
    }
    face_data: dict[str, dict[str, Any]] = {}
    geometry_rows: list[dict[str, Any]] = []
    loading_rows: list[dict[str, Any]] = []
    demand_rows: list[dict[str, Any]] = []
    loso_rows: list[dict[str, Any]] = []
    relation_rows: list[dict[str, Any]] = []
    permutation_rows: list[dict[str, Any]] = []

    for face_name, (axis, blocks) in face_definitions.items():
        demands, proportions = face_proportions(
            blocks, responses, axis, a_coeff, b_coeff, sigma, ell_list
        )
        s_indices = np.asarray([block[1] for block in blocks], dtype=float)
        pca = full_pca(proportions, s_indices)
        loso = loso_pca(proportions, s_indices, pca["direction"])
        gamma = np.asarray([row["gamma"] for row in loso], dtype=float)
        rank1_pass = float(pca["explained_fractions"][0]) >= 0.95 - TOL
        face_data[face_name] = {
            "axis": axis,
            "blocks": blocks,
            "demands": demands,
            "proportions": proportions,
            "pca": pca,
            "loso": loso,
            "gamma": gamma,
            "rank1_pass": rank1_pass,
            "relations": {},
        }
        geometry_rows.append(
            {
                "face": face_name,
                "axis_degrees": axis,
                "coordinate_count": len(blocks),
                "effective_simplex_dimension": len(blocks) - 1,
                "pc1_fraction": float(pca["explained_fractions"][0]),
                "pc2_fraction": float(pca["explained_fractions"][1]) if len(pca["explained_fractions"]) > 1 else 0.0,
                "pc3_fraction": float(pca["explained_fractions"][2]) if len(pca["explained_fractions"]) > 2 else 0.0,
                "rank1_pass_at_0p95": rank1_pass,
                "max_loso_angle_degrees": max(row["angle_to_full_pc1_degrees"] for row in loso),
                "max_loso_heldout_residual_fraction": max(row["held_out_residual_fraction"] for row in loso),
                "min_loso_training_pc1_fraction": min(row["training_pc1_fraction"] for row in loso),
            }
        )
        for block_index, block in enumerate(blocks):
            loading_rows.append(
                {
                    "face": face_name,
                    "axis_degrees": axis,
                    "ell": block[0],
                    "s_index": block[1],
                    "s_value": float(s_grid[block[1]]),
                    "mean_proportion": float(pca["mean"][block_index]),
                    "pc1_loading": float(pca["direction"][block_index]),
                }
            )
        for h_index, h in enumerate(H_DEGREES):
            for block_index, block in enumerate(blocks):
                demand_rows.append(
                    {
                        "face": face_name,
                        "axis_degrees": axis,
                        "h_degrees": float(h),
                        "ell": block[0],
                        "s_index": block[1],
                        "quadratic_demand": float(demands[h_index, block_index]),
                        "normalized_face_proportion": float(proportions[h_index, block_index]),
                        "centered_proportion": float(pca["centered"][h_index, block_index]),
                        "full_pc1_loading": float(pca["direction"][block_index]),
                        "full_pc1_score": float(pca["scores"][h_index]),
                    }
                )
            loso_row = loso[h_index]
            row = {
                "face": face_name,
                "axis_degrees": axis,
                "held_out_h_degrees": float(h),
                "cross_fitted_gamma": loso_row["gamma"],
                "training_pc1_fraction": loso_row["training_pc1_fraction"],
                "angle_to_full_pc1_degrees": loso_row["angle_to_full_pc1_degrees"],
                "held_out_residual_fraction": loso_row["held_out_residual_fraction"],
            }
            for variant in (
                "original_r_eta",
                "frozen_baseline_r_eta",
                "raw_even_eta",
                "raw_even_direction",
            ):
                drift = drift_by_axis[axis][variant]
                centered_drift = drift[h_index] - np.mean(np.delete(drift, h_index))
                row[f"{variant}_value"] = float(drift[h_index])
                row[f"{variant}_cross_fitted_centered"] = float(centered_drift)
                row[f"{variant}_positive_sign_concordance"] = bool(
                    loso_row["gamma"] * centered_drift > 0.0
                )
            loso_rows.append(row)

        for variant in (
            "original_r_eta",
            "frozen_baseline_r_eta",
            "raw_even_eta",
            "raw_even_direction",
        ):
            summary, permutations = drift_relation(gamma, drift_by_axis[axis][variant])
            face_data[face_name]["relations"][variant] = summary
            relation_rows.append(
                {
                    "face": face_name,
                    "axis_degrees": axis,
                    "variant": variant,
                    "spearman": summary["spearman"],
                    "positive_sign_concordance_count": summary["sign_concordance_count"],
                    "relation_pass": summary["relation_pass"],
                    "one_sided_spearman_tail_count": summary["one_sided_spearman_tail_count"],
                    "one_sided_spearman_tail_fraction": summary["one_sided_spearman_tail_fraction"],
                    "absolute_spearman_tail_count": summary["absolute_spearman_tail_count"],
                    "absolute_spearman_tail_fraction": summary["absolute_spearman_tail_fraction"],
                    "sign_concordance_tail_count": summary["sign_concordance_tail_count"],
                    "sign_concordance_tail_fraction": summary["sign_concordance_tail_fraction"],
                }
            )
            for row in permutations:
                permutation_rows.append(
                    {"face": face_name, "axis_degrees": axis, "variant": variant, **row}
                )

    invariance = coordinate_invariance(
        face_data["90_primary"]["pca"]["centered"],
        np.asarray([block[1] for block in FACE90], dtype=float),
        face_data["90_primary"]["pca"],
    )

    raw_eta = drift_by_axis[90.0]["raw_even_eta"]
    raw_alpha = drift_by_axis[90.0]["raw_even_alpha"]
    raw_direction = drift_by_axis[90.0]["raw_even_direction"]
    identity_error = float(np.max(np.abs(raw_direction - raw_eta / raw_alpha)))
    inversion_rows: list[dict[str, Any]] = []
    inversion_count = 0
    for left, right in itertools.combinations(range(len(H_DEGREES)), 2):
        eta_order = float(np.sign(raw_eta[left] - raw_eta[right]))
        direction_order = float(np.sign(raw_direction[left] - raw_direction[right]))
        inverted = eta_order * direction_order < 0.0
        inversion_count += int(inverted)
        inversion_rows.append(
            {
                "left_h_degrees": float(H_DEGREES[left]),
                "right_h_degrees": float(H_DEGREES[right]),
                "raw_eta_left": float(raw_eta[left]),
                "raw_eta_right": float(raw_eta[right]),
                "raw_alpha_left": float(raw_alpha[left]),
                "raw_alpha_right": float(raw_alpha[right]),
                "raw_direction_left": float(raw_direction[left]),
                "raw_direction_right": float(raw_direction[right]),
                "eta_order_sign": eta_order,
                "direction_order_sign": direction_order,
                "denominator_induced_order_inversion": inverted,
            }
        )
    relation90 = face_data["90_primary"]["relations"]
    normalization_documented = (
        bool(np.all(raw_alpha > 0.0))
        and identity_error <= 1.0e-12
        and inversion_count >= 1
        and relation90["raw_even_eta"]["relation_pass"]
        and not relation90["raw_even_direction"]["relation_pass"]
    )

    rank1_90 = face_data["90_primary"]["rank1_pass"]
    original90 = relation90["original_r_eta"]["relation_pass"]
    support90 = (
        relation90["frozen_baseline_r_eta"]["relation_pass"]
        or relation90["raw_even_eta"]["relation_pass"]
    )
    matched270_reproduces = (
        face_data["270_matched"]["rank1_pass"]
        and face_data["270_matched"]["relations"]["original_r_eta"]["relation_pass"]
    )
    core_support = rank1_90 and original90 and support90 and not matched270_reproduces
    raw_direction90 = relation90["raw_even_direction"]["relation_pass"]
    if core_support and raw_direction90:
        decision = "FACE_LEVEL_CANDIDATE"
    elif core_support and normalization_documented:
        decision = "FACE_LEVEL_CANDIDATE_NORMALIZATION_SENSITIVE"
    else:
        decision = "FACE_LEVEL_NOT_SUPPORTED"
    descriptive_classification = (
        "RANK1_FACE_GEOMETRY_CONFIRMED_DRIFT_LINK_NOT_ROBUST"
        if rank1_90 and not core_support
        else "FACE_GEOMETRY_AND_DRIFT_LINK_SUPPORTED"
        if core_support
        else "RANK1_FACE_GEOMETRY_NOT_CONFIRMED"
    )

    result = {
        "schema_version": "1.0",
        "status": "COMPLETE",
        "decision": decision,
        "descriptive_classification": descriptive_classification,
        "new_solver_runs": 0,
        "source_solve_count": 38,
        "regression_models_fit": 0,
        "primary_90_face_blocks": [list(block) for block in FACE90],
        "native_270_ell0_block_count": len(active270_ell0),
        "face_geometry": {
            name: {
                "axis_degrees": data["axis"],
                "blocks": [list(block) for block in data["blocks"]],
                "pc1_fraction": float(data["pca"]["explained_fractions"][0]),
                "singular_values": data["pca"]["singular_values"].tolist(),
                "explained_fractions": data["pca"]["explained_fractions"].tolist(),
                "pc1_direction": data["pca"]["direction"].tolist(),
                "rank1_pass": data["rank1_pass"],
                "max_loso_angle_degrees": max(
                    row["angle_to_full_pc1_degrees"] for row in data["loso"]
                ),
                "min_loso_training_pc1_fraction": min(
                    row["training_pc1_fraction"] for row in data["loso"]
                ),
                "max_loso_heldout_residual_fraction": max(
                    row["held_out_residual_fraction"] for row in data["loso"]
                ),
                "cross_fitted_scores": data["gamma"].tolist(),
                "drift_relations": data["relations"],
            }
            for name, data in face_data.items()
        },
        "normalization_sensitivity_90": {
            "raw_direction_identity_max_abs_error": identity_error,
            "all_raw_alpha_positive": bool(np.all(raw_alpha > 0.0)),
            "raw_alpha_values": raw_alpha.tolist(),
            "pairwise_order_count": len(inversion_rows),
            "denominator_induced_order_inversion_count": inversion_count,
            "documented": normalization_documented,
            "claim_boundary": "Arithmetic normalization sensitivity is documented; this does not prove alpha is a nuisance or that the ratio reversal is an artifact.",
        },
        "coordinate_invariance": invariance,
        "decision_components": {
            "90_rank1_pass": rank1_90,
            "90_original_relation_pass": original90,
            "90_support_variant_pass": support90,
            "90_raw_even_direction_relation_pass": raw_direction90,
            "270_matched_reproduces_rank1_and_original_relation": matched270_reproduces,
            "normalization_sensitivity_documented": normalization_documented,
            "core_face_support": core_support,
        },
        "read_only_stop_recommended": decision == "FACE_LEVEL_NOT_SUPPORTED",
        "claim_boundary": scope["claim_boundary"],
    }

    write_json(ROOT / "face_geometry_result.json", result)
    write_json(ROOT / "coordinate_invariance.json", invariance)
    write_csv(ROOT / "response_variants_90_270.csv", response_rows)
    write_csv(ROOT / "face_demand_coordinates.csv", demand_rows)
    write_csv(ROOT / "pca_geometry_summary.csv", geometry_rows)
    write_csv(ROOT / "pc1_loadings.csv", loading_rows)
    write_csv(ROOT / "loso_pca_scores.csv", loso_rows)
    write_csv(ROOT / "drift_relation_summary.csv", relation_rows)
    write_csv(ROOT / "scale_permutation_120.csv", permutation_rows)
    write_csv(ROOT / "normalization_pairwise_order_audit.csv", inversion_rows)

    figure, axes = plt.subplots(2, 3, figsize=(17, 10))
    colors = ["#4c78a8", "#f58518", "#54a24b", "#e45756"]
    p90 = face_data["90_primary"]["proportions"]
    p90_centered = p90 - np.mean(p90, axis=0)
    for index, block in enumerate(FACE90):
        axes[0, 0].plot(
            H_DEGREES,
            1000.0 * p90_centered[:, index],
            "o-",
            color=colors[index],
            label=f"s{block[1]}",
        )
    axes[0, 0].set_xscale("log")
    axes[0, 0].invert_xaxis()
    axes[0, 0].set_title("90° centered ell=0 face demand")
    axes[0, 0].set_xlabel("h (degrees)")
    axes[0, 0].set_ylabel("1000 × (p - mean p)")
    axes[0, 0].legend()

    geometry_names = ["90_primary", "270_matched", "270_native"]
    geometry_labels = ["90 matched-4", "270 matched-4", "270 native"]
    pc1_values = [face_data[name]["pca"]["explained_fractions"][0] for name in geometry_names]
    axes[0, 1].bar(geometry_labels, pc1_values, color=["#4c78a8", "#b279a2", "#9d755d"])
    axes[0, 1].axhline(0.95, color="black", linestyle="--", linewidth=1)
    axes[0, 1].set_ylim(0.0, 1.02)
    axes[0, 1].set_ylabel("PC1 centered energy fraction")
    axes[0, 1].set_title("Regression-free face rank")
    axes[0, 1].tick_params(axis="x", rotation=15)

    gamma90 = face_data["90_primary"]["gamma"]
    original90_values = drift_by_axis[90.0]["original_r_eta"]
    axes[0, 2].scatter(gamma90, original90_values, s=70, color="#e45756")
    for index, h in enumerate(H_DEGREES):
        axes[0, 2].annotate(f"{h:.5g}", (gamma90[index], original90_values[index]), fontsize=8)
    axes[0, 2].axhline(0.0, color="gray", linewidth=0.7)
    axes[0, 2].axvline(0.0, color="gray", linewidth=0.7)
    axes[0, 2].set_xlabel("cross-fitted face PC1 score")
    axes[0, 2].set_ylabel("original r_eta")
    axes[0, 2].set_title("90° score vs drift (no fitted line)")

    variants = ["original_r_eta", "frozen_baseline_r_eta", "raw_even_eta", "raw_even_direction"]
    relation_labels = ["original", "frozen", "raw eta", "raw eta/alpha"]
    rho90 = [relation90[name]["spearman"] for name in variants]
    axes[1, 0].bar(relation_labels, rho90, color=["#4c78a8", "#72b7b2", "#54a24b", "#e45756"])
    axes[1, 0].axhline(0.8, color="black", linestyle="--", linewidth=1)
    axes[1, 0].axhline(0.0, color="gray", linewidth=0.7)
    axes[1, 0].set_ylim(-1.05, 1.05)
    axes[1, 0].set_ylabel("Spearman(gamma, drift)")
    axes[1, 0].set_title("90° drift-definition robustness")
    axes[1, 0].tick_params(axis="x", rotation=20)

    matched_gamma = face_data["270_matched"]["gamma"]
    matched_drift = drift_by_axis[270.0]["original_r_eta"]
    axes[1, 1].scatter(matched_gamma, matched_drift, s=70, color="#b279a2")
    for index, h in enumerate(H_DEGREES):
        axes[1, 1].annotate(f"{h:.5g}", (matched_gamma[index], matched_drift[index]), fontsize=8)
    axes[1, 1].set_xlabel("270° matched cross-fitted score")
    axes[1, 1].set_ylabel("270° original r_eta")
    axes[1, 1].set_title("270° matched control (no fitted line)")

    components = result["decision_components"]
    component_labels = ["90 rank1", "original", "support variant", "270 negative", "raw direction"]
    component_values = [
        components["90_rank1_pass"],
        components["90_original_relation_pass"],
        components["90_support_variant_pass"],
        not components["270_matched_reproduces_rank1_and_original_relation"],
        components["90_raw_even_direction_relation_pass"],
    ]
    axes[1, 2].bar(
        component_labels,
        [int(value) for value in component_values],
        color=["#59a14f" if value else "#e15759" for value in component_values],
    )
    axes[1, 2].set_ylim(0.0, 1.15)
    axes[1, 2].set_yticks([0, 1], ["FAIL", "PASS"])
    axes[1, 2].tick_params(axis="x", rotation=25)
    axes[1, 2].set_title(decision)
    figure.tight_layout()
    figure.savefig(ROOT / "face_geometry_diagnostics.png", dpi=180)
    plt.close(figure)

    report = f"""# Face-level geometry without regression

Status: **COMPLETE**  
Decision: **{decision}**  
Descriptive classification: **{descriptive_classification}**  
Saved source solves: **38**  
New solver runs: **0**  
Regression models fit: **0**

## 90-degree face geometry

The fixed face is `{FACE90}`. Centered normalized demand has PC1 energy fraction `{face_data['90_primary']['pca']['explained_fractions'][0]:.9g}` (preregistered rank-1 threshold 0.95: **{'PASS' if rank1_90 else 'FAIL'}**). Across leave-one-scale-out PCA fits, the maximum angle to the full PC1 is `{max(row['angle_to_full_pc1_degrees'] for row in face_data['90_primary']['loso']):.6g}` degrees and the minimum training PC1 fraction is `{min(row['training_pc1_fraction'] for row in face_data['90_primary']['loso']):.9g}`.

In block order `(s11,s12,s24,s29)`, the mean face proportions are `{np.array2string(face_data['90_primary']['pca']['mean'], precision=7, separator=', ')}` and the oriented PC1 loadings are `{np.array2string(face_data['90_primary']['pca']['direction'], precision=7, separator=', ')}`. Thus the observed face mode is predominantly s29 against the pooled other three blocks, not a special s29-s24 exchange.

## Cross-fitted score versus drift, without regression

The PC orientation is fixed from low to high s-index without using drift. The table below reports Spearman rank agreement and the number of positive signs among the five products of held-out score and held-out drift relative to the four-point training mean.

| drift definition | Spearman | positive signs | relation pass | one-sided exact tail |
|---|---:|---:|---|---:|
| original r_eta | {relation90['original_r_eta']['spearman']:.6g} | {relation90['original_r_eta']['sign_concordance_count']}/5 | {relation90['original_r_eta']['relation_pass']} | {relation90['original_r_eta']['one_sided_spearman_tail_fraction']:.6g} |
| frozen baseline r_eta | {relation90['frozen_baseline_r_eta']['spearman']:.6g} | {relation90['frozen_baseline_r_eta']['sign_concordance_count']}/5 | {relation90['frozen_baseline_r_eta']['relation_pass']} | {relation90['frozen_baseline_r_eta']['one_sided_spearman_tail_fraction']:.6g} |
| raw even eta | {relation90['raw_even_eta']['spearman']:.6g} | {relation90['raw_even_eta']['sign_concordance_count']}/5 | {relation90['raw_even_eta']['relation_pass']} | {relation90['raw_even_eta']['one_sided_spearman_tail_fraction']:.6g} |
| raw even eta/alpha | {relation90['raw_even_direction']['spearman']:.6g} | {relation90['raw_even_direction']['sign_concordance_count']}/5 | {relation90['raw_even_direction']['relation_pass']} | {relation90['raw_even_direction']['one_sided_spearman_tail_fraction']:.6g} |

## 270-degree controls

The matched four-coordinate 270-degree PC1 fraction is `{face_data['270_matched']['pca']['explained_fractions'][0]:.9g}`. Its original-drift Spearman is `{face_data['270_matched']['relations']['original_r_eta']['spearman']:.6g}` with `{face_data['270_matched']['relations']['original_r_eta']['sign_concordance_count']}/5` positive signs, so simultaneous rank-1 plus drift reproduction is **{matched270_reproduces}**. The descriptive native 270-degree ell=0 face contains `{len(active270_ell0)}` blocks and has PC1 fraction `{face_data['270_native']['pca']['explained_fractions'][0]:.9g}`.

Because both 270-degree controls are also above the 0.95 rank-1 threshold, rank-1 face-demand variation alone is not a 90-degree-specific signature. The axis contrast lies in the absence of the same original-drift correspondence at 270 degrees.

## Normalization sensitivity

The exact identity `raw_even_direction = raw_even_eta/raw_even_alpha` holds to maximum absolute error `{identity_error:.3g}`; all five alpha values are positive. The variable denominator reverses `{inversion_count}` of 10 pairwise raw-eta orderings. Normalization sensitivity is preregistered as **{'DOCUMENTED' if normalization_documented else 'NOT DOCUMENTED'}**. This arithmetic result does not establish that alpha is a nuisance or that the ratio reversal is an artifact.

## Coordinate invariance and claim boundary

All 24 label permutations and all 16 coordinate sign flips preserve the singular spectrum and structurally oriented scores to within `{max(invariance['max_label_permutation_explained_fraction_error'], invariance['max_label_permutation_score_error'], invariance['max_sign_flip_explained_fraction_error'], invariance['max_sign_flip_score_error']):.3g}`. They are therefore sanity checks, not negative controls.

This package describes five saved scales only. It fits no drift-on-face regression and makes no causal, KKT, dual, population, continuum, or intervention claim.

## Re-run

`python analyze_face_geometry.py`
"""
    (ROOT / "README.md").write_text(report, encoding="utf-8")

    provenance_inputs = {str(path): sha256(path) for path in EXPECTED}
    provenance_inputs.update({str(path): sha256(path) for path in solve_paths})
    write_json(
        ROOT / "PROVENANCE_SHA256.json",
        {
            "schema_version": "1.0",
            "inputs": provenance_inputs,
            "source_solve_count": len(solve_paths),
            "new_solver_runs": 0,
            "regression_models_fit": 0,
        },
    )

    manifest_names = [
        "FACE_GEOMETRY_SCOPE.preregistered.json",
        "PROVENANCE_SHA256.json",
        "README.md",
        "analyze_face_geometry.py",
        "coordinate_invariance.json",
        "drift_relation_summary.csv",
        "face_demand_coordinates.csv",
        "face_geometry_diagnostics.png",
        "face_geometry_result.json",
        "loso_pca_scores.csv",
        "normalization_pairwise_order_audit.csv",
        "pc1_loadings.csv",
        "pca_geometry_summary.csv",
        "read_only_preflight.json",
        "response_variants_90_270.csv",
        "scale_permutation_120.csv",
    ]
    manifest = "".join(f"{sha256(ROOT / name)}  {name}\n" for name in manifest_names)
    (ROOT / "MANIFEST_SHA256.txt").write_text(manifest, encoding="utf-8")

    print(
        json.dumps(
            {
                "status": "COMPLETE",
                "decision": decision,
                "pc1_90": float(face_data["90_primary"]["pca"]["explained_fractions"][0]),
                "new_solver_runs": 0,
                "regression_models_fit": 0,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
