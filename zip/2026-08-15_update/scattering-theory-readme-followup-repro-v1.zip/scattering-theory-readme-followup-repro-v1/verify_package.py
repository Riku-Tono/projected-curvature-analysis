from __future__ import annotations

import csv
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from typing import Any


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST_SHA256.txt"
FOLLOWUP_ROOT = ROOT / "evidence" / "followup_packages"
BASE_REPRO = ROOT / "evidence" / "base_repro"
PORTABLE_ROOT = ROOT / "portable_replay" / "scripts"

STAGES = [
    ("face_level_geometry_regression_free_v1", "analyze_face_geometry.py"),
    ("active_demand_adversarial_audit_v1", "analyze_adversarial_audit.py"),
    ("drift_origin_active_demand_readonly_v1", "analyze_drift_origin.py"),
    ("near_null_fixed_direction_validation_v1", "analyze_fixed_direction.py"),
    ("near_null_direction_readonly_v1", "analyze_near_null.py"),
]

SKIP_REPLAY_NAMES = {
    "MANIFEST_SHA256.txt",
    "PROVENANCE_SHA256.json",
}


class VerificationError(RuntimeError):
    pass


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def is_cache_path(path: Path) -> bool:
    return any(part in {"__pycache__", ".mplconfig"} for part in path.parts) or path.suffix == ".pyc"


def parse_manifest(path: Path) -> dict[str, str]:
    entries: dict[str, str] = {}
    for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not raw.strip():
            continue
        try:
            expected, relative = raw.split("  ", 1)
        except ValueError as exc:
            raise VerificationError(f"Malformed manifest line {line_number}: {raw}") from exc
        if len(expected) != 64:
            raise VerificationError(f"Malformed SHA-256 on line {line_number}")
        normalized = relative.replace("\\", "/")
        if normalized in entries:
            raise VerificationError(f"Duplicate manifest path: {normalized}")
        entries[normalized] = expected.upper()
    return entries


def verify_manifest(package_root: Path, manifest_path: Path, require_complete: bool) -> int:
    entries = parse_manifest(manifest_path)
    for relative, expected in entries.items():
        path = package_root / Path(relative)
        if not path.is_file():
            raise VerificationError(f"Manifest file missing: {path}")
        actual = sha256(path)
        if actual != expected:
            raise VerificationError(
                f"Manifest mismatch: {relative}: expected {expected}, observed {actual}"
            )
    if require_complete:
        actual_files = {
            path.relative_to(package_root).as_posix()
            for path in package_root.rglob("*")
            if path.is_file()
            and path != manifest_path
            and not is_cache_path(path.relative_to(package_root))
        }
        listed = set(entries)
        if actual_files != listed:
            missing = sorted(actual_files - listed)
            stale = sorted(listed - actual_files)
            raise VerificationError(
                f"Top-level manifest closure failure; unlisted={missing}, stale={stale}"
            )
    return len(entries)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def parse_csv_scalar(value: str) -> Any:
    if value == "":
        return value
    try:
        return float(value)
    except ValueError:
        return value


def load_csv(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return [
            {key: parse_csv_scalar(value) for key, value in row.items()}
            for row in csv.DictReader(handle)
        ]


def compare_values(reference: Any, observed: Any, location: str) -> None:
    if isinstance(reference, bool) or isinstance(observed, bool):
        if reference is not observed:
            raise VerificationError(f"Boolean mismatch at {location}: {reference} != {observed}")
        return
    if isinstance(reference, (int, float)) and isinstance(observed, (int, float)):
        left = float(reference)
        right = float(observed)
        if math.isnan(left) and math.isnan(right):
            return
        if not math.isclose(left, right, rel_tol=2.0e-11, abs_tol=2.0e-12):
            raise VerificationError(f"Numeric mismatch at {location}: {left} != {right}")
        return
    if isinstance(reference, dict) and isinstance(observed, dict):
        if set(reference) != set(observed):
            raise VerificationError(
                f"Key mismatch at {location}: {sorted(reference)} != {sorted(observed)}"
            )
        for key in reference:
            compare_values(reference[key], observed[key], f"{location}.{key}")
        return
    if isinstance(reference, list) and isinstance(observed, list):
        if len(reference) != len(observed):
            raise VerificationError(
                f"Length mismatch at {location}: {len(reference)} != {len(observed)}"
            )
        for index, (left, right) in enumerate(zip(reference, observed)):
            compare_values(left, right, f"{location}[{index}]")
        return
    if reference != observed:
        raise VerificationError(f"Value mismatch at {location}: {reference!r} != {observed!r}")


def compare_replayed_file(reference: Path, observed: Path) -> None:
    if not observed.is_file():
        raise VerificationError(f"Replay output missing: {observed}")
    if reference.suffix == ".json":
        compare_values(load_json(reference), load_json(observed), reference.name)
    elif reference.suffix == ".csv":
        compare_values(load_csv(reference), load_csv(observed), reference.name)
    else:
        left = reference.read_text(encoding="utf-8")
        right = observed.read_text(encoding="utf-8")
        if left != right:
            raise VerificationError(f"Text replay mismatch: {reference.name}")


def verify_dependencies() -> dict[str, str]:
    expected = {"numpy": "2.5.0", "matplotlib": "3.11.1"}
    observed = {name: importlib.metadata.version(name) for name in expected}
    if observed != expected:
        raise VerificationError(f"Pinned dependency mismatch: {observed} != {expected}")
    return observed


def verify_provenance_and_claims() -> int:
    provenance = load_json(ROOT / "PROVENANCE.json")
    before = ROOT / provenance["readme"]["before_path"]
    after = ROOT / provenance["readme"]["after_path"]
    if sha256(before) != provenance["readme"]["before_sha256"]:
        raise VerificationError("Before README hash mismatch")
    if sha256(after) != provenance["readme"]["after_sha256"]:
        raise VerificationError("After README hash mismatch")
    if before.read_bytes() == after.read_bytes():
        raise VerificationError("README before and after are unexpectedly identical")
    if not (ROOT / provenance["readme"]["unified_patch"]).is_file():
        raise VerificationError("Unified README patch is missing")

    manifest_paths = {
        "base_repro": BASE_REPRO / "MANIFEST_SHA256.txt",
        **{
            stage: FOLLOWUP_ROOT / stage / "MANIFEST_SHA256.txt"
            for stage, _ in STAGES
        },
    }
    for name, path in manifest_paths.items():
        expected = provenance["sealed_manifest_hashes"][name]
        if sha256(path) != expected:
            raise VerificationError(f"Sealed manifest provenance mismatch: {name}")

    readme = after.read_text(encoding="utf-8")
    base_result = load_json(BASE_REPRO / "reference" / "projected_curvature_result.json")
    near = load_json(FOLLOWUP_ROOT / "near_null_direction_readonly_v1" / "near_null_result.json")
    fixed = load_json(
        FOLLOWUP_ROOT
        / "near_null_fixed_direction_validation_v1"
        / "fixed_direction_result.json"
    )
    drift = load_json(
        FOLLOWUP_ROOT / "drift_origin_active_demand_readonly_v1" / "drift_origin_result.json"
    )
    audit = load_json(
        FOLLOWUP_ROOT
        / "active_demand_adversarial_audit_v1"
        / "adversarial_audit_result.json"
    )
    face = load_json(
        FOLLOWUP_ROOT
        / "face_level_geometry_regression_free_v1"
        / "face_geometry_result.json"
    )

    tokens = [
        base_result["classification"],
        str(near["stable_window"]["minimum_cancellation_fraction"]),
        str(near["stable_window"]["maximum_cancellation_fraction"]),
        str(near["stable_window"]["minimum_cosine_to_1_minus2_1"]),
        str(fixed["blind_zero_sum_direction"]["projection_energy_fraction"]),
        str(drift["primary_model_comparison"]["90_r_eta_demand_p_D_normalized_loocv_sse"]),
        audit["decision"],
        audit["competitor_qualifier"],
        face["decision"],
        face["descriptive_classification"],
        str(face["face_geometry"]["90_primary"]["pc1_fraction"]),
        str(face["face_geometry"]["270_matched"]["pc1_fraction"]),
        str(face["face_geometry"]["270_native"]["pc1_fraction"]),
    ]
    missing = [token for token in tokens if token not in readme]
    if missing:
        raise VerificationError(f"README is missing sealed-result tokens: {missing}")

    labels = ["ACTIVE_DEMAND_CANDIDATE", "DOES_NOT_SURVIVE", "FACE_LEVEL_NOT_SUPPORTED"]
    positions = [readme.find(label) for label in labels]
    if any(position < 0 for position in positions) or positions != sorted(positions):
        raise VerificationError(f"README audit-stage ordering is wrong: {positions}")

    result_records = [base_result, near, fixed, drift, audit, face]
    for record in result_records:
        if record.get("source_solve_count", 38) != 38:
            raise VerificationError("A result record does not report 38 source solves")
        if record.get("new_solver_runs") != 0:
            raise VerificationError("A result record reports a nonzero solver count")
    if face.get("regression_models_fit") != 0:
        raise VerificationError("Final face stage unexpectedly fit a regression model")
    return len(tokens)


def run_subprocess(command: list[str], cwd: Path, timeout: int = 180) -> str:
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=environment,
        text=True,
        capture_output=True,
        timeout=timeout,
    )
    output = (completed.stdout + "\n" + completed.stderr).strip()
    if completed.returncode != 0:
        raise VerificationError(
            f"Command failed ({completed.returncode}) in {cwd}: {' '.join(command)}\n{output}"
        )
    return output


def replay_base_package() -> str:
    output = run_subprocess([sys.executable, "verify_package.py"], BASE_REPRO)
    if "PACKAGE VERIFICATION: PASS" not in output:
        raise VerificationError("Bundled base verifier did not report PASS")
    return "PASS"


def copytree_without_caches(source: Path, destination: Path) -> None:
    shutil.copytree(
        source,
        destination,
        ignore=shutil.ignore_patterns("__pycache__", ".mplconfig", "*.pyc"),
    )


def replay_followups() -> tuple[int, int]:
    compared_files = 0
    with tempfile.TemporaryDirectory(prefix="near_null_readme_replay_") as temporary:
        workspace = Path(temporary) / "workspace"
        outputs = workspace / "outputs"
        copytree_without_caches(BASE_REPRO, workspace / "base_repro")
        copytree_without_caches(FOLLOWUP_ROOT, outputs)

        for stage, script_name in STAGES:
            target_stage = outputs / stage
            portable_script = PORTABLE_ROOT / stage / script_name
            if not portable_script.is_file():
                raise VerificationError(f"Portable script missing: {portable_script}")
            shutil.copy2(portable_script, target_stage / script_name)
            output = run_subprocess([sys.executable, script_name], target_stage)
            if '"status": "COMPLETE"' not in output and "EXITCODE" not in output:
                result_candidates = list(target_stage.glob("*result.json"))
                if not result_candidates:
                    raise VerificationError(f"Replay stage did not complete: {stage}")

            reference_stage = FOLLOWUP_ROOT / stage
            manifest_entries = parse_manifest(reference_stage / "MANIFEST_SHA256.txt")
            for relative in sorted(manifest_entries):
                name = Path(relative).name
                suffix = Path(relative).suffix.lower()
                if (
                    name in SKIP_REPLAY_NAMES
                    or name == script_name
                    or suffix == ".png"
                ):
                    continue
                compare_replayed_file(reference_stage / relative, target_stage / relative)
                compared_files += 1
    return len(STAGES), compared_files


def main() -> int:
    try:
        dependency_versions = verify_dependencies()
        manifest_count = verify_manifest(ROOT, MANIFEST, require_complete=True)
        nested_count = verify_manifest(BASE_REPRO, BASE_REPRO / "MANIFEST_SHA256.txt", False)
        for stage, _ in STAGES:
            stage_root = FOLLOWUP_ROOT / stage
            nested_count += verify_manifest(
                stage_root, stage_root / "MANIFEST_SHA256.txt", False
            )
        claim_count = verify_provenance_and_claims()
        base_status = replay_base_package()
        replay_stage_count, compared_files = replay_followups()
    except (VerificationError, OSError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        print(f"PACKAGE VERIFICATION: FAIL\n{exc}")
        return 1

    print(f"Pinned dependencies: {dependency_versions}")
    print(f"Top-level manifest entries checked: {manifest_count}")
    print(f"Nested manifest entries checked: {nested_count}")
    print(f"README sealed-result tokens checked: {claim_count}")
    print(f"Bundled base replay: {base_status}")
    print(
        f"Follow-up stages regenerated: {replay_stage_count}; "
        f"deterministic files compared: {compared_files}"
    )
    print("Source solves: 38; new solver runs: 0")
    print("PACKAGE VERIFICATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
